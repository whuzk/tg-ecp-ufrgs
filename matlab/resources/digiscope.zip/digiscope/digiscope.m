function varargout = digiscope(varargin)
% DIGISCOPE M-file for digiscope.fig
%      DIGISCOPE, by itself, creates a new DIGISCOPE or raises the existing
%      singleton*.
%
%      H = DIGISCOPE returns the handle to a new DIGISCOPE or the handle to
%      the existing singleton*.
%
%      DIGISCOPE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DIGISCOPE.M with the given input arguments.
%
%      DIGISCOPE('Property','Value',...) creates a new DIGISCOPE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before digiscope_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to digiscope_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help digiscope

% Last Modified by GUIDE v2.5 15-Oct-2008 07:47:50

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @digiscope_OpeningFcn, ...
                   'gui_OutputFcn',  @digiscope_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before digiscope is made visible.
function digiscope_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to digiscope (see VARARGIN)



% Choose default command line output for digiscope
handles.output = hObject;
handles.filters = [];
handles.timeLength = 2;
handles.haveSignal = 0;
handles.startT = 0;
handles.filterPlots = [];
handles.URL = 'https://digiscope.svn.sourceforge.net/svnroot/digiscope/trunk/';
set(handles.filterList,'value',[]);
handles.guiDir = handlePaths(1);
handles.filtDir = sprintf('%s%sfunctions%sfilters',handles.guiDir,filesep,filesep);
handles.custFiltDir = sprintf('%s%sfunctions%smyFilters',handles.guiDir,filesep,filesep);
handles = getFilters(handles);

% get the status if available
updateDir = sprintf('%s%sfunctions%sutils%supdate%s',handles.guiDir, filesep, filesep, filesep, filesep);
statusFile = [updateDir,'status.mat'];
rev = '';
if exist(statusFile,'file')
    status = load(statusFile);
    rev = sprintf(', Rev %s', status.Revision);
end
fprintf('Starting Digiscope V3.0%s...\n', rev);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes digiscope wait for user response (see UIRESUME)
% uiwait(handles.digiscope);

%-------------------------------------------
function guiDir = handlePaths(todo)

guiDir = which('digiscope');
a = strfind(guiDir,filesep);
if isempty(a)
    %error?
end
guiDir = guiDir(1:a(end));
paths{1} = sprintf('%s%sfunctions%sfilters',guiDir,filesep,filesep);
paths{2} = sprintf('%s%sfunctions%smyFilters',guiDir,filesep,filesep);
paths{3} = sprintf('%s%sfunctions%sIO',guiDir,filesep,filesep);
paths{4} = sprintf('%s%sfunctions%sutils',guiDir,filesep,filesep);
paths{5} = sprintf('%s%sfunctions%sutils%supdate',guiDir,filesep,filesep, filesep);
paths{6} = guiDir;

if todo == 1
    % add paths to path
    for i=1:length(paths)
        addpath(paths{i});
    end
else
    for i=1:length(paths)
        rmpath(paths{i});
    end
end

%--------------------------------------------
function handles = getFilters(handles)
% first get the contents of the filter directory
filterListObjs = [];

D = dir(handles.filtDir);
n = 0;
for i=1:length(D)
    if D(i).isdir continue; end
    if isempty(strfind(D(i).name,'.m')) continue; end
    if ~isempty(strfind(D(i).name,'.m~')) continue; end
    
    % check the validity of the file
    try
        funcName = D(i).name(1:end-2);
        newObj = eval(sprintf('%s(''filtdat'')', funcName));
        if ~isstruct(newObj) || ~isfield(newObj,'passthrough')
            continue;
        end
        n = n+1;
        
        filterListObjs{n} = newObj;
        filterListObjs{n}.funcName = funcName;
        filterListObjs{n}.infoBox = handles.outputBox;
    catch
        fprintf('Invalid function file: %s\n', D(i).name);
        continue;
    end
end

D = dir(handles.custFiltDir);
for i=1:length(D)
    if D(i).isdir continue; end
    if isempty(strfind(D(i).name,'.m')) continue; end
    if ~isempty(strfind(D(i).name,'.m~')) continue; end
    
    % check the validity of the file
    try
        funcName = D(i).name(1:end-2);
        newObj = eval(sprintf('%s(''filtdat'')', funcName));
        if ~isstruct(newObj) || ~isfield(newObj,'passthrough')
            continue;
        end
        n = n+1;
        
        filterListObjs{n} = newObj;
        filterListObjs{n}.funcName = funcName;
        filterListObjs{n}.infoBox = handles.outputBox;
    catch
        fprintf('Invalid function file: %s\n', D(i).name);
        continue;
    end
end

handles.filterObjs = filterListObjs;


% --- Outputs from this function are returned to the command line.
function varargout = digiscope_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function timeBox_Callback(hObject, eventdata, handles)
% hObject    handle to timeBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of timeBox as text
%        str2double(get(hObject,'String')) returns contents of timeBox as a double

v = sort(str2num(get(hObject,'string')));
if length(v) ~= 2
    v = [0 handles.timeLength]+handles.startT;
end
handles.startT = v(1);
handles.timeLength = v(2)-handles.startT;
handles = scrollPlots(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function timeBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to timeBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in backSmallBtn.
function backSmallBtn_Callback(hObject, eventdata, handles)
% hObject    handle to backSmallBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if isempty(handles.filters{1}) || ~handles.haveSignal  return; end

incVal = -handles.timeLength/10;
if handles.startT + incVal < 0 return; end
handles.startT = handles.startT + incVal;
handles = scrollPlots(handles);
guidata(hObject, handles);
% --- Executes on button press in backLargeBtn.
function backLargeBtn_Callback(hObject, eventdata, handles)
% hObject    handle to backLargeBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if isempty(handles.filters{1}) || ~handles.haveSignal  return; end

incVal = -handles.timeLength;
if handles.startT +incVal < 0 return; end
handles.startT = handles.startT + incVal;
handles = scrollPlots(handles);
guidata(hObject, handles);

% --- Executes on button press in backStartBtn.
function backStartBtn_Callback(hObject, eventdata, handles)
% hObject    handle to backStartBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if isempty(handles.filters{1}) || ~handles.haveSignal  return; end

handles.startT = 0;
handles = scrollPlots(handles);
guidata(hObject, handles);

% --- Executes on button press in forwSmallBtn.
function forwSmallBtn_Callback(hObject, eventdata, handles)
% hObject    handle to forwSmallBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if isempty(handles.filters{1}) || ~handles.haveSignal  return; end

incVal = handles.timeLength/10;
if (handles.startT + handles.timeLength + incVal) > length(handles.filters{1}.data)/handles.filters{1}.Rate; 
    handles.startT = length(handles.filters{1}.data)/handles.filters{1}.Rate - handles.timeLength -incVal;
end
handles.startT = handles.startT + incVal;
handles = scrollPlots(handles);
guidata(hObject, handles);

% --- Executes on button press in forwLargeBtn.
function forwLargeBtn_Callback(hObject, eventdata, handles)
% hObject    handle to forwLargeBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if isempty(handles.filters{1}) || ~handles.haveSignal  return; end

incVal = handles.timeLength;
if (handles.startT + handles.timeLength + incVal) > length(handles.filters{1}.data)/handles.filters{1}.Rate; 
    handles.startT = length(handles.filters{1}.data)/handles.filters{1}.Rate - handles.timeLength-incVal;
end
handles.startT = handles.startT + incVal;
handles = scrollPlots(handles);
guidata(hObject, handles);
% --- Executes on button press in forwEndBtn.
function forwEndBtn_Callback(hObject, eventdata, handles)
% hObject    handle to forwEndBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if isempty(handles.filters{1}) || ~handles.haveSignal  return; end

handles.startT = length(handles.filters{1}.data)/handles.filters{1}.Rate - handles.timeLength;
handles = scrollPlots(handles);
guidata(hObject, handles);
% --- Executes on button press in zoomInBtn.
function zoomInBtn_Callback(hObject, eventdata, handles)
% hObject    handle to zoomInBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if isempty(handles.filters{1}) || ~handles.haveSignal return; end
handles.timeLength = (handles.timeLength/1.5);
if handles.timeLength < .01 handles.timeLength = .01; end
%handles = updatePlots(handles);
handles = scrollPlots(handles);
set(handles.ySensBox,'string','');
guidata(hObject, handles);

% --- Executes on button press in zoomOutBtn.
function zoomOutBtn_Callback(hObject, eventdata, handles)
% hObject    handle to zoomOutBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if isempty(handles.filters{1}) || ~handles.haveSignal  return; end
handles.timeLength = (handles.timeLength*1.5);
if handles.timeLength > handles.filters{1}.t(end) handles.timeLength = handles.filters{1}.t(end); end
if (handles.startT + handles.timeLength) > handles.filters{1}.t(end) 
    handles.startT = handles.filters{1}.t(end) - handles.timeLength;
end
%handles = updatePlots(handles);
handles = scrollPlots(handles);
set(handles.ySensBox,'string','');
guidata(hObject, handles);

% --- Executes on selection change in filterList.
function filterList_Callback(hObject, eventdata, handles)
% hObject    handle to filterList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns filterList contents as cell array
%        contents{get(hObject,'Value')} returns selected item from filterList

a = get(handles.filterList,'value');
if isempty(a) || a(1) > length(handles.filters) return; end
set(handles.plotCheck,'value',handles.filters{a(1)}.plot);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function filterList_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filterList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in addFilterBtn.
function addFilterBtn_Callback(hObject, eventdata, handles)
% hObject    handle to addFilterBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

filterNames = [];
for i=1:length(handles.filterObjs)
    filterNames{i} = handles.filterObjs{i}.name;
end
[sel,ok] = listdlg('liststring', filterNames,'PromptString','Add a New Action');
if ok == 0 return; end

filtStr = get(handles.filterList,'string');
filtStr{end+1} = filterNames{sel};
set(handles.filterList,'string', filtStr);
handles.filters{end+1} = handles.filterObjs{sel};
handles.filters{end}.filtPos = length(handles.filters);
handles = configFilter(handles,length(handles.filters));
guidata(hObject, handles);
[filters, outstr, str] = updateFilterChain(handles.filters,0,handles.startT, handles.timeLength);
handles.filters = filters;
set(handles.outputBox,'string',outstr);
set(handles.filterList,'string',str);
guidata(hObject, handles);
handles = updatePlots(handles);
guidata(hObject, handles);
% --- Executes on button press in delFilterBtn.
function delFilterBtn_Callback(hObject, eventdata, handles)
% hObject    handle to delFilterBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
v = get(handles.filterList,'value');
if isempty(v) return; end

answer = questdlg('Are you sure you want to remove this action(s)? This cannot be undone!',...
    'Remove Filters','Yes','No','No');
if isempty(answer) || strcmp(answer,'No') return; end
str = get(handles.filterList,'string');
for i = length(v):-1:1
    handles.filters(v(i)) = [];
    str(v(i)) = [];
end
set(handles.filterList,'string',str,'value',[]);
[filters, outstr, str] = updateFilterChain(handles.filters,0,handles.startT, handles.timeLength);
handles.filters = filters;
set(handles.outputBox,'string',outstr);
set(handles.filterList,'string',str);
guidata(hObject, handles);
handles = updatePlots(handles);
guidata(hObject, handles);

% --- Executes on button press in moveUpBtn.
function moveUpBtn_Callback(hObject, eventdata, handles)
% hObject    handle to moveUpBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% the main signal must ALWAYS be first, so filters{1} cannot move down ever
v = get(handles.filterList,'value');
newV = [];
if isempty(v) return; end
for i=1:length(v)
    if v(i) <= 2 continue; end
    tmpFilt = handles.filters{v(i)-1};    
    handles.filters{v(i)-1} = handles.filters{v(i)};
    handles.filters{v(i)} = tmpFilt;
    newV(end+1) = v(i)-1;
    clear tmpFilt;
end
for i=1:length(handles.filters)
    str{i} = handles.filters{i}.name;
end
set(handles.filterList,'string',str,'value',newV);
[filters, outstr, str] = updateFilterChain(handles.filters,0,handles.startT, handles.timeLength);
handles.filters = filters;
set(handles.outputBox,'string',outstr);
set(handles.filterList,'string',str);
guidata(hObject, handles);
handles = updatePlots(handles);
guidata(hObject, handles);

% --- Executes on button press in moveDownBtn.
function moveDownBtn_Callback(hObject, eventdata, handles)
% hObject    handle to moveDownBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
v = get(handles.filterList,'value');
newV = [];
if isempty(v) || isempty(handles.filters) return; end
for i=1:length(v)
    if v(i) == 1 || v(i) == length(handles.filters) continue; end
    tmpFilt = handles.filters{v(i)+1};    
    handles.filters{v(i)+1} = handles.filters{v(i)};
    handles.filters{v(i)} = tmpFilt;
    newV(end+1) = v(i)+1;
    clear tmpFilt;
end
for i=1:length(handles.filters)
    str{i} = handles.filters{i}.name;
end
set(handles.filterList,'string',str,'value',newV);
[filters, outstr, str] = updateFilterChain(handles.filters,0,handles.startT, handles.timeLength);
handles.filters = filters;
set(handles.outputBox,'string',outstr);
set(handles.filterList,'string',str);
guidata(hObject, handles);
handles = updatePlots(handles);
guidata(hObject, handles);

%------------------------------------------------------
function prevFilt = getPreviousFilter(handles, filtNum)
found = 0;
prevFilt = [];
for i=filtNum-1:-1:1
    if handles.filters{i}.passthrough == 1
        % it is this signal
        prevFilt = i;
        return;
    end
    if ~found continue; end
end

%---------------------------------------------------
function handles = configFilter(handles,val)
prevFilt = getPreviousFilter(handles,val);
if handles.filters{val}.sigreqd    
    if isempty(prevFilt)
        waitfor(errordlg('No input signal is present for this filter. Please load a signal.'));
        return;
    end
    curSignal = [];
    if ~isempty(handles.filters{prevFilt}.data)
        curSignal = handles.filters{prevFilt};
    else
        errordlg('No input signal is present for this filter. Please load a signal.');
    end
    try
        handles.filters{val} = eval(sprintf('%s(''config'',handles.filters{val},curSignal)',...
            handles.filters{val}.funcName));
    catch
        errordlg(sprintf('Error configuring filter: %s',lasterr));
        return;
    end
else
    curSignal = [];
    if ~isempty(prevFilt) && ~isempty(handles.filters) && ~isempty(handles.filters{prevFilt}.data)
        curSignal = handles.filters{prevFilt};
    end
    try
        handles.filters{val} = eval(sprintf('%s(''config'',handles.filters{val},curSignal)',...
            handles.filters{val}.funcName));
    catch
        errordlg(sprintf('Error configuring filter: %s',lasterr));
        return;
    end
end



% --- Executes on button press in configFilterBtn.
function configFilterBtn_Callback(hObject, eventdata, handles)
% hObject    handle to configFilterBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
val = get(handles.filterList,'value');
if isempty(val) return; end
val = val(1);
handles = configFilter(handles,val);

[filters, outstr, str] = updateFilterChain(handles.filters,0,handles.startT, handles.timeLength);
handles.filters = filters;
set(handles.outputBox,'string',outstr);
set(handles.filterList,'string',str);
guidata(hObject, handles);
handles = updatePlots(handles);
guidata(hObject, handles);

% --- Executes when digiscope is resized.
function digiscope_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to digiscope (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% figPos = get(hObject,'position');
% axesPos = get(handles.mainAxesPanel,'position');
% controlPos = get(handles.controlPanel,'position');
% filterPos = get(handles.filterPanel,'position');
% %infoPos = get(handles.infoPanel,'position');
% infoBox = get(handles.outputBox,'position');
% %filtSetPos = get(handles.filterSettingsPanel,'position');
% leftSpace = .24;
% rightSpace = .02;
% topSpace = .02;
% axesWidth = leftSpace - rightSpace;
% axesPos(1) = leftSpace;
% axesPos(3) = axesWidth;
% axesPos(4) = figPos(4) - topSpace - axesPos(2);
% filterPos(2) = figPos(4) - .02 - filterPos(4);
% %filtSetPos(2) = filterPos(2)-10-filtSetPos(4);
% controlPos(1) = figPos(3)/2 - controlPos(3)/2;
% infoPos(2) = axesPos(2);
% infoPos(4) = filterPos(2)-.005 - infoPos(2);
% infoBox(4) = infoPos(4)-.025;
figPos = get(hObject,'position');
filterList = get(handles.filterList,'position');
plotCheckPos = get(handles.plotCheck,'position');
updateBtnPos = get(handles.updateFiltersBtn,'position');
copyBtnPos = get(handles.copyFiltBtn,'position');
btnH =23;
btnW = 31;
spc = 5;
ctrlH = 75;
ctrlW = figPos(3)*.9;
filtPanelH = figPos(4) - ctrlH - 2*spc;
filtPanelW = 225;
axisH = filtPanelH;
axisW = figPos(3)-filtPanelW-spc*3;
filtW = filtPanelW - 4*spc;
filtH = filtPanelH/3-4*spc;

controlPos = [figPos(3)*0.05, spc, ctrlW, ctrlH];
filterPos = [spc, 2*spc+ctrlH, filtPanelW, filtPanelH];
axesPos = [filtPanelW+2*spc, 2*spc+ctrlH, axisW, axisH];

filterList = [2*spc, filtPanelH*2/3-spc, filtW, filtH];
btnStart = filterList(1)+filtW/2 - 5/2*btnW;
btnTop = filterList(2)-spc-btnH;


set(handles.mainAxesPanel,'position',axesPos);
set(handles.controlPanel,'position',controlPos);
set(handles.filterPanel,'position',filterPos);
set(handles.filterList,'position',filterList);
set(handles.moveUpBtn,'position',[btnStart, btnTop,btnW, btnH]);
set(handles.moveDownBtn,'position',[btnStart+btnW, btnTop, btnW, btnH]);
set(handles.configFilterBtn,'position',...
    [btnStart+2*btnW, btnTop, btnW, btnH]);
set(handles.addFilterBtn,'position',...
    [btnStart+3*btnW, btnTop, btnW, btnH]);
set(handles.delFilterBtn,'position',...
    [btnStart+4*btnW, btnTop, btnW, btnH]);
set(handles.plotCheck,'position',...
    [filterList(1), btnTop-spc-btnH,plotCheckPos(3), btnH]);
set(handles.updateFiltersBtn,'position',...
    [filterList(1)+filtW/2-updateBtnPos(3)/2,btnTop-spc-btnH,...
    updateBtnPos(3), btnH]);
set(handles.copyFiltBtn,'position',...
    [filterList(1)+filtW-copyBtnPos(3),btnTop-spc-btnH,...
    copyBtnPos(3), btnH]);
set(handles.outputBox,'position',...
    [filterList(1), 2*spc, filterList(3),btnTop-4*spc-btnH]);
%set(handles.infoPanel,'position',infoPos);
%set(handles.outputBox,'position',infoBox);
guidata(hObject, handles);

%set(handles.filterSettingsPanel,'position',filtSetPos);


% --------------------------------------------------------------------
function fileMnu_Callback(hObject, eventdata, handles)
% hObject    handle to fileMnu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function openDatMnu_Callback(hObject, eventdata, handles)
% hObject    handle to openDatMnu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function openTextMnu_Callback(hObject, eventdata, handles)
% hObject    handle to openTextMnu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function toolsMnu_Callback(hObject, eventdata, handles)
% hObject    handle to toolsMnu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function addSignalMnu_Callback(hObject, eventdata, handles)
% hObject    handle to addSignalMnu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function addDigiscopeMnu_Callback(hObject, eventdata, handles)
% hObject    handle to addDigiscopeMnu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if isempty(handles.filters)
    handles.filters{1} = [];
end
if ~isempty(handles.filters{1})
    answer = questdlg('A signal already exists. If you continue, this signal will be erased. Do you want to continue?','Overwrite Existing Signal','Yes','No','No');
    if isempty(answer) || strcmp(answer,'No') return; end
end

[fname,fpath] = uigetfile({'*.dat','Digiscope File (*.dat)';...
    '*.txt','Digiscope txt file (*.txt)'}, 'Select Digiscope DAT or TXT file',[handles.guiDir, filesep, 'ECGfiles', filesep]);
if fname == 0 return; end

if ~isempty(strfind(fname(end-3:end),'.dat'))
    try
        newSignal = DigiDatRead([fpath,fname]);
    catch
        errordlg(sprintf('Error reading %s. Make sure a valid Digiscope DAT file is selected, and try again',[fpath,fname]));
        return;
    end
elseif ~isempty(strfind(fname(end-3:end),'.txt'))
    try
        data = load([fpath,fname]);
    catch
        errordlg('Error reading %s. It does not appear to contain valid ASCII data.',fname);
    end
    prompt= {'Sample Rate','Voltage Range','Resolution'};
    def = {'200','-5.0 5.0','12'};
    ans = inputdlg(prompt,'Enter Signal Parameters',1,def);
    if isempty(ans) return; end
    Rate = str2num(ans{1});
    if Rate < 0 || isempty(Rate)
        errordlg('The Sampling Rate must be a numeric value greater than 0');
        return;
    end
    tmp = str2num(ans{2});
    if length(tmp) ~= 2 || isempty(tmp)
        errordlg('The Voltage Range must contain 2 numeric values');
        return;
    end
    VoltHigh = num2str(max(tmp));
    VoltLow = num2str(min(tmp));
    Resolution = str2num(ans{3});
    if Resolution < 0 || isempty(Resolution)
        errordlg('The Resolution must be a numeric value greater than 0');
        return;
    end
    Resolution = ans{3};
    Step = '0';
    Channels = '1';
    Samples = length(data);
    datar = data*(str2num(VoltHigh)-str2num(VoltLow))/(2^(str2num(Resolution)));
    newSignal = struct('Title', fname(1:end-4), 'Creator', 'txt', 'Source', 'txt',...
        'Typle','','Compress','0','Chan','1',...
        'VoltHigh', VoltHigh, 'VoltLow', VoltLow, 'Step', Step,...
        'Resolution', Resolution, 'Rate', Rate,...
        'Channels', Channels, 'Samples', Samples,...
        'data', datar, 'dataint', data);
else
    return;
end
handles.haveSignal = 1;
newSignal = initMainSignal('filtdat',newSignal);
handles.filters{1} = newSignal;
handles.startT = 0;
if handles.timeLength > length(handles.filters{1}.data)/handles.filters{1}.Rate
    handles.timeLength = length(handles.filters{1}.data)/handles.filters{1}.Rate;
end
[filters, outstr, str] = updateFilterChain(handles.filters,0,handles.startT, handles.timeLength);
handles.filters = filters;
set(handles.outputBox,'string',outstr);
set(handles.filterList,'string',str);
guidata(hObject,handles);
handles = updatePlots(handles);
guidata(hObject, handles);
% --------------------------------------------------------------------
function addSignalGenMnu_Callback(hObject, eventdata, handles)
% hObject    handle to addSignalGenMnu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if isempty(handles.filters)
    handles.filters{1} = [];
end
if ~isempty(handles.filters{1})
    answer = questdlg('A signal already exists. If you continue, this signal will be erased. Do you want to continue?','Overwrite Existing Signal','Yes','No','No');
    if isempty(answer) || strcmp(answer,'No') return; end
end
newSignal = wave_gen;
if isempty(newSignal) return; end
handles.haveSignal = 1;
newSignal = initMainSignal('filtdat',newSignal);
handles.filters{1} = newSignal;
handles.filters{1}.Rate = handles.filters{1}.Rate;
handles.startT = 0;
if handles.timeLength > length(handles.filters{1}.data)/handles.filters{1}.Rate
    handles.timeLength = length(handles.filters{1}.data)/handles.filters{1}.Rate;
end
[filters, outstr, str] = updateFilterChain(handles.filters,0,handles.startT, handles.timeLength);
handles.filters = filters;
set(handles.outputBox,'string',outstr);
set(handles.filterList,'string',str);
guidata(hObject,handles);
handles = updatePlots(handles);
guidata(hObject, handles);

% --------------------------------------------------------------------
function createFromExistMnu_Callback(hObject, eventdata, handles)
% hObject    handle to createFromExistMnu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function addFromTemplateMnu_Callback(hObject, eventdata, handles)
% hObject    handle to addFromTemplateMnu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

D = template_gen;

% --------------------------------------------------------------------
function saveFilterChainMnu_Callback(hObject, eventdata, handles)
% hObject    handle to saveFilterChainMnu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if isempty(handles.filters)
    errordlg('No signals or filters are loaded.');
    return;
end

[fname,fpath] = uiputfile('*.mat');
if fname == 0 return; end

ans = questdlg('Do you want to save the FIRST signal in the chain with action information, or do you want to CALCULATE and save every step in the chain?',...
    'Save Chain','FIRST','CALCULATE','FIRST');
if isempty(ans) return; end

filters = handles.filters;
if strcmp(ans,'FIRST')
    for i=2:length(filters)
        filters{i}.data = [];
        if isfield(filters{i},'t') filters{i}.t = []; end            
    end
end
save([fpath,fname],'filters');
%------------------------------------------------
function actFilts = getActFilts(handles)
actFilts = [];
for i=1:length(handles.filters)
    if handles.filters{i}.plot
        actFilts(end+1) = i;
    end
end

%------------------------------------------------
function handles = disableControls(handles, state)
return;
if state == 0
    state = 'off';
else
    state = 'on';
end
set(handles.filterList,'enable',state);
set(handles.addFilterBtn,'enable',state);
set(handles.delFilterBtn,'enable',state);
set(handles.moveUpBtn,'enable',state);
set(handles.moveDownBtn,'enable',state);
set(handles.configFilterBtn,'enable',state);
set(handles.updateFiltersBtn,'enable',state);
set(handles.copyFiltBtn,'enable',state);
set(handles.plotCheck,'enable',state);
    

%------------------------------------------------
function handles = updatePlots(handles, filtNum)
handles = disableControls(handles, 0);
if exist('filtNum') && ~isempty(filtNum)
    % just update a single plot
    if handles.filters{filtNum}.plot == 0 return; end
    eval(sprintf('%s(''plot'',handles.filters{filtNum}, handles.filters{filtNum}.axes)',...
        handles.filters{filtNum}.funcName));
    handles = disableControls(handles, 1);
    return;
end

plots = get(handles.mainAxesPanel,'children');
for i=1:length(plots) delete(plots(i)); end

actFilts = getActFilts(handles);
numPlots = 0;
for i=1:length(actFilts)
    numPlots = numPlots + handles.filters{actFilts(i)}.numPlots;
end
numActFilts = length(actFilts);
%axes(handles.mainAxes);
curPlot = 1;


% go through filters
ySens = str2num(get(handles.ySensBox,'string'));
for i=1:length(actFilts)
    f = actFilts(i);
    if f > length(handles.filters) continue; end
    if handles.filters{f}.plot == 0 continue; end
    for p = 1:handles.filters{f}.numPlots
        handles.filters{f}.axes(p) = subplot(numPlots,1,curPlot,'parent',handles.mainAxesPanel);
        handles.filterPlots(curPlot) = handles.filters{f}.axes(p);
        
        curPlot = curPlot+1;
    end
    eval(sprintf('%s(''plot'',handles.filters{f})',...
        handles.filters{f}.funcName));
    for p = 1:handles.filters{f}.numPlots
        if handles.filters{f}.scroll && ~isempty(ySens)
            set(handles.filters{f}.axes(p),'ylim',ySens);
        end
    end
    
end

%handles.startT = 0;
handles = scrollPlots(handles);
handles = disableControls(handles, 1);


%------------------------------------------------
function handles = scrollPlots(handles)
if isempty(handles.filterPlots) return; end
[handles.filters,outstr, str] = updateFilterChain(handles.filters,1,handles.startT, handles.timeLength);
set(handles.outputBox,'string',outstr);
set(handles.filterList,'string',str);
actFilts = getActFilts(handles);
for i=1:length(actFilts)
    if handles.filters{actFilts(i)}.updateWindow == 1
        %[filters, outstr, str] = updateFilterChain(handles.filters,1,handles.startT, handles.timeLength);
        %handles.filters = filters;
        handles = updatePlots(handles,actFilts(i));
    end
    if handles.filters{actFilts(i)}.scroll == 1
        set(handles.filters{actFilts(i)}.axes,'xlim',[0 handles.timeLength] + handles.startT);
        %handles.filters{actFilts(i)}.plotRange = ([0 handles.timeLength] + handles.startT)*handles.filters{actFilts(i)}.Rate+1;
    end
end

set(handles.timeBox,'string',...
    sprintf('%1.2f %1.2f',handles.startT, handles.startT+handles.timeLength));
handles = disableControls(handles, 1);


% --- Executes on button press in updateFilterChainBtn.
function updateFiltersBtn_Callback(hObject, eventdata, handles)
% hObject    handle to updateFilterChainBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filters, outstr, str, err] = updateFilterChain(handles.filters,0,handles.startT, handles.timeLength);
handles.filters = filters;
set(handles.outputBox,'string',outstr);
set(handles.filterList,'string',str);
if err return; end
handles = updatePlots(handles);
guidata(hObject, handles);


% --- Executes on button press in copyFiltBtn.
function copyFiltBtn_Callback(hObject, eventdata, handles)
% hObject    handle to copyFiltBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

v = get(handles.filterList,'value');
if isempty(v) || v == 1
    return;
end
handles.filters{end+1} = handles.filters{v};
[filters, outstr, str] = updateFilterChain(handles.filters,0,handles.startT, handles.timeLength);
handles.filters = filters;
set(handles.outputBox,'string',outstr);
set(handles.filterList,'string',str);
guidata(hObject,handles);
handles = updatePlots(handles);
guidata(hObject,handles);
% --- Executes on button press in plotCheck.
function plotCheck_Callback(hObject, eventdata, handles)
% hObject    handle to plotCheck (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of plotCheck

a = get(handles.filterList,'value');
p = get(handles.plotCheck,'value');
for i=1:length(a)
    if a(i) > length(handles.filters) continue; end
    handles.filters{a(i)}.plot = p;
end
handles = updatePlots(handles);
guidata(hObject, handles);



function outputBox_Callback(hObject, eventdata, handles)
% hObject    handle to outputBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of outputBox as text
%        str2double(get(hObject,'String')) returns contents of outputBox as a double


% --- Executes during object creation, after setting all properties.
function outputBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to outputBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in measureBtn.
function measureBtn_Callback(hObject, eventdata, handles)
% hObject    handle to measureBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of measureBtn

if get(hObject,'value')
    datacursormode on;
else
    datacursormode off;
end


% --------------------------------------------------------------------
function plotExternalFigure_Callback(hObject, eventdata, handles)
% hObject    handle to plotExternalFigure (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

plots = get(handles.mainAxesPanel,'children');
if isempty(plots) return; end
f = figure('color',[1 1 1]);
for i=1:length(plots)
    copyobj(plots(i), f);
end


% --------------------------------------------------------------------
function saveSignalMnu_Callback(hObject, eventdata, handles)
% hObject    handle to saveSignalMnu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function exportToDesktopMnu_Callback(hObject, eventdata, handles)
% hObject    handle to exportToDesktopMnu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
assignin('base','filters',handles.filters);

% --------------------------------------------------------------------
function saveSignalAsDatMnu_Callback(hObject, eventdata, handles)
% hObject    handle to saveSignalAsDatMnu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if isempty(handles.filters)
    errordlg('There are no signals loaded.');
    return;
end
v =get(handles.filterList,'value');
if isempty(v)
    errordlg('There are no signals loaded, or no filters selected.');
    return;
end
v = v(1);
[fname,fpath] = uiputfile('*.dat');
if fname == 0 return; end
DigiDatWrite([fpath,fname], handles.filters{v});

% --------------------------------------------------------------------
function saveSignalAsTxtMnu_Callback(hObject, eventdata, handles)
% hObject    handle to saveSignalAsTxtMnu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if isempty(handles.filters)
    errordlg('There are no signals loaded.');
    return;
end
v =get(handles.filterList,'value');

if isempty(v)
    errordlg('There are no signals loaded, or no filters selected.');
    return;
end
v = v(1);
[fname,fpath] = uiputfile('*.txt');
if fname == 0 return; end
S = handles.filters{v};
convertback = 2^(str2num(S.Resolution)) / ...
    (str2num(S.VoltHigh) - str2num(S.VoltLow));

datar = int16(S.data * convertback);
    dlmwrite([fpath,fname], datar,'delimiter','\n' ,'newline','pc');

% --------------------------------------------------------------------
function saveSignalAsMatMnu_Callback(hObject, eventdata, handles)
% hObject    handle to saveSignalAsMatMnu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if isempty(handles.filters)
    errordlg('There are no signals loaded.');
    return;
end
v =get(handles.filterList,'value');

if isempty(v)
    errordlg('There are no signals loaded, or no filters selected.');
    return;
end
v = v(1);
[fname,fpath] = uiputfile('*.mat');
if fname == 0 return; end
S = handles.filters{v};
save([fpath,fname], 'S');


% --------------------------------------------------------------------
function loadFilterChainMnu_Callback(hObject, eventdata, handles)
% hObject    handle to loadFilterChainMnu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if ~isempty(handles.filters)
    answer = questdlg('A signal and filter chain already exists. If you continue loading, this will be overwritten. Do you want to continue?',...
        'Load Filter Chain','Yes','No','No');
    if isempty(answer)||strcmp(answer,'No')
        return;
    end
end
[fname,fpath] = uigetfile('*.mat');
if fname == 0 return; end
F = load([fpath,fname]);
if isempty(F)
    errordlg('There was an error loading the filter chain.');
    return;
end
if ~isfield(F,'filters')
    errordlg('This does not appear to be a valid filter chain.');
    return;
end
handles.filters = F.filters;
handles.haveSignal = 1;
guidata(hObject, handles);
[filters, outstr, str] = updateFilterChain(handles.filters,0,handles.startT, handles.timeLength);
handles.filters = filters;
set(handles.outputBox,'string',outstr);
set(handles.filterList,'string',str);
guidata(hObject, handles);
handles = updatePlots(handles);
guidata(hObject, handles);


% --- Executes on button press in incSensBtn.
function incSensBtn_Callback(hObject, eventdata, handles)
% hObject    handle to incSensBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if isempty(handles.filters) || isempty(handles.filters{1}.data)
    return;
end
YL = get(gca,'ylim');
YL = max(abs(YL))/1.5;
set(gca,'ylim',[-YL YL]);
set(handles.ySensBox,'string',sprintf('%1.2f, %1.2f',-YL, YL));
guidata(hObject, handles);

% --- Executes on button press in decSensBtn.
function decSensBtn_Callback(hObject, eventdata, handles)
% hObject    handle to decSensBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if isempty(handles.filters) || isempty(handles.filters{1}.data)
    return;
end
YL = get(gca,'ylim');
YL = max(abs(YL))*1.5;
set(gca,'ylim',[-YL YL]);
set(handles.ySensBox,'string',sprintf('%1.2f, %1.2f',-YL, YL));
guidata(hObject, handles);

% --------------------------------------------------------------------
function signalStatusMnu_Callback(hObject, eventdata, handles)
% hObject    handle to signalStatusMnu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
v = get(handles.filterList,'value');
if isempty(v) v = 1; end
v = v(1);
if isempty(handles.filters) || isempty(handles.filters{v}) || isempty(handles.filters{v}.data)
    errordlg('No signal is loaded to view.');
    return;
end
statuspop(handles.filters{v});



function ySensBox_Callback(hObject, eventdata, handles)
% hObject    handle to ySensBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ySensBox as text
%        str2double(get(hObject,'String')) returns contents of ySensBox as a double
if isempty(handles.filters) || isempty(handles.filters{1}.data)
    return;
end
YL = sort(str2num(get(hObject,'string')));
if length(YL) ~= 2
    errordlg('The sensitivity must contain 2 values');
    return;
end
set(gca,'ylim',YL);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function ySensBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ySensBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in zoomBtn.
function zoomBtn_Callback(hObject, eventdata, handles)
% hObject    handle to zoomBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if get(hObject,'value')
    zoom on;
else
    zoom off;
end


% --------------------------------------------------------------------
function exportSignalMnu_Callback(hObject, eventdata, handles)
% hObject    handle to exportSignalMnu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
v = get(handles.filterList,'value');
if isempty(v) return; end
v = v(1);
if isempty(handles.filters) || isempty(handles.filters{v}) || isempty(handles.filters{v}.data)
    errordlg('No signal is loaded to view.');
    return;
end
F = handles.filters{v};
assignin('base','signal',F.data);
assignin('base','fs',F.Rate);


% --------------------------------------------------------------------
function Untitled_1_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function checkUpdatesMnu_Callback(hObject, eventdata, handles)
% hObject    handle to checkUpdatesMnu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[ans] = questdlg('Press OK to check for updates','Check For Updates','OK','Cancel','OK');
if isempty(ans) || strcmp(ans,'Cancel') return; end
st = checkForUpdates(handles.guiDir, handles.URL);
if st
    msgbox('Update Complete! Please restart digiscope to enable changes');
else
    msgbox('No updates available at this time');
end