function DigiTemplWrite(templfile, templstruct)

%%%%% Function description %%%%%
% Function use --   write a specified filter file
%
% Inputs:
% templfile -- the file to be written
%
% templstruct -- this is a struct containing the ASCII elements in the
%                   template.  The elements are: Name, ID, Datapoints,
%                   Rate, Data

fid = fopen(templfile, 'w'); %open the file for writing

if fid < 0
    error(['Problem with file' + templfile + 'for writing']);
end

%Write template file
fprintf(fid, '%s\r\n', templstruct.Name);
fprintf(fid, '%d\r\n', templstruct.ID);
fprintf(fid, '%d\r\n', templstruct.Datapoints);
fprintf(fid, '%d\r\n', templstruct.Rate);

for i = 1: 1 : templstruct.Datapoints
    fprintf(fid, '%d\r\n', templstruct.Data(i));
end

fclose(fid);