clear
%clf
%the function does not do anything if there is a error on the file yet
headd = DigiDatRead('ecg117.dat');

%headd %check the header
%ista1 = headd.datarray

DigiDatWrite('newdatfile.dat', headd);

headd2 = DigiDatRead('newdatfile.dat');

%itsa2 = headd2.datarray

if(headd.datarray == headd2.datarray)
    ok = 1
else ok = 0
end

%thisistheTitle = headd.Title

%figure(1)
%plot(headd.datarray) %look at a plot of the data
