function [b, a] = DigiFilRead(filfile)

%%%%% Function description %%%%%
% Function use --   read a given .fil file in DigiScope format.
%               This function reads in the b and a values to be given to
%               the Matlab filter function: y = filter(b, a, X)
%               where b contains the numerator coefficients,
%               a contains the denominator coefficients and
%               X is the data to be filtered (this can be read in from a
%               file using the DigiDatRead function
%
% Inputs:
% filfile -- the file to be loaded, it must be in standard Digiscope 
%               filter file format
%
% Outpus:
% firiir -- indicates whether the filter in the file is an fir or iir
%               firiir = 0 if the filter is an fir
%               firiir = 1 if the filter is an iir
% intfil -- indicates whether the filter in the file is an integer filter
%               intfil = 0 if the filter is not and integer filter
%               intfil = 1 if the filter is an integer filter
% b -- the numerator coefficients of the filter
% a -- the denomenator coefficients of the filter
%               a defaults to 1 for fir filters


fid = fopen(filfile, 'r');

a = 1.000; %default to fir

if fid ~= -1
     
	all = fscanf(fid, '%f'); %read in all numbers from file
    nums = all(1); %number of numerator coefficients
    firiir = all(2); %type indication: 0 if fir, 1 if iir
    intfil = all(3); %indicator: 1 if integer filter
    
    for i = 1:1:nums
        b(i) = all(i+3); %assign numerator coefficients
    end
    
    if firiir==1 %then is iir filter so has denominator coef
        dens = all(4+nums); %number of denominator coefficients
        
        for j = 1:1:dens
            a(j) = all(4+nums+j); %assign denominator coefficients
        end
    end
end

fclose(fid);
        
        
        