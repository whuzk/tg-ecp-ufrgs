clear

[firiir, intfil, b, a] = DigiFilRead('current.fil');

%these case statments show what firiir and intfil represent in the file
if firiir == 0
    filtype = 'fir'
else if firiir == 1
        filtype = 'iir'
    else filtype = 'unknown filter type'
    end
end
if intfil == 0
    isintfil = 'is not an integer filter'
else if intfil == 1
        isintfil = 'is an integer filter'
    else isintfil = 'unknown if integer filter'
    end
end

%the numerator coefficients and denominator coefficients
b
a

%write the file back out to filtest.fil
DigiFilWrite('filtest.fil', firiir, intfil, b, a);

%read it in to make sure it matches
[firiirIN, intfilIN, bIN, aIN] = DigiFilRead('filtest.fil');
bIN
aIN
