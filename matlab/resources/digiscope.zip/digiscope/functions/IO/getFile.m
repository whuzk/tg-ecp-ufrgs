function [ file, path, data ] = getFile(textBox)
%UNTITLED1 Summary of this function goes here
%   Detailed explanation goes here
[file, path] = uigetfile('*.txt')
data = [];
if ( file == 0 )
    return;
else
    set(textBox, 'string', [path,file]);  %and put the path and filename into the box
    try 
        data = load([path, file]);
    catch
        errordlg('There was an error in the get file function');
        return;
    end
    return;
end
