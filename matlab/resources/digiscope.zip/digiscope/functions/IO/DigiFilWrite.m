function DigiFilWrite(filfile, firiir, intfil, b, a)

%%%%% Function description %%%%%
% Function use --   write a .fil file in DigiScope filter file format.
%
% Inputs:
% filfile -- the file to be written
% firiir -- indicates whether the filter in the file is an fir or iir
%               firiir = 0 if the filter is an fir
%               firiir = 1 if the filter is an iir
% intfil -- indicates whether the filter in the file is an integer filter
%               intfil = 0 if the filter is not an integer filter
%               intfil = 1 if the filter is an integer filter
% b -- the numerator coefficients of the filter
% a -- the denomenator coefficients of the filter
%               a should be 1 for fir filters

fid = fopen(filfile, 'w'); %open file for writing

if fid ~= -1
    fprintf(fid, '%d\r\n', length(b)); %write number of num coefficients
    fprintf(fid, '%d\r\n', firiir); %write filter type fir or iir
    fprintf(fid, '%d\r\n', intfil); %write if integer filter
    for i = 1:1:length(b) %write numerator coefficients
        if i<length(b)
            fprintf(fid, '%f\t', b(i)); 
        else
            fprintf(fid, '%f\r\n', b(i));
        end
    end
    
    if length(a) > 1 %if there are denomintor coefficients then write them
        fprintf(fid, '%d\r\n', length(a)); %number of den coef if exist
        for j = 1:1:length(a)
            if j<length(a)
                fprintf(fid, '%f\t', a(j));
            else
                fprintf(fid, '%f\r\n', a(j));
            end
        end
    end
end

fclose(fid);
        