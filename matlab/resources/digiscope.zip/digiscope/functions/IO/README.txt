Very short description of functions (ie. arguments passed, parameters returned...). 
Detailed explanation can be found in the respective file.
**********************************************************************************

getFile(textBox):
Returns the file, path, and actual data and updates the textBox with the filepath/file
If the file name is empty, the function returns without doing anything.

