clear
%clf
%the function does not do anything if there is a error on the file yet
tem = DigiTemplRead('ECG1templ.txt');

a= tem.Name
b= tem.ID
c= tem.Datapoints
d= tem.Rate
e= tem.Data

DigiTemplWrite('TESTtempl.txt', tem);

t2 = DigiTemplRead('TESTtempl.txt');

a2= t2.Name
b2= t2.ID
c2= t2.Datapoints
d2= t2.Rate
e2= t2.Data
