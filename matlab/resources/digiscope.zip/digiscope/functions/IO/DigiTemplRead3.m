function templstruct = DigiTemplRead3(templfile)

%%%%% Function description %%%%%
% Function use --   read a given template txt file 
%
% Inputs:
% templfile -- the template file to be loaded
%
% Outpus:
% templstruct -- this is a struct containing the ASCII elements in the
%                   template.  The elements are: Name, ID, Datapoints,
%                   Rate, Data

fin = fopen(templfile,'r'); %open the given file for reading
if fin < 0
    error(['Could not open'+ templfile +'for reading']);
end

%Template files have the following format, restrictions are from previous
%       versions of digiscope
%Waveform Name (80 characters max.)
%Waveform ID number (1-12 are reserved; max. number 50)
%Number of Datapoints (32767 max.)
%Sample Rate of Signal (in Hz.�32767 max.)
%Data(1)
%Data(2) (the first and the last datapoints
%. must be the same baseline values)
%..
%Data(Number of Datapoints)
Datapoints = fscanf(fin, '%d', 1);
Data(Datapoints) = 0;

for i = 1 : 1 : Datapoints
    Data(i) = fscanf(fin, '%d', 1);
end

%This creates the structure to be returned
%The values can be referenced by name eg templstruct.Name
templstruct = struct( 'Datapoints', Datapoints,... 
    'Data', Data );

fclose(fin);
