function DigiDatWrite(datfile, headerstruct)

%%%%% Function description %%%%%
% Function use --   write a given .dat file in DigiScope format with
%                   a header portion and a data portion
% Inputs:
% datfile -- the file to be written, I do not force it to be type .dat yet
%
% headerstruct -- this is a struct containing the ASCII elements in the
%                   header.  The elements are: Title, Creator, Source,Type,
%                   VoltHigh, VoltLow, Step, Compress, Resolution,
%                   Rate, Channels, Samples, Chan
%                   the ecg data.  This is just a normal array variable.  The
%                   entire array is written to the file in binary format.

% first, check that the signal is 1D, and has a sample rate associated with
% it
if ~isfield(headerstruct,'data')
    errordlg('An invalid signal was passed!');
    return;
end
if numel(headerstruct.data) ~= length(headerstruct.data)
    errordlg('Data to be saved must be 1D');
    return;
end
if isempty(headerstruct.Rate)
    errordlg('The data has an invalid sample rate associated with it.');
    return;
end
headerstruct.Title = headerstruct.name;
headerstruct.Samples = num2str(length(headerstruct.data));
fid = fopen(datfile, 'w'); %open the file for writing

if fid < 0
    error(['Problem with file' + datfile + 'for writing']);
end

%Digiscope .dat file need to have this header structure at the top of file
fprintf(fid, 'Title:  %s\r\n', headerstruct.Title);
fprintf(fid, 'Creator:  %s\r\n', headerstruct.Creator);
fprintf(fid, 'Source:  %s\r\n', headerstruct.Source);
fprintf(fid, 'Type:  %s\r\n', headerstruct.Type);
fprintf(fid, 'VoltHigh:  %s\r\n', headerstruct.VoltHigh);
fprintf(fid, 'VoltLow:  %s\r\n', headerstruct.VoltLow);
fprintf(fid, 'Step:  %s\r\n', headerstruct.Step);
fprintf(fid, 'Compress:  %s\r\n', headerstruct.Compress);
fprintf(fid, 'Resolution:  %s\r\n', (headerstruct.Resolution));
fprintf(fid, 'Rate:  %s\r\n', num2str(headerstruct.Rate));
fprintf(fid, 'Channels:  %s\r\n', headerstruct.Channels);
fprintf(fid, 'Samples:  %s\r\n', headerstruct.Samples);
fprintf(fid, 'Chan:  %s\r\n\r\n', headerstruct.Chan);

convertback = 2^(str2num(headerstruct.Resolution)) / ...
    (str2num(headerstruct.VoltHigh) - str2num(headerstruct.VoltLow));

datar = int16(headerstruct.data * convertback);

isokin = fwrite(fid, transpose(datar), 'int16');

fclose(fid);