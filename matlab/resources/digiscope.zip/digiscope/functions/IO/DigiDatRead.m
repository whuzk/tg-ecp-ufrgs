function headerstruct = DigiDatRead(datfile)

%%%%% Function description %%%%%
% Function use --   read a given .dat file in DigiScope format into
%                   a header portion and a data portion
% Inputs:
% datfile -- the file to be loaded, it must be in standard Digiscope format
%
% Outpus:
% headerstruct -- this is a struct containing the ASCII elements in the
%                   header.  The elements are: Title, Creator, Source,Type,
%                   VoltHigh, VoltLow, Step, Compress, Resolution,
%                   Rate, Channels, Samples, Chan, datarray
%                   The ecg data is attached after all the header info

fin = fopen(datfile,'r'); %open the given file for reading
if fin < 0
    error(['Could not open'+ datfile +'for reading']);
end

isvalid = 1;

%DigiScope .dat files always have the same header so each line contains
%the same variable each time.  The fscanf removes the variable name and
%stores the value to be returned in headerstruct
buff = fscanf(fin, '%c', 8);
if (~strcmpi(buff, 'Title:  '))
    isvalid = 0;
end
Title = fgetl(fin);
buff = fscanf(fin, '%c', 10);
if (~strcmpi(buff, 'Creator:  '))
    isvalid = 0;
end
Creator = fgetl(fin);
buff = fscanf(fin, '%c', 9);
if (~strcmpi(buff, 'Source:  '))
    isvalid = 0;
end
Source = fgetl(fin);
buff = fscanf(fin, '%c', 7);
if (~strcmpi(buff, 'Type:  '))
    isvalid = 0;
end
Type = fgetl(fin);
buff = fscanf(fin, '%c', 11);
if (~strcmpi(buff, 'VoltHigh:  '))
    isvalid = 0;
end
VoltHigh = fgetl(fin);
buff = fscanf(fin, '%c', 10);
if (~strcmpi(buff, 'VoltLow:  '))
    isvalid = 0;
end
VoltLow = fgetl(fin);
buff = fscanf(fin, '%c', 7);
if (~strcmpi(buff, 'Step:  '))
    isvalid = 0;
end
Step = fgetl(fin);
buff = fscanf(fin, '%c', 11);
if (~strcmpi(buff, 'Compress:  '))
    isvalid = 0;
end
Compress = fgetl(fin);
buff = fscanf(fin, '%c', 13);
if (~strcmpi(buff, 'Resolution:  '))
    isvalid = 0;
end
Resolution = fgetl(fin);
buff = fscanf(fin, '%c', 7);
if (~strcmpi(buff, 'Rate:  '))
    isvalid = 0;
end
Rate = fgetl(fin);
buff = fscanf(fin, '%c', 11);
if (~strcmpi(buff, 'Channels:  '))
    isvalid = 0;
end
Channels = fgetl(fin);
buff = fscanf(fin, '%c', 10);
if (~strcmpi(buff, 'Samples:  '))
    isvalid = 0;
end
Samples = fgetl(fin);
buff = fscanf(fin, '%c', 7);
if (~strcmpi(buff, 'Chan:  '))
    isvalid = 0;
end
Chan = fgetl(fin);
%There is always a blank line between the header and the data
blank = fgetl(fin);

if(~isvalid)
    data = 0;
    errordlg('The selected file does not appear to be a valid digiscope file');
else
    %Load the ecg data to be returned
    %According to the DigiScope manual the data is always 16bit integers
    data = fread(fin,str2num(Samples),'int16');
end

data = transpose(data);

%DC2A Conversion
datar = data*(str2num(VoltHigh)-str2num(VoltLow))/(2^(str2num(Resolution)));
%datar = datar*.00244140265;
%This creates the header structure to be returned
%The values can be referenced by name eg headerstruct.Title
headerstruct = struct('Title', Title, 'Creator', Creator, 'Source', Source,... 
    'Type', Type, 'VoltHigh', VoltHigh, 'VoltLow', VoltLow, 'Step', Step,... 
    'Compress', Compress, 'Resolution', Resolution, 'Rate', str2double(Rate),...
    'Channels', Channels, 'Samples', Samples, 'Chan', Chan,...
    'data', datar, 'dataint', data);

fclose(fin);
