%------------------------------------------------
function [filters, outstr, str, err] = updateFilterChain(filters, updateScroll, startT, timeLength)

if isempty(filters) || isempty(filters{1})
    curSignal = [];
else
    curSignal = filters{1};
    if isempty(curSignal.data)
        curSignal=[];
    else
        curSignal.totalDelay = 0;
    end
end

str = [];
outstr = [];
err = 0;
for i=1:length(filters)
    if isempty(curSignal) && filters{i}.sigreqd
        outstr{end+1} = sprintf('Input signal required for filter #%d',i);
        err=1;
    end
    if err
        str{i} = filters{i}.name;
        continue;
    end
    try
        filters{i}.totalDelay = filters{i}.delay + curSignal.totalDelay;
        if isfield(curSignal, 'atrtime')
            filters{i}.atrtime = curSignal.atrtime;
        end
        if updateScroll
            if filters{i}.updateWindow == 0
                % nothing needs to be done, the signal will be passed on
                % below
            else
                filters{i} = eval(sprintf('%s(''calc'', filters{i}, curSignal)',...
                    filters{i}.funcName));
            end
        else
            filters{i} = eval(sprintf('%s(''calc'', filters{i}, curSignal)',...
                filters{i}.funcName));
        end
        if filters{i}.scroll
            filters{i}.plotRange = round(([0 timeLength] + startT)*filters{i}.Rate)+1;
        end
        
%         if filters{i}.updateWindow == 1
%             curSignalTmp = curSignal;
%             range = round(filters{i}.Rate*([0:1/filters{i}.Rate:timeLength]+startT))+1;
%             while range(end) > length(curSignalTmp.data) range = range-1; end
%             while range(1) < 1 range = range+1; end
%             curSignalTmp.data = curSignalTmp.data(range);
%             filters{i} = eval(sprintf('%s(''calc'', filters{i}, curSignalTmp)',...
%                 filters{i}.funcName));
%             clear curSignalTmp;
%         elseif doWindowed == 0
%             filters{i} = eval(sprintf('%s(''calc'', filters{i}, curSignal)',...
%                 filters{i}.funcName));
%         end
    catch
        outstr{end+1} = ['Error processing ', filters{i}.name,': ', lasterr];
        err = 1;
    end
    if filters{i}.passthrough
        curSignal = filters{i};
        
    end
    if ~isempty(filters{i}.output)
        outstr{end+1} = filters{i}.output;
    end
    str{i} = filters{i}.name;
    
end
