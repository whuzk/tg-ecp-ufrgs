function TH= getTransfer(MR, PR, PL, ZL, TH)
%take lists and generate numbers for each entry
%Then generate cartesian values for each polar entry

    global X;

    CartesPole=[];
    CartesZero=[];

    tempp = size(PL);
    tempz = size(ZL);

    PLsize = tempp(1);
    ZLsize = tempz(1);

    tempp=isempty(PL);
    tempz=isempty(ZL);
    
    if tempp == 0    
        for i=1:PLsize
            temp = str2num(PL{i});
            tempR = temp(1);
            tempAng = temp(2);
            tempT=tempAng/360*2*pi;
            CartesPole(i,1)=tempR*cos(tempT); %x value
            CartesPole(i,2)=j*tempR*sin(tempT); %y value  
        end
    end
 
     if tempz == 0   
        for i=1:ZLsize
            temp = str2num(ZL{i});
            tempR = temp(1);
            tempAng = temp(2);
            tempT=tempAng/360*2*pi;
            CartesZero(i,1)=tempR*cos(tempT); %x value
            CartesZero(i,2)=j*tempR*sin(tempT); %y value  
        end
     end
 
 %%%%%%%%%%%Generate Pole Equation%%%%%%%%%%%%%%%%%%%
 
  A=size(CartesPole);
  B=size(CartesZero);
  PoleEq = [];
  ZeroEq = [];
  if A(1)> 0
    for i=1:A(1)
        PoleEq(i) = CartesPole(i,1)+CartesPole(i,2);
    end
  end    
  if B(1)> 0
    for i=1:B(1)
        ZeroEq(i) = CartesZero(i,1)+CartesZero(i,2);
    end
  end

    a = poly(PoleEq);
    b = poly(ZeroEq);
    returnthing = [a,b];

    %graph the magnitude response
    fs=200;
    n=512;
    [h,f]=freqz(b,a,n,fs);
    axes(MR);
    plot(f,20.*log10(abs(h)));
    
    %graph the phase response
    axes(PR);
    P = angle(h);
    yminpr=min(P);
    ymaxpr=max(P);
    plot(f,P);
    axis([0 100 -pi-.2 pi+.2]);
    %output transfer function
    TH = transferOut(a,b,TH);
    
    
    
    
