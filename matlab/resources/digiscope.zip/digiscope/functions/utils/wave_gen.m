function varargout = wave_gen(varargin)
% WAVE_GEN M-file for wave_gen.fig
%      WAVE_GEN, by itself, creates a new WAVE_GEN or raises the existing
%      singleton*.
%
%      H = WAVE_GEN returns the handle to a new WAVE_GEN or the handle to
%      the existing singleton*.
%
%      WAVE_GEN('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in WAVE_GEN.M with the given input arguments.
%
%      WAVE_GEN('Property','Value',...) creates a new WAVE_GEN or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before wave_gen_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to wave_gen_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Copyright 2002-2003 The MathWorks, Inc.

% Edit the above text to modify the response to help wave_gen

% Last Modified by GUIDE v2.5 23-Aug-2008 23:32:07

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @wave_gen_OpeningFcn, ...
                   'gui_OutputFcn',  @wave_gen_OutputFcn, ...
                   'CloseRequestFcn',@wave_gen_CloseRequestFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before wave_gen is made visible.
function wave_gen_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to wave_gen (see VARARGIN)
% Choose default command line output for wave_gen
%handles.output = hObject;
handles.sig = [];
handles.headerstruct = [];
handles.output = [];
handles.is_valid = 0;
handles.export_button_clicked = false;
set(handles.wave_gen,'CloseRequestFcn',@wave_gen_CloseRequestFcn)
% Update handles structure
guidata(hObject, handles);
%turn off annoying warnings..
warning('off')

% Make the GUI modal
set(handles.wave_gen,'WindowStyle','modal')

%make visible
uiwait(hObject);


% --- Outputs from this function are returned to the command line.
function varargout = wave_gen_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
% if (isempty(handles) == 0)
%     if (handles.is_valid == 1)
%         if nargout > 0
%             handles.output = handles.headerstruct;
%             varargout{1} = handles.output;
%             delete(hObject);
%         end
%     else
%         errordlg('There is nothing to export!');
%         varagout = [];
%         return;
%     end
% else
%     varargout{1} = [];
% end
varargout{1} = handles.output;
delete(hObject);
%uiresume(gcf)

% --- Executes on button press in gen_button.
function gen_button_Callback(hObject, eventdata, handles)
% hObject    handle to gen_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
axes(handles.axes1);
%get all values
sample_rate = str2double(get(handles.sample_edit, 'String'));
pts = str2double(get(handles.pts_edit, 'String'));
res = str2double(get(handles.res_edit, 'String'));
ph = str2num(get(handles.phaseBox,'string'));
amp = str2num(get(handles.ampBox,'string'));

f = str2double(get(handles.freq_edit, 'String'));

addMode = 0;
if get(handles.overwriteRadio,'value') addMode = 1;
elseif get(handles.addRadio,'value') addMode = 2;
elseif get(handles.multiplyRadio,'value') addMode = 3;
end

%and check
if isempty(ph) || abs(ph) > pi
    errordlg('Phase must be -pi <= phase <= pi');
    return;
end
if ( isnan(sample_rate) || isnan(pts) || isnan(res) || isnan(f) ||...
     sample_rate < 0 || pts < 0 || res < 0 || f < 0 )
    errordlg('Invalid input');
    handles.is_valid = 0;
    return;
end

% now check that the signals are compatible, if a previous one exists and
% addmode > 1
if addMode > 1
    if ~isempty(handles.headerstruct)
        if handles.headerstruct.Rate ~= sample_rate ||...
            handles.headerstruct.Samples ~= pts ||...
            handles.headerstruct.Resolution ~= res
            errordlg('The sample rate, # samples, and resolution must be equal for adding/multiplying signals');
            return;
        end            
    end
end
t = [0 : 1/sample_rate : (pts-1)/sample_rate];
    
popup_sel_index = get(handles.wave_popup, 'Value');
switch popup_sel_index

    case 1
        %create sine
        sig = (amp*sin(2*pi*f*t + ph));
    case 2
        %create square wave
        sig = amp*square(2*pi*f*t + ph);
    case 3
        %create triangle
        %the vector d defines how many times to repeat...
        %d = [0 : 1/f : (pts-1)/f];
        %sig = amp * (pulstran(t,d, 'tripuls', 1/f)-1/2);
        sig = amp*sawtooth(2*pi*t*f + ph, 0.5);
    case 4
        %create impulse
        sig = amp*[0, 0, 0, 0, 1, zeros(1,pts-5)];
    case 5
        sig = amp*[0 0 0 0 ones(1,pts-4)];
end

%calculate the quantization
quant = 2^res-1;

%quantize signal
sig = floor(sig/quant^-1)*quant^-1 + (quant^-1)/2;

% if a signal already exists, add the new one to it
switch addMode
    case 1
        handles.sig = sig;
    case 2
        handles.sig = handles.headerstruct.data + sig;
    case 3
        handles.sig = handles.headerstruct.data.*sig;
    otherwise
        handles.sig = sig;
end

%and plot it
plot(handles.axes1, t, handles.sig);
ylabel('Amplitude');
xlabel('Time (in sec.)');
axis([0 1 min(handles.sig) max(handles.sig)]);
handles.is_valid = 1;
handles.headerstruct = getHeader(hObject, eventdata, handles);
guidata(hObject, handles);

% --------------------------------------------------------------------
function FileMenu_Callback(hObject, eventdata, handles)
% hObject    handle to FileMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function OpenMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to OpenMenuItem (see GCBO)
%eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[file, path] = uigetfile('*.wave');
if ~isequal(file, 0)
    %sig = load('-ascii', [path file]);
    handles.headerstruct = DigiDatRead([path file]);
    handles.sig = handles.headerstruct.datarray;
    plot(handles.axes1, handles.sig(1:end));
    ylabel('Amplitude');
    xlabel('Time (in sec.)');
    handles.is_valid = 1;
end
guidata(hObject, handles);

    
% --------------------------------------------------------------------
function PrintMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to PrintMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
printdlg(handles.wave_gen)

% --------------------------------------------------------------------
function CloseMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to CloseMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection = questdlg(['Close ' get(handles.wave_gen,'Name') '?'],...
                     ['Close ' get(handles.wave_gen,'Name') '...'],...
                     'Yes','No','Yes');
if strcmp(selection,'No')
    return;
end
uiresume(gcf);
set(hObject,'Visible','off');
delete(handles.wave_gen)


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1



% --- Executes on selection change in wave_popup.
function wave_popup_Callback(hObject, eventdata, handles)
% hObject    handle to wave_popup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns wave_popup contents as cell array
%        contents{get(hObject,'Value')} returns selected item from wave_popup


% --- Executes during object creation, after setting all properties.
function wave_popup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to wave_popup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function freq_edit_Callback(hObject, eventdata, handles)
% hObject    handle to freq_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of freq_edit as text
%        str2double(get(hObject,'String')) returns contents of freq_edit as
%        a double


% --- Executes during object creation, after setting all properties.
function freq_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to freq_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function sample_edit_Callback(hObject, eventdata, handles)
% hObject    handle to sample_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sample_edit as text
%        str2double(get(hObject,'String')) returns contents of sample_edit as a double


% --- Executes during object creation, after setting all properties.
function sample_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sample_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function pts_edit_Callback(hObject, eventdata, handles)
% hObject    handle to pts_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of pts_edit as text
%        str2double(get(hObject,'String')) returns contents of pts_edit as a double


% --- Executes during object creation, after setting all properties.
function pts_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pts_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function res_edit_Callback(hObject, eventdata, handles)
% hObject    handle to res_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of res_edit as text
%        str2double(get(hObject,'String')) returns contents of res_edit as a double


% --- Executes during object creation, after setting all properties.
function res_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to res_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in noise_popup.
function noise_popup_Callback(hObject, eventdata, handles)
% hObject    handle to noise_popup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns noise_popup contents as cell array
%        contents{get(hObject,'Value')} returns selected item from noise_popup


% --- Executes during object creation, after setting all properties.
function noise_popup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to noise_popup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function amplitude_edit_Callback(hObject, eventdata, handles)
% hObject    handle to amplitude_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of amplitude_edit as text
%        str2double(get(hObject,'String')) returns contents of amplitude_edit as a double


% --- Executes during object creation, after setting all properties.
function amplitude_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to amplitude_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --------------------------------------------------------------------
function save_menu_Callback(hObject, eventdata, handles)
% hObject    handle to save_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[FileName,PathName] = uiputfile('*.wave', 'Save Wave as...');
handles.headerstruct = getHeader(hObject, eventdata, handles);
if ( (FileName ~= 0))
    DigiDatWrite([PathName FileName], handles.headerstruct);
end
guidata(hObject,handles);

% --------------------------------------------------------------------
function headerstruct = getHeader(hObject, eventdata, handles)

switch get(handles.wave_popup, 'Value')
    case 1
        title = 'Sine Wave';
    case 2
        title = 'Square Wave';
    case 3
        title = 'Triangle Wave';
    case 4
        title = 'Unit Impulse';
    case 5 
        title = 'Step Function';
end
       
   
headerstruct.Title = title;
headerstruct.Creator = 'Digiscope';
headerstruct.Source = '';
headerstruct.Type = '';
headerstruct.VoltHigh = max(handles.sig); %handles.A;
headerstruct.VoltLow = min(handles.sig);;
headerstruct.Step = '';
headerstruct.Compress = 'No';
headerstruct.Resolution = str2num(get(handles.res_edit, 'String'));
headerstruct.Rate = str2num(get(handles.sample_edit, 'String'));
headerstruct.Channels = 1;
headerstruct.Samples = str2num(get(handles.pts_edit, 'String'));
headerstruct.Chan = 1;
headerstruct.data = handles.sig; %substruct('.', handles.sig);

guidata(hObject, handles);

% --- Executes on button press in export_button.
function export_button_Callback(hObject, eventdata, handles)
% hObject    handle to export_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.output = handles.headerstruct;
guidata(hObject, handles);
uiresume(handles.wave_gen);

function wave_gen_CloseRequestFcn(hObject, eventdata, handles)
%uiresume(gcf)
selection = questdlg(['Do you really want to close?'...
                       ' No changes will be saved.'],...
                     ['Really close?'],...
                     'Yes','No','Yes');
if strcmp(selection,'No')
    return;
end
handles.output = [];
guidata(hObject,handles);
uiresume(hObject);



% --- Executes on button press in overwriteRadio.
function overwriteRadio_Callback(hObject, eventdata, handles)
% hObject    handle to overwriteRadio (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of overwriteRadio

if get(hObject,'value') == 0 set(hObject,'value',1); end
guidata(hObject, handles);


% --- Executes on button press in addRadio.
function addRadio_Callback(hObject, eventdata, handles)
% hObject    handle to addRadio (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of addRadio
if get(hObject,'value') == 0 set(hObject,'value',1); end
guidata(hObject, handles);


% --- Executes on button press in multiplyRadio.
function multiplyRadio_Callback(hObject, eventdata, handles)
% hObject    handle to multiplyRadio (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of multiplyRadio

if get(hObject,'value') == 0 set(hObject,'value',1); end
guidata(hObject, handles);



function ampBox_Callback(hObject, eventdata, handles)
% hObject    handle to ampBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ampBox as text
%        str2double(get(hObject,'String')) returns contents of ampBox as a double


% --- Executes during object creation, after setting all properties.
function ampBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ampBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function dynRangeBox_Callback(hObject, eventdata, handles)
% hObject    handle to dynRangeBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of dynRangeBox as text
%        str2double(get(hObject,'String')) returns contents of dynRangeBox as a double


% --- Executes during object creation, after setting all properties.
function dynRangeBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dynRangeBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function phaseBox_Callback(hObject, eventdata, handles)
% hObject    handle to phaseBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of phaseBox as text
%        str2double(get(hObject,'String')) returns contents of phaseBox as a double


% --- Executes during object creation, after setting all properties.
function phaseBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to phaseBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function gen_button_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gen_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


