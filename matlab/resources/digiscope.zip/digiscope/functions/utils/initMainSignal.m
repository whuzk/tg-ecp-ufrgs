function varargout = initMainSignal(varargin)

switch(varargin{1})
    case 'name'
        varargout{1} = 'Signal';
        return;
    case 'filtdat'
        filtdat = genericFiltDat;
        filtdat.passthrough = 1;
        filtdat.funcName = 'initMainSignal';
        filtdat.scroll = 1;
        filtdat.numPlots = 1;
        filtdat.plot = 1;
        filtdat.name = 'SIGNAL';
        if nargin == 2 && isstruct(varargin{2})            
            %merge the signals
            signalFields = fieldnames(varargin{2});
            for i=1:length(signalFields)
                filtdat = setfield(filtdat,signalFields{i},getfield(varargin{2},signalFields{i}));
            end
        end
        varargout{1} = filtdat;
        return;
    case 'config'
        varargout{1} = varargin{2};
        return;
    case 'calc'
        %signal = varargin{2};
        filtdat = varargin{3};
        filtdat.t = (0:length(filtdat.data)-1)/filtdat.Rate;
        varargout{1} = filtdat;
    case 'plot'
        filtdat = varargin{2};
        if isempty(filtdat.data) return; end
        axes(filtdat.axes(1));        
        plot(filtdat.t, filtdat.data,'color',[0 0 0]);
        return;
end


