function varargout = template_gen(varargin)
% TEMPLATE_GEN M-file for template_gen.fig
%      TEMPLATE_GEN, by itself, creates a new TEMPLATE_GEN or raises the existing
%      singleton*.
%
%      H = TEMPLATE_GEN returns the handle to a new TEMPLATE_GEN or the handle to
%      the existing singleton*.
%
%      TEMPLATE_GEN('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TEMPLATE_GEN.M with the given input arguments.
%
%      TEMPLATE_GEN('Property','Value',...) creates a new TEMPLATE_GEN or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before template_gen_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to template_gen_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help template_gen

% Last Modified by GUIDE v2.5 08-May-2008 10:44:53

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @template_gen_OpeningFcn, ...
    'gui_OutputFcn',  @template_gen_OutputFcn, ...
    'CloseRequestFcn',@template_gen_CloseRequestFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before template_gen is made visible.
function template_gen_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to template_gen (see VARARGIN)

handles.full_signal = []; % A loaded Digiscope file
handles.loaded_template = [];
handles.sig_generated = 0;
handles.output = [];
handles.is_valid = 0; % Determines whether the user generated a signal
handles.template = [];  % The template to repeat, loaded or user chosen

set(handles.figure1,'CloseRequestFcn',@template_gen_CloseRequestFcn)
guidata(hObject, handles);

%turn off annoying warnings...
warning('off');
%make visible


% Make the GUI modal
set(handles.figure1,'WindowStyle','modal');


set(handles.figure1, 'Visible', 'on');
waitfor(handles.figure1, 'Visible');

% UIWAIT makes template_gen wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = template_gen_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Check if we have a valid signal to export, or if the user clicked the
% red 'X' to exit the signal generator without exporting.  If they chose
% to export without creating a signal, the same behavior follows and a
% null object is passed back to the caller
if (isempty(handles) == 0)
    if (handles.is_valid > 0 )
        if nargout > 0
            handles.output = handles.full_signal;
            varargout{1} = handles.output;
            delete(hObject);
        end
    else
        varargout{1} = [];
        delete(hObject);
    end
else
    varargout{1} = [];
end
uiresume(gcf);


% --- Executes on button press in import_temp_button.
function import_temp_button_Callback(hObject, eventdata, handles)
% hObject    handle to import_temp_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[inputfile, pathname] = uigetfile( ...
    {'*.txt','Template Files (*.txt)';
    }, ...
    'Select a Template file', ...
    '..\templatefiles'); %this is hard coded to look for the path

%if no filemenu is select. ie. cancel button clicked
if ( inputfile ~= 0 )
    handles.loaded_template = DigiTemplRead([pathname,inputfile]);
    handles.is_valid = 2;  %if the user picks a file, continue
end

handles.template = handles.loaded_template.Data;

%DC2A conversion
vrange = handles.loaded_template.VoltHigh - handles.loaded_template.VoltLow;

adc_scale = vrange/(2^handles.loaded_template.Resolution);
handles.template = handles.template*adc_scale/handles.loaded_template.ScaleFactor;

%change it into a valid signal, like we expect
handles.full_signal.Title = handles.loaded_template.Name;
handles.full_signal.Creator = 'unknown';
handles.full_signal.Source = 'unknown';
handles.full_signal.Type = 'Template Generated Signal';
handles.full_signal.Step = '0';
handles.full_signal.Resolution = '12';
handles.full_signal.Rate = handles.loaded_template.Rate;
handles.full_signal.Channels = '1';
handles.full_signal.Samples = '5120';
handles.full_signal.Chan = '0  Gain  1.000000  Ofst  0.000000  Type  (null)';
handles.full_signal.VoltHigh = int2str(handles.loaded_template.VoltHigh);
handles.full_signal.VoltLow = int2str(handles.loaded_template.VoltLow);

figure();
h = gca;
plot(h, handles.template);
%set(h, 'XTickLabel', [left:10:right]);

guidata(hObject, handles);


% --- Executes on button press in open_digiscope_button.
function open_digiscope_button_Callback(hObject, eventdata, handles)

% If the user doesn't want to use one of the selected Digiscope template
% files to generate a signal, let them select a new template from an
% existing digiscope file
[inputfile, pathname] = uigetfile( ...
    {'*.dat','DigiScope Files (*.dat)';
    }, ...
    'Select a Digiscope file', ...
    '..\ecgFiles\datfiles'); %this is hard coded to look for the path

%if no filemenu is select. ie. cancel button clicked
if ( inputfile ~= 0 )
    handles.full_signal = DigiDatRead([pathname,inputfile]);
    handles.is_valid = 1;  %if the user picks a file, continue
end

linkaxes([handles.axes1],'x');
axes(handles.axes1);
cla;

% Plot the signal loaded from the Digiscope file
handles.plot.time = (0:length(handles.full_signal.data)-1)/handles.full_signal.Rate;
plot(handles.plot.time,handles.full_signal.data);

%plot(handles.full_signal.data);
guidata(hObject,handles);
% hObject    handle to open_digiscope_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in ok_go.
function ok_go_Callback(hObject, eventdata, handles)
% hObject    handle to ok_go (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if handles.sig_generated == 0
    msgbox('Generate a signal to export','Notice');
    return;
else
    guidata(hObject, handles);
    set(handles.figure1,'Visible', 'off');
end

% --- Executes on button press in pick_template_button.
function pick_template_button_Callback(hObject, eventdata, handles)
if(isempty(handles.full_signal))
    msgbox('You must load a Digiscope file to select a template','Warning');
else

    axes(handles.axes1);
    x = ginput(2);
    x = sort(x);
    left = x(1);
    right = x(2);
    left = round(left*handles.full_signal.Rate)+1;
    if left < 0
        left = 0;
    end

    right = round(right*handles.full_signal.Rate)+1;
    handles.template = handles.full_signal.data(left:right);


    % Select a template from the digiscope signal
    %  [left, right] = curs(hObject, eventdata, handles);
    % handles.template = handles.full_signal.data(left:right);

    %plot the template in a new window
    figure();
    h = gca;
    plot(h, handles.template);
    set(h, 'XTickLabel', [left:10:right]);

    % Now we have a valid template to generate
    handles.template_valid = 1;
end
guidata(hObject, handles);
% hObject    handle to pick_template_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


function delay_btw_peaks_box_Callback(hObject, eventdata, handles)
% hObject    handle to delay_btw_peaks_box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of delay_btw_peaks_box as text
%        str2double(get(hObject,'String')) returns contents of delay_btw_peaks_box as a double


% --- Executes during object creation, after setting all properties.
function delay_btw_peaks_box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to delay_btw_peaks_box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% This function handles for when the user clicks on the red 'X'
function template_gen_CloseRequestFcn(hObject, eventdata, handles)

uiresume(gcf);
set(hObject,'Visible','off');
delete(hObject);


% --- Executes on button press in gen_sig_button.
function gen_sig_button_Callback(hObject, eventdata, handles)

% Check if handles.template is valid before we attempt to generate a sig.
if(isempty(handles.template))
    msgbox('You must load a template or select it from a Digiscope file before generating a signal','Warning');
else

    if handles.is_valid > 0
        handles.sig_generated = 1;
        period_len = (str2num(get(handles.delay_btw_peaks_box, 'String'))*handles.full_signal.Rate)/1000;

        % Determine how many points the user selected for the template
        template_len = length(handles.template);

        % If the selected period is less than the template length, set the
        % period to the template length
        if period_len < template_len
            template_wave = handles.template;
            for j=1:(5120/template_len)
                template_wave = cat(2,template_wave,handles.template);
            end
        else
            %difference in period and template
            len_diff = period_len - template_len;
            %difference in height
            height_diff = handles.template(1) - handles.template(template_len);
            x = [1:len_diff];
            scale = (len_diff.^2)/height_diff; %scale difference

            if height_diff > 0 %curve up
                curve_bit = (x.^2)/scale + handles.template(template_len);
            else %curve down
                x = x(end:-1:1);
                curve_bit = (x.^2)/(-scale) + handles.template(1);
            end

            template_wave = cat(2,handles.template,curve_bit);
            template_wave2 = template_wave;

            for j=1:(5120/period_len)
                template_wave = cat(2,template_wave, template_wave2);
            end
        end

        handles.full_signal.data = template_wave(1:5120);

        linkaxes([handles.axes1],'x');
        axes(handles.axes1);


        handles.plot.time = (0:length(handles.full_signal.data)-1)/handles.full_signal.Rate;
        plot(handles.plot.time,handles.full_signal.data);


        %     plot(handles.full_signal.data);
    end
end
guidata(hObject, handles);

% hObject    handle to gen_sig_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --- Executes on button press in zoom_button.
function zoom_button_Callback(hObject, eventdata, handles)
% hObject    handle to zoom_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
zoom;



function max_volt_Callback(hObject, eventdata, handles)
% hObject    handle to max_volt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of max_volt as text
%        str2double(get(hObject,'String')) returns contents of max_volt as a double


% --- Executes during object creation, after setting all properties.
function max_volt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to max_volt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function min_volt_Callback(hObject, eventdata, handles)
% hObject    handle to min_volt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of min_volt as text
%        str2double(get(hObject,'String')) returns contents of min_volt as a double


% --- Executes during object creation, after setting all properties.
function min_volt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to min_volt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sampling_rate_Callback(hObject, eventdata, handles)
% hObject    handle to sampling_rate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sampling_rate as text
%        str2double(get(hObject,'String')) returns contents of sampling_rate as a double


% --- Executes during object creation, after setting all properties.
function sampling_rate_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sampling_rate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resolution_size_Callback(hObject, eventdata, handles)
% hObject    handle to resolution_size (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resolution_size as text
%        str2double(get(hObject,'String')) returns contents of resolution_size as a double


% --- Executes during object creation, after setting all properties.
function resolution_size_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resolution_size (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in get_data_pts.
function get_data_pts_Callback(hObject, eventdata, handles)
% hObject    handle to get_data_pts (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[inputfile, pathname] = uigetfile( ...
    {'*.txt','Data Text Files (*.txt)';
    }, ...
    'Select a Data Text file', ...
    '..\rawdata'); %this is hard coded to look for the path

%if no filemenu is select. ie. cancel button clicked
if ( inputfile ~= 0 )
    handles.loaded_template = DigiTemplRead3([pathname,inputfile]);
    handles.is_valid = 3;  %if the user picks a file, continue
end

%if handles.is_valid == 3

%handles.template = handles.loaded_template.Data;
%maximum_volt = str2num(get(handles.max_volt, 'String'));
%minimum_volt = str2num(get(handles.min_volt, 'String'));
%sampling_rate = str2num(get(handles.sampling_rate, 'String'));
%res_scale = str2num(get(handles.resolution_size, 'String'));

%end
%DC2A conversion
%vrange = maximum_volt - minimum_volt;

%adc_scale = vrange/(2^res_scale);
%handles.template = handles.template*adc_scale; % /handles.loaded_template.ScaleFactor;

%change it into a valid signal, like we expect
%handles.full_signal.Title = get(handles.edit_name, 'String');
%handles.full_signal.Creator = 'unknown';
%handles.full_signal.Source = 'unknown';
%handles.full_signal.Type = 'Template Generated Signal';
%handles.full_signal.Step = '0';
%handles.full_signal.Resolution = get(handles.resolution_size, 'String');
%handles.full_signal.Rate = get(handles.sampling_rate, 'String');
%handles.full_signal.Channels = '1';
%handles.full_signal.Samples = '5120';
%handles.full_signal.Chan = '0  Gain  1.000000  Ofst  0.000000  Type  (null)';
%handles.full_signal.VoltHigh = get(handles.max_volt, 'String');
%handles.full_signal.VoltLow =get(handles.min_volt, 'String');


%figure();
%    h = gca;
%    plot(h, handles.template);

guidata(hObject, handles);




function edit_name_Callback(hObject, eventdata, handles)
% hObject    handle to edit_name (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_name as text
%        str2double(get(hObject,'String')) returns contents of edit_name as a double


% --- Executes during object creation, after setting all properties.
function edit_name_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_name (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes on button press in gen_new_template.
function gen_new_template_Callback(hObject, eventdata, handles)
% hObject    handle to gen_new_template (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if handles.is_valid == 3

    handles.template = handles.loaded_template.Data;
    maximum_volt = str2num(get(handles.max_volt, 'String'));
    minimum_volt = str2num(get(handles.min_volt, 'String'));
    sampling_rate = str2num(get(handles.sampling_rate, 'String'));
    res_scale = str2num(get(handles.resolution_size, 'String'));


    %DC2A conversion
    vrange = maximum_volt - minimum_volt;

    adc_scale = vrange/(2^res_scale);
    handles.template = handles.template*adc_scale; % /handles.loaded_template.ScaleFactor;

    %change it into a valid signal, like we expect
    handles.full_signal.Title = get(handles.edit_name, 'String');
    handles.full_signal.Creator = 'unknown';
    handles.full_signal.Source = 'unknown';
    handles.full_signal.Type = 'Template Generated Signal';
    handles.full_signal.Step = '0';
    handles.full_signal.Resolution = get(handles.resolution_size, 'String');
    handles.full_signal.Rate = str2num(get(handles.sampling_rate, 'String'));
    handles.full_signal.Channels = '1';
    handles.full_signal.Samples = '5120';
    handles.full_signal.Chan = '0  Gain  1.000000  Ofst  0.000000  Type  (null)';
    handles.full_signal.VoltHigh = get(handles.max_volt, 'String');
    handles.full_signal.VoltLow =get(handles.min_volt, 'String');


    figure();
    h = gca;
    plot(h, handles.template);
    %set(h, 'XTickLabel', [left:10:right]);
end
guidata(hObject, handles);
