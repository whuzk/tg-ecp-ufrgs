function [ output_data ] = compress_tp( input_data )
%TURNING_POINT Summary of this function goes here
%   Detailed explanation goes here

% Remember the turning point results
% Always save the first data point
x0 = input_data(1);
output_data = [x0];

i = 2;
while (i < length(input_data))
    x1 = input_data(i);
    x2 = input_data(i+1);
    
    s1 = sign(x1 - x0);
    s2 = sign(x2 - x1);
 
    if ( ~s1 || (s1 + s2) )
        x0 = x2;
        output_data = [output_data; x2];
        i = i + 2;
    else
        x0 = x1;
        output_data = [output_data; x1];
        i = i + 2;        
    end
end