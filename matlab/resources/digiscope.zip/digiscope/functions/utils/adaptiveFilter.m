function ydata = adaptiveFilter(signal, fs, d)

Ns = length(signal); % sample count
omega = 120*pi;
N = cos(omega/fs);

% run adaptive filter algorithm
A=0;
e_last = A*sin(0);
e_now = A*sin(omega/fs);
ydata(1)=signal(1);
for i=2:Ns-1
  e_next = 2*N*e_now-e_last;
  f_next = signal(i+1)-e_next-(signal(i)-e_now);
  if f_next>0
      e_next = e_next+d;
  else 
      if f_next<0 
          e_next = e_next-d;
      end;
  end;
  ydata(i+1) = signal(i+1)-e_next;
  e_last = e_now;
  e_now = e_next;
end;


