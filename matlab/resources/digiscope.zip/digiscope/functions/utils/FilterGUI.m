function varargout = FilterGUI(varargin)
% FILTERGUI M-file for FilterGUI.fig
%      FILTERGUI, by itself, creates a new FILTERGUI or raises the existing
%      singleton*.
%
%      H = FILTERGUI returns the handle to a new FILTERGUI or the handle to
%      the existing singleton*.
%
%      FILTERGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FILTERGUI.M with the given input arguments.
%
%      FILTERGUI('Property','Value',...) creates a new FILTERGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before FilterGUI_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to FilterGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help FilterGUI

% Last Modified by GUIDE v2.5 23-Oct-2008 09:11:26

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @FilterGUI_OpeningFcn, ...
    'gui_OutputFcn',  @FilterGUI_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before FilterGUI is made visible.
function FilterGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to FilterGUI (see VARARGIN)
% Choose default command line output for sigproPopUp
handles = setupDefaultFilters(handles);
handles = initGUI(handles);
handles.filter = [];
handles.TFtext = [];
handles.TFdispMode = 1;
handles.zeroPlace = [];
handles.polePlace = [];
handles.output = [];
if nargin == 4
    handles.Rate = varargin{1}.Rate;
    if ~isempty(varargin{1}.zeros)
        try
            handles.currentFilter = varargin{1};
            handles.Rate = handles.currentFilter.Rate;
            handles.currentFilterNum = handles.currentFilter.filterNum;
            set(handles.FilterSelect,'value',handles.currentFilterNum);
            handles = updateFilter(handles);
            if handles.currentFilter.filterNum == handles.custFiltNum
                handles.currentFilter = varargin{1};
                handles = changeFilterType(handles, handles.currentFilter.filterType);
                set(handles.filterTypeCombo,'value',handles.currentFilter.filterType);
                switch handles.currentFilter.filterType
                    case 1
                        set(handles.filterZerosBox,'string',num2str(handles.currentFilter.zeros));
                        set(handles.filterPolesBox,'string',num2str(handles.currentFilter.poles));
                    case 2
                        handles.currentFilter = varargin{1};
                        set(handles.freqSampleCombo,'value',handles.currentFilter.freqSampleMode);
                        set(handles.freqSampleInputBox,'string',num2str(handles.currentFilter.freqSampleResp));
                        handles.currentFilter.poles = 1;
                        
                        resp = 10.^(handles.currentFilter.freqSampleResp/20);

                        if rem(length(resp),2) == 1
                            resp(end+1) = 0;
                            order = length(resp);
                            space = 180/(length(resp)-1.5);
                            f = [0:space:180]/180;
                            f(end+1) = 1;
                            handles.currentFilter.zeros = firls((length(f)-2)*2,f,resp);
                        else
                            order = length(resp);
                            space = 180/(length(resp)-.5);
                            f = [0:space:180]/180;
                            handles.currentFilter.zeros = firls((length(f)-1)*2,f,resp);
                        end
                        set(handles.polesBox,'string',num2str(handles.currentFilter.poles,1));
                        set(handles.zerosBox,'string',num2str(handles.currentFilter.zeros,1)); 

                        switch handles.currentFilter.freqSampleMode
                            case 1 % polar
                                f = f*180;
                                %set(handles.freqSampleFreqBox,'string',num2str(f*180));
                            case 2 % freq
                                f = f*handles.Rate/2;
                                %set(handles.freqSampleFreqBox,'string',num2str());
                            case 3 % normalized
                                f = f/2;
                                %set(handles.freqSampleFreqBox,'string',num2str(f/2));
                        end
                        str = '';
                        for i=1:length(f)
                            str = sprintf('%s %1.2f', str, f(i));
                        end

                        handles.currentFilter.freqSampleFstr = str;
                        set(handles.freqSampleFreqBox,'string',str);
                    case 4
                        handles.currentFilter = varargin{1};
                        set(handles.zeroPlaceFormCombo,'value',handles.currentFilter.vz);
                        set(handles.polePlaceFormCombo,'value',handles.currentFilter.vp);
                        handles = updateFIRZeroPlace(handles);
                    case 5
                        set(handles.filterZerosBox,'string',num2str(handles.currentFilter.zeros));
                        set(handles.filterPolesBox,'string',num2str(handles.currentFilter.poles));
                    case 6
                        set(handles.twoPoleRbox,'string', num2str(handles.currentFilter.R));
                        set(handles.twoPoleThetaBox,'string', num2str(handles.currentFilter.th));
                        set(handles.twoPoleFormCombo,'value', handles.currentFilter.mode);
                        set(handles.twoPoleTypeCombo,'value', handles.currentFilter.type);
                        switch handles.currentFilter.mode
                            case 1
                                set(handles.twoPoleThetaTxt,'string','Theta (deg)');
                            case 2
                                set(handles.twoPoleThetaTxt,'string','Freq (Hz)');
                            case 3
                                set(handles.twoPoleThetaTxt,'string','Freq (Norm)');
                        end
                    case 7
                        handles.currentFilter = varargin{1};
                        set(handles.zeroPlaceFormCombo,'value',handles.currentFilter.vz);
                        set(handles.polePlaceFormCombo,'value',handles.currentFilter.vp);
                        handles = updateFIRZeroPlace(handles);
                    case 8
                        handles.currentFilter = varargin{1};
                        set(handles.intPolesCombo,'value', handles.currentFilter.intPolesVal);
                        set(handles.intZerosCombo,'value',handles.currentFilter.intZerosVal);
                        set(handles.intFiltOrderBox,'string',num2str(handles.currentFilter.intOrder));
                        handles = updateIntFilter(handles);
                end
            end
        catch
            handles.Rate = 200;
            handles.currentFilterNum = 1;
            handles.currentFilter = handles.filterList{1};
            handles.currentFilter.filterType = 0;
            handles = updateFilter(handles);
        end
    else
        handles.Rate = varargin{1}.Rate;
        handles.currentFilterNum = 1;
        handles.currentFilter = handles.filterList{1};
        handles.currentFilter.filterType = 0;
        handles = updateFilter(handles);
    end
    guidata(hObject, handles);
else
    handles.Rate = 200;
    handles.currentFilterNum = 1;
    handles.currentFilter = handles.filterList{1};
    handles.currentFilter.filterType = 0;
    handles = updateFilter(handles);
    guidata(hObject, handles);
end

set(handles.fsBox,'string',num2str(handles.Rate));

% 
% if nargin == 4
%     if ~isempty(varargin{1}.zeros)
%         handles.currentFilter.name = varargin{1}.name;
%         handles.currentFilter.zeros = varargin{1}.zeros;
%         handles.currentFilter.poles = varargin{1}.poles;
%         handles.currentFilter.name = varargin{1}.name;
%         set(handles.filter_name,'string',handles.currentFilter.name);
%         handles.currentFilter.filterType = 1;
%         set(handles.filtInfoText,'string',...
%             'Enter filter coefficients into the zeros and poles box above');
%         set(handles.filterImpulsePanel,'visible','on');
%         set(handles.zerosBox,'string',num2str(handles.currentFilter.zeros));
%         set(handles.polesBox,'string',num2str(handles.currentFilter.poles));
%         set(handles.filterZerosBox,'string',num2str(handles.currentFilter.zeros));
%         set(handles.filterPolesBox,'string',num2str(handles.currentFilter.poles));
%         set(handles.filterTypeCombo,'value',1);
%         handles.currentFilterNum = 11;
%         set(handles.FilterSelect,'value',1);
%     else
%         handles.currentFilterNum = 1;
%         handles.currentFilter = handles.filterList{1};
%     end
% 
% end

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes sigproPopUp wait for user response (see UIRESUME)
uiwait(handles.filterGUI);


% --- Outputs from this function are returned to the command line.
function varargout = FilterGUI_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
% uiresume(hObject)
% 
% %return a struct of zeroes and poles
% temp = struct('zeroes', 'poles');
% temp.zeroes = handles.Z;
% temp.poles = handles.P;
% temp.name = handles.name;
% varargout{1} = temp;

% The figure can be deleted now
if isempty(handles)
    handles.output = [];
end
varargout{1} = handles.output;
delete(hObject);

%-----------------------------------------
function handles = initGUI(handles)
plotWidths = .4;
plotHeights = .26;
handles.axes1 = subplot('position',[.08 1-plotHeights-.05 plotWidths plotHeights]);
set(handles.axes1,'parent',handles.axesPanel);
handles.axes2 = subplot('position',[1-plotWidths-.05 1-plotHeights-.05 plotWidths plotHeights]);
set(handles.axes2, 'parent',handles.axesPanel);
handles.axes3 = subplot('position',[.08 1-plotHeights*2-.05*2.5 plotWidths plotHeights]);
set(handles.axes3, 'parent',handles.axesPanel);
handles.axes4 = subplot('position',[1-plotWidths-.05 1-plotHeights*2-.05*2.5 plotWidths plotHeights]);
set(handles.axes4, 'parent',handles.axesPanel);
handles.TFaxes = subplot('position',[.05 .05 .9 plotHeights]);
set(handles.TFaxes, 'parent',handles.axesPanel);
set(handles.TFaxes,'visible','off');
set(handles.axes1,'xticklabel','','yticklabel','');
set(handles.axes2,'xticklabel','','yticklabel','');
set(handles.axes3,'xticklabel','','yticklabel','');
set(handles.axes4,'xticklabel','','yticklabel','');
set(handles.TFaxes,'units','characters');

handles.name = '';
handles.funcText = '';

str = [];
% Custom Filter
% Filter From Pole Zero Plot
% Load Filter from File
for i=1:length(handles.filterList)
    str{i} = handles.filterList{i}.name;
end

set(handles.FilterSelect,'string',str);

%-------------------------------------------------
function handles = updateFilter(handles)
curFilt = handles.currentFilterNum;
handles.currentFilter = handles.filterList{curFilt};
handles.currentFilter.filterNum = curFilt;
switch curFilt
    case handles.custFiltNum
        set(handles.zerosBox,'enable','inactive');
        set(handles.polesBox,'enable','inactive');
        set(handles.zerosBox,'string',num2str(handles.currentFilter.zeros));
        set(handles.polesBox,'string',num2str(handles.currentFilter.poles));
        set(handles.filter_name,'string',handles.currentFilter.name);
        set(handles.filterDesignPanel,'visible','on');
        set(handles.filterTypeCombo,'value',1);
%         handles.currentFilter.filterType = 1;
        set(handles.filtInfoText,'string',...
            'Enter filter coefficients into the zeros and poles box below');
        set(handles.filterImpulsePanel,'visible','on');
    case handles.loadFiltNum
        L = which('digiscope');
        a = strfind(L,filesep);
        L(a(end)+1:end) = [];
        [fname,fpath] = uigetfile({'*.fil','Digiscope Filter File'},'Select a Digiscope Filter',[L,'filterFiles']);
        try
            [handles.currentFilter.zeros, handles.currentFilter.poles] = DigiFilRead([fpath,fname]);
            handles.currentFilter.name = fname(1:end-4);
            set(handles.zerosBox,'string',num2str(handles.currentFilter.zeros));
            set(handles.polesBox,'string',num2str(handles.currentFilter.poles));
            set(handles.filter_name,'string',handles.currentFilter.name);
        catch
        end
    otherwise
        set(handles.filter_name,'string',handles.currentFilter.name);
        set(handles.zerosBox,'string',num2str(handles.currentFilter.zeros));
        set(handles.polesBox,'string',num2str(handles.currentFilter.poles));
        set(handles.zerosBox,'enable','on');
        set(handles.polesBox,'enable','on');
        set(handles.filterDesignPanel,'visible','off');
end


function Zeroes_Callback(hObject, eventdata, handles)



% --- Executes during object creation, after setting all properties.
function zerosBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Zeroes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Poles_Callback(hObject, eventdata, handles)
% hObject    handle to Poles (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Poles as text
%        str2double(get(hObject,'String')) returns contents of Poles as a double


str = get(handles.Poles,'String'); % nab string
str = strrep( str, ' ', ''); %gets rid of all spaces
if (get(handles.intRadio, 'Value') ==1 ) %if INT
    % we need to limit the zeroes to:
    % 1 + 1z^-1 +/- z^-2 120
    % 1 - 1z^-1 +/- z^-2 60
    % 1 +/- z^-1
    % 1 +/- z^-2 90
    % There are 6 possible cases.  Instead of some fancy algorithm,
    % i'm just gonna make a case statement
    set(handles.PolesDisplay, 'String', 'These poles appear valid.  Make sure they are canceled out by zeroes.');
    switch str
        case {'1+z^-1+z^-2', '1+1z^-1+z^-2', '1+1z^-1+1z^-2', '1+z^-1+1z^-2'}
            handles.P = [1,1,1];
            %                  set(handles.Theta, 'String', 'Note this is what you get when you set Theta to 120 degrees.');
        case {'1+z^-1-z^-2', '1+1z^-1-z^-2', '1+1z^-1-1z^-2', '1+z^-1-1z^-2'}
            handles.P = [1,1,-1];
            %                  set(handles.Theta, 'String', 'Note this is what you get when you set Theta to 120 degrees.');
        case {'1-z^-1+z^-2', '1-1z^-1+z^-2', '1-1z^-1+1z^-2', '1-z^-1+1z^-2'}
            handles.P = [1,-1,1];
            %                  set(handles.Theta, 'String', 'Note this is what you get when you set Theta to 60 degrees.');
        case {'1-z^-1-z^-2', '1-1z^-1-z^-2', '1-1z^-1-1z^-2', '1-z^-1-1z^-2'}
            handles.P = [1,-1,-1];
            %                  set(handles.Theta, 'String', 'Note this is what you get when you set Theta to 60 degrees.');
        case {'1+z^-2', '1+1z^-2', '1+0z^-1+z^-2', '1+0z^-1+1z^-2', '1-0z^-1+z^-2', '1-0z^-1+1z^-2'}
            handles.P = [1,0,1];
            %                  set(handles.Theta, 'String', 'Note this is what you get when you set Theta to 90 degrees.');
        case {'1-z^-2', '1-1z^-2', '1+0z^-1-z^-2', '1+0z^-1-1z^-2', '1-0z^-1-z^-2', '1-0z^-1-1z^-2'}
            handles.P = [1,0,-1];
            %                  set(handles.Theta, 'String', 'Note this is what you get when you set Theta to 90 degrees.');
        case {'1+z^-1', '1+1z^-1', '1+z^-1+0z^-2', '1+1z^-1-0z^-2'}
            handles.P = [1,1];
            %                  set(handles.Theta, 'String', '');
        case {'1-z^-1', '1-1z^-1', '1-z^-1+0z^-2', '1-1z^-1-0z^-2'}
            handles.P = [1,-1];
            %                  set(handles.Theta, 'String', '');
        otherwise
            set(handles.PolesDisplay, 'String', 'This does not appear to be a valid pole.  You need the form 1 +/- Az^-1 +/- Bz^-2, where A and B are integers.');
            set(handles.Poles, 'String', '1 + z^-1');

    end % end case

else % end INT filter, now on to FIR, IIR

    str = strrep( str, ' ', ''); %gets rid of all spaces
    locations = findstr (str, ',');    %how many expressions do we have?
    numLoc = size(locations,2); % using delimiters, need to add one more
    numLoc = numLoc + 1;

    remain = str;  %necessary for upcoming operation
    Pstr = 'unitilized';


    for i=1:numLoc
        [arg, remain]=strtok(remain, ','); %find current arg
        A = str2num(arg);
        handles.P(i)=A;
        if i == 1
            Pstr = arg;
        else
            Pstr = strcat(Pstr,'  +  ', arg, 'z^-');
            j = num2str(i-1);
            Pstr = strcat(Pstr, j, ' ');
        end
    end % end stepping through zeroes expression


    if (get(handles.firRadio, 'Value')  && i>1 ) % if FIR, check to see if too many arguments in pole
        set(handles.Poles, 'String', '');
        set(handles.HelpText, 'String', 'A FIR filter cannot have more then 1 argument in the denominator');
    else % we are clear to  proceed with the rest of the processing
        % root the sucker!
        handles.PRoots = roots(handles.P);

        % Find number of answers
        ans = size(handles.PRoots);
        handles.NumPans = ans(1);
        guidata(hObject, handles);

    end % end FIR or IIR

    set(handles.PolesDisplay, 'String', Pstr); %display the string

end % end INT or FIR/IIR


guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function Poles_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Poles (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in DrawFilter.
function DrawFilter_Callback(hObject, eventdata, handles)
% hObject    handle to DrawFilter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

nCasc = str2num(get(handles.numCascadesBox,'string'));
if nCasc < 0
    errordlg('Error: the number of cascades must be positive');
    return;
end
handles.filter = handles.currentFilter;
fzeros = handles.filter.zeros;
fpoles = handles.filter.poles;
for i=1:nCasc
    fzeros = conv(fzeros, handles.filter.zeros);
    fpoles = conv(fpoles, handles.filter.poles);
end
handles.filter.zeros = fzeros;
handles.filter.poles = fpoles;
set(handles.zerosBox,'string', num2str(handles.filter.zeros));
set(handles.polesBox,'string',num2str(handles.filter.poles));
handles.filter.zRoots = roots(handles.filter.zeros);
handles.filter.pRoots = roots(handles.filter.poles);
[h,f] = freqz(handles.filter.zeros, handles.filter.poles,1024,handles.Rate);

doNorm = get(handles.normCheck,'value');
Ph = abs(h);
Gh = max(Ph(find(Ph ~= Inf)));
if Gh == 0 Gh=1; end
if doNorm Ph = Ph./Gh; end
Gh = 20*log10(Gh);
%--------
axes(handles.axes1);
plot(f, 20*log10(Ph));
xlim([f(1) f(end)])
YL = get(handles.axes1,'ylim');
if YL(1) > -40 YL(1) = -40; set(handles.axes1,'ylim',YL); end
ylabel('Magnitude Response (dB)');
xlabel('Frequency (Hz)');
if doNorm title(sprintf('Gain=%1.2f dB',Gh)); end

%-------
axes(handles.axes2)
[impresp,impt] = impz(handles.filter.zeros, handles.filter.poles);
%dirac = [1; zeros(99,1)];
%impresp = filter(handles.filter.zeros, handles.filter.poles, dirac);
% impresp = impz(
stem(impt,impresp);
XL = get(gca,'xlim'); YL = get(gca,'ylim');
XL(1) = -.1;
XL(2) = XL(2) +min(.1*XL(2),2);
YL(2) = YL(2) +min(.1*YL(2),2);
set(gca,'xlim',XL,'ylim', YL);
% if length(handles.filter.poles) == 1
%     xlim([1 max(length(handles.filter.zeros),2)]);
% else
%     xlim([0 100])
% end
% 
% ylim([-1 1]*max(abs(impresp))*1.5);
ylabel('Impulse Response');
xlabel('Samples');

%-------
axes(handles.axes3);
zplane(handles.filter.zRoots,handles.filter.pRoots);
%-------
axes(handles.axes4)
%phasez(handles.filter.zeros, handles.filter.poles);
plot(f,angle(h)); grid; axis([f(1) f(end) -pi pi]);
title('');

%-------

handles.TFtext = transferOut(handles.filter.zeros, handles.filter.poles,...
    handles.TFtext, handles.TFaxes, handles.TFdispMode);
guidata(hObject, handles);

guidata(hObject, handles);


% --- Executes on selection change in FilterSelect.
function FilterSelect_Callback(hObject, eventdata, handles)
% hObject    handle to FilterSelect (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: contents = get(hObject,'String') returns FilterSelect contents as cell array
%        contents{get(hObject,'Value')} returns selected item from FilterSelect
% set(handles.DrawFilter, 'Enable', 'on');

handles.currentFilterNum = get(hObject,'value');
handles = updateFilter(handles);

guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function FilterSelect_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FilterSelect (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in load_file.
function load_file_Callback(hObject, eventdata, handles)
% hObject    handle to load_file (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[inputfile, pathname] = uigetfile( ...
    {'*.fil','DigiScope Filter Files (*.fil)';
    '*.*',  'All Files (*.*)'}, ...
    'Pick a file');

%if no filemenu is select. ie. cancel button clicked
% if ( inputfile ~= 0 )
%     [firiir, intfil, b, a] = DigiFilRead([pathname inputfile]);
%     handles.is_valid = 1;  %if the user picks a file, continue
%     switch (intfil)
%         case 0
%             switch (firiir)
%                 case 0
%                     str = 'Custom FIR';
%                 case 1
%                     str = 'Custom IIR';
%             end
%         case 1
%             str = 'Custom Integer'
%     end
%     set(handles.filter_name, 'String', str);
%     handles.Z = b
%     handles.P = a
% end

guidata(hObject,handles);


function filter_name_Callback(hObject, eventdata, handles)
% hObject    handle to filter_name (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of filter_name as text
%        str2double(get(hObject,'String')) returns contents of filter_name as a double
s = get(hObject,'string');
handles.currentFilter.name =s;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function filter_name_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filter_name (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Close.
function Close_Callback(hObject, eventdata, handles)
% hObject    handle to Close (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.output = handles.filter;
guidata(hObject, handles);
uiresume(handles.filterGUI);


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over FilterSelect.
function FilterSelect_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to FilterSelect (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function DrawFilter_CreateFcn(hObject, eventdata, handles)
% hObject    handle to DrawFilter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes when user attempts to close filterGUI.
function filterGUI_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to filterGUI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.output = [];
guidata(hObject, handles);
uiresume(handles.filterGUI);


function intFiltOrderBox_Callback(hObject, eventdata, handles)
% hObject    handle to intFiltOrderBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles = updateIntFilter(handles);
guidata(hObject, handles);
% Hints: get(hObject,'String') returns contents of intFiltOrderBox as text
%        str2double(get(hObject,'String')) returns contents of intFiltOrderBox as a double

% str = get(handles.intFiltOrderBox,'String'); % nab string
% Pos = get(handles.intPosRadio, 'Value');
% Neg = get(handles.intNegRadio, 'Value');
% 
% if(Pos == 1)
%     str2 = '1 + z^-';
% 
% elseif (Neg == 1)
%     str2 = '1 - z^-';
% 
% end
% str = strcat(str2, str);
% set(handles.Zeroes, 'String', str);
% Zeroes_Callback(hObject, eventdata, handles);

% --- Executes during object creation, after setting all properties.
function intFiltOrderBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to intFiltOrderBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%--------------------------------------------------------
function handles = setupDefaultFilters(handles)

handles.filterList{1}.zeros = 1;
handles.filterList{1}.poles = 1;
handles.filterList{1}.name = 'Custom Filter';
handles.custFiltNum = 1;

handles.filterList{end+1}.zeros =[1 2 1];
handles.filterList{end}.poles =[4];
handles.filterList{end}.name = 'Hanning';

handles.filterList{end+1}.zeros = [2,1,0,-1,-2];
handles.filterList{end}.poles = [10];
handles.filterList{end}.name = 'deriv2';

handles.filterList{end+1}.zeros = [3,2,1,0,-1,-2,-3];
handles.filterList{end}.poles = [28];
handles.filterList{end}.name = 'deriv3';

handles.filterList{end+1}.zeros = [5,4,3,2,1,0,-1,-2,-3,-4,-5];
handles.filterList{end}.poles = [110];
handles.filterList{end}.name = 'deriv5';

handles.filterList{end+1}.zeros = [-3,12,17,12,-3];
handles.filterList{end}.poles = [35];
handles.filterList{end}.name = 'poly2';

handles.filterList{end+1}.zeros = [-2,3,6,7,6,3,-2];
handles.filterList{end}.poles = [21];
handles.filterList{end}.name = 'poly3';

handles.filterList{end+1}.zeros = [-21,14,39,54,59,54,39,14,-21];
handles.filterList{end}.poles = [231];
handles.filterList{end}.name = 'poly4';

handles.filterList{end+1}.zeros = [0 1];
handles.filterList{end}.poles = [1 -1];
handles.filterList{end}.name = 'Rectangular Integration';

handles.filterList{end+1}.zeros = [1 1]/2;
handles.filterList{end}.poles = [2 -2]/2;
handles.filterList{end}.name = 'Trapezoidal Integration';

handles.filterList{end+1}.zeros = [1,4,2]/3;
handles.filterList{end}.poles = [3,0,-3]/3;
handles.filterList{end}.name = 'Simpson''s Rule';

handles.filterList{end+1}.zeros = 1;
handles.filterList{end}.poles = 1;
handles.filterList{end}.name = 'Load From File...';
handles.loadFiltNum = length(handles.filterList);



function zerosBox_Callback(hObject, eventdata, handles)
% hObject    handle to zerosBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of zerosBox as text
%        str2double(get(hObject,'String')) returns contents of zerosBox as a double



function polesBox_Callback(hObject, eventdata, handles)
% hObject    handle to polesBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of polesBox as text
%        str2double(get(hObject,'String')) returns contents of polesBox as a double


% --- Executes during object creation, after setting all properties.
function polesBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to polesBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on key press with focus on zerosBox and no controls selected.
function zerosBox_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to zerosBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --- Executes on key press with focus on polesBox and no controls selected.
function polesBox_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to polesBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
c = get(handles.filterGUI,'currentcharacter');
if c == '-' || c == '.' || c == 'e'
    return;
end
try
    a = str2num(get(hObject,'string'));
    if isempty(a)
        errordlg('Invalid entry for filter poles.');   
    else
        handles.currentFilter.poles = a;
    end    
catch
    errordlg('Invalid entry for filter poles.');
end
set(hObject,'string',num2str(handles.currentFilter.poles));
guidata(hObject,handles);


% --- Executes on selection change in filterTypeCombo.
function filterTypeCombo_Callback(hObject, eventdata, handles)
% hObject    handle to filterTypeCombo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns filterTypeCombo contents as cell array
%        contents{get(hObject,'Value')} returns selected item from filterTypeCombo
v = get(hObject,'value');
handles = changeFilterType(handles,v);
guidata(hObject, handles);

function handles = changeFilterType(handles,v)

% hide all objects here automatically, and just worry about displaying the
% ones needed
set(handles.intFilterPanel,'visible','off');
set(handles.zerosBox,'enable','inactive');
set(handles.polesBox,'enable','inactive');
set(handles.firFreqSamplePanel,'visible','off');
set(handles.zeroPlacePanel,'visible','off');
set(handles.polePlacePanel,'visible','off');
set(handles.twoPolePanel,'visible','off');
set(handles.filtInfoText,'string','');
set(handles.filterImpulsePanel,'visible','off');
pause(.1);
switch v
    case 1 % FIR Impulse response
        handles.currentFilter.filterType = 1;
        set(handles.filtInfoText,'string',...
            'Enter filter coefficients into the zeros and poles box below');
        set(handles.filterImpulsePanel,'visible','on');
    case 2 % FIR Frequency Sample
        handles.currentFilter.filterType = 2;
        set(handles.firFreqSamplePanel,'visible','on');
        set(handles.filtInfoText,'string',...
            'Enter gain values in dB. Locations will depend on the number entered.');
    case 4
        handles.currentFilter.filterType = 4;
        handles.currentFilter.zeros = 1;
        handles.currentFilter.poles = 1;
        handles.currentFilter.zeroPlace = [];
        handles.currentFilter.polePlace = [];
        handles = updateFIRZeroPlace(handles);
        set(handles.zeroPlacePanel,'visible','on');
        set(handles.firPoleBox,'visible','on');
        set(handles.firPoleText,'visible','on');
        set(handles.filtInfoText,'string',...
                'Add zero locations in rect or polar format, and set the numerator coefficient.');
    case 5
        handles.currentFilter.filterType = 5;
        set(handles.filtInfoText,'string',...
            'Enter filter coefficients into the zeros and poles box above');
        set(handles.filterImpulsePanel,'visible','on');
    case 6
        handles.currentFilter.filterType = 6;
        set(handles.twoPolePanel,'visible','on');
        set(handles.filtInfoText,'string',...
                'Select the filter type and critical frequency in polar, frequency, or normalized format.');
    case 7
        handles.currentFilter.filterType = 7;
        set(handles.zeroPlacePanel,'visible','on');
        set(handles.firPoleBox,'visible','off');
        set(handles.firPoleText,'visible','off');
        set(handles.polePlacePanel,'visible','on');
        handles.currentFilter.zeros = 1;
        handles.currentFilter.poles = 1;
        handles.currentFilter.zeroPlace = [];
        handles.currentFilter.polePlace = [];
        handles = updateFIRZeroPlace(handles);
        set(handles.filtInfoText,'string',...
                'Enter filter coefficients into the zeros and poles box below');
    case 8 % integer
        handles.currentFilter.filterType = 8;
        set(handles.intFilterPanel,'visible','on');
        set(handles.filtInfoText,'string',...
            'Select zero and poles settings below');  
        handles = updateIntFilter(handles);
end

% --- Executes during object creation, after setting all properties.
function filterTypeCombo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filterTypeCombo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in freqSampleCombo.
function freqSampleCombo_Callback(hObject, eventdata, handles)
% hObject    handle to freqSampleCombo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns freqSampleCombo contents as cell array
%        contents{get(hObject,'Value')} returns selected item from freqSampleCombo


% --- Executes during object creation, after setting all properties.
function freqSampleCombo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to freqSampleCombo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function freqSampleInputBox_Callback(hObject, eventdata, handles)
% hObject    handle to freqSampleInputBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of freqSampleInputBox as text
%        str2double(get(hObject,'String')) returns contents of freqSampleInputBox as a double


% --- Executes during object creation, after setting all properties.
function freqSampleInputBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to freqSampleInputBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function freqSampleFreqBox_Callback(hObject, eventdata, handles)
% hObject    handle to freqSampleFreqBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of freqSampleFreqBox as text
%        str2double(get(hObject,'String')) returns contents of freqSampleFreqBox as a double


% --- Executes during object creation, after setting all properties.
function freqSampleFreqBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to freqSampleFreqBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in zeroPlaceFormCombo.
function zeroPlaceFormCombo_Callback(hObject, eventdata, handles)
% hObject    handle to zeroPlaceFormCombo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns zeroPlaceFormCombo contents as cell array
%        contents{get(hObject,'Value')} returns selected item from zeroPlaceFormCombo
handles = updateFIRZeroPlace(handles);
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function zeroPlaceFormCombo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to zeroPlaceFormCombo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in zeroPlaceList.
function zeroPlaceList_Callback(hObject, eventdata, handles)
% hObject    handle to zeroPlaceList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns zeroPlaceList contents as cell array
%        contents{get(hObject,'Value')} returns selected item from zeroPlaceList


% --- Executes during object creation, after setting all properties.
function zeroPlaceList_CreateFcn(hObject, eventdata, handles)
% hObject    handle to zeroPlaceList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%------------------------------------------------
function handles = updateFIRZeroPlace(handles)
handles.currentFilter.vz = get(handles.zeroPlaceFormCombo,'value');
handles.currentFilter.vp = get(handles.polePlaceFormCombo,'value');
if isempty(handles.currentFilter.zeroPlace)
    set(handles.zeroPlaceList,'string','');
    handles.currentFilter.zeros = 1;
else
    [Z,zStr] = calcCoeffsFromRoots(handles.currentFilter.zeroPlace, handles.currentFilter.vz);
    handles.currentFilter.zeros = Z;
    
    set(handles.zeroPlaceList,'string',zStr);
end
set(handles.zerosBox,'string',num2str(handles.currentFilter.zeros));

if handles.currentFilter.filterType == 4
    if isempty(handles.currentFilter.poles)
        handles.currentFilter.poles = 1;
    end
else
    if isempty(handles.currentFilter.polePlace)
        set(handles.polePlaceList,'string','');
        handles.currentFilter.poles = 1;
    else
        [P,pStr] = calcCoeffsFromRoots(handles.currentFilter.polePlace, handles.currentFilter.vp);
        handles.currentFilter.poles = P;
        
        set(handles.polePlaceList,'string',pStr);
    end
end
set(handles.polesBox,'string',num2str(handles.currentFilter.poles));


%------------------------------
function [coeffs, str] = calcCoeffsFromRoots(R,mode)
coeffs = poly(R(:,1));
for k=1:size(R,1)
    if mode == 1
        str{k} = num2str(R(k,1));
    else
        str{k} = sprintf('(%s, %s)', num2str(R(k,2),3), num2str(R(k,3)*180/pi,3));
    end
end


% --- Executes on button press in addZeroBtn.
function addZeroBtn_Callback(hObject, eventdata, handles)
% hObject    handle to addZeroBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
v = get(handles.zeroPlaceFormCombo,'value');
if v == 1
    answer = inputdlg({'Real Part','Imaginary Part'},'Enter Zero in Rectangular Form',1,{'1','0'});
    if isempty(answer) return; end
    r = str2double(answer{1});
    im = str2double(answer{2});
    handles.currentFilter.zeroPlace = cat(1,handles.currentFilter.zeroPlace,[(r+i*im) sqrt(r^2+im^2) atan2(im,r) 0]);
    if im ~= 0
        handles.currentFilter.zeroPlace = cat(1,handles.currentFilter.zeroPlace,...
            [(r-im*i) sqrt(r^2+im^2) atan2(-im,r) (size(handles.currentFilter.zeroPlace,1))]);
        handles.currentFilter.zeroPlace(end-1,4) = size(handles.currentFilter.zeroPlace,1);
    end
else
    answer = inputdlg({'Radius','Theta (deg)'},'Enter Zero in Polar Form',1,{'1','0'});
    if isempty(answer) return; end
    r = str2double(answer{1});
    th = str2double(answer{2})*pi/180;
    handles.currentFilter.zeroPlace = cat(1,handles.currentFilter.zeroPlace,[(r*cos(th)+i*r*sin(th)) r th 0]);
    if th ~= 0 && th ~= pi
        handles.currentFilter.zeroPlace = cat(1,handles.currentFilter.zeroPlace,...
            [(r*cos(th)-i*r*sin(th)) r -th size(handles.currentFilter.zeroPlace,1)]);
        handles.currentFilter.zeroPlace(end-1,4) = size(handles.currentFilter.zeroPlace,1);
    end
end

handles = updateFIRZeroPlace(handles);
guidata(hObject, handles);

% --- Executes on button press in remZeroBtn.
function remZeroBtn_Callback(hObject, eventdata, handles)
% hObject    handle to remZeroBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
v = get(handles.zeroPlaceList,'value');
if isempty(handles.currentFilter.zeroPlace) return; end
if isempty(v) return; end
set(handles.zeroPlaceList,'value',1);
tie = handles.currentFilter.zeroPlace(v,4);
if tie ~= 0
    handles.currentFilter.zeroPlace([v tie],:) = [];
else
    handles.currentFilter.zeroPlace(v,:) = [];
end

handles = updateFIRZeroPlace(handles);
guidata(hObject, handles);

% --- Executes on selection change in polePlaceFormCombo.
function polePlaceFormCombo_Callback(hObject, eventdata, handles)
% hObject    handle to polePlaceFormCombo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns polePlaceFormCombo contents as cell array
%        contents{get(hObject,'Value')} returns selected item from polePlaceFormCombo
handles = updateFIRZeroPlace(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function polePlaceFormCombo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to polePlaceFormCombo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in polePlaceList.
function polePlaceList_Callback(hObject, eventdata, handles)
% hObject    handle to polePlaceList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns polePlaceList contents as cell array
%        contents{get(hObject,'Value')} returns selected item from polePlaceList
handles = updateFIRZeroPlace(handles);
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function polePlaceList_CreateFcn(hObject, eventdata, handles)
% hObject    handle to polePlaceList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in addPoleBtn.
function addPoleBtn_Callback(hObject, eventdata, handles)
% hObject    handle to addPoleBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

v = get(handles.polePlaceFormCombo,'value');
if v == 1
    answer = inputdlg({'Real Part','Imaginary Part'},'Enter Pole in Rectangular Form',1,{'1','0'});
    if isempty(answer) return; end
    r = str2double(answer{1});
    im = str2double(answer{2});
    handles.currentFilter.polePlace = cat(1,handles.currentFilter.polePlace,[(r+i*im) sqrt(r^2+im^2) atan2(im,r) 0]);
    if im ~= 0
        handles.currentFilter.polePlace = cat(1,handles.currentFilter.polePlace,...
            [(r-im*i) sqrt(r^2+im^2) atan2(-im,r) (size(handles.currentFilter.polePlace,1))]);
        handles.currentFilter.polePlace(end-1,4) = size(handles.currentFilter.polePlace,1);
    end
else
    answer = inputdlg({'Radius','Theta (deg)'},'Enter Pole in Polar Form',1,{'1','0'});
    if isempty(answer) return; end
    r = str2double(answer{1});
    th = str2double(answer{2})*pi/180;
    handles.currentFilter.polePlace = cat(1,handles.currentFilter.polePlace,[(r*cos(th)+i*r*sin(th)) r th 0]);
    if th ~= 0 && th ~= pi
        handles.currentFilter.polePlace = cat(1,handles.currentFilter.polePlace,...
            [(r*cos(th)-i*r*sin(th)) r -th size(handles.currentFilter.polePlace,1)]);
        handles.currentFilter.polePlace(end-1,4) = size(handles.currentFilter.polePlace,1);
    end
end

handles = updateFIRZeroPlace(handles);
guidata(hObject, handles);

% --- Executes on button press in remPoleBtn.
function remPoleBtn_Callback(hObject, eventdata, handles)
% hObject    handle to remPoleBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
v = get(handles.polePlaceList,'value');
if isempty(handles.currentFilter.polePlace) return; end
if isempty(v) return; end
set(handles.polePlaceList,'value',1);
tie = handles.currentFilter.polePlace(v,4);
if tie ~= 0
    handles.currentFilter.polePlace([v tie],:) = [];
else
    handles.currentFilter.polePlace(v,:) = [];
end

handles = updateFIRZeroPlace(handles);
guidata(hObject, handles);

% --- Executes on selection change in twoPoleTypeCombo.
function twoPoleTypeCombo_Callback(hObject, eventdata, handles)
% hObject    handle to twoPoleTypeCombo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns twoPoleTypeCombo contents as cell array
%        contents{get(hObject,'Value')} returns selected item from twoPoleTypeCombo


% --- Executes during object creation, after setting all properties.
function twoPoleTypeCombo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to twoPoleTypeCombo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in twoPoleFormCombo.
function twoPoleFormCombo_Callback(hObject, eventdata, handles)
% hObject    handle to twoPoleFormCombo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns twoPoleFormCombo contents as cell array
%        contents{get(hObject,'Value')} returns selected item from twoPoleFormCombo
switch get(hObject,'value')
    case 1
        set(handles.twoPoleThetaTxt,'string','Theta (deg)');
        set(handles.twoPoleThetaBox,'string','45');
    case 2
        set(handles.twoPoleThetaTxt,'string','Freq (Hz)');
        set(handles.twoPoleThetaBox,'string','25');
    case 3
        set(handles.twoPoleThetaTxt,'string','Freq (Norm)');
        set(handles.twoPoleThetaBox,'string','0.25');
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function twoPoleFormCombo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to twoPoleFormCombo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function twoPoleRbox_Callback(hObject, eventdata, handles)
% hObject    handle to twoPoleRbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of twoPoleRbox as text
%        str2double(get(hObject,'String')) returns contents of twoPoleRbox as a double


% --- Executes during object creation, after setting all properties.
function twoPoleRbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to twoPoleRbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function twoPoleThetaBox_Callback(hObject, eventdata, handles)
% hObject    handle to twoPoleThetaBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of twoPoleThetaBox as text
%        str2double(get(hObject,'String')) returns contents of twoPoleThetaBox as a double


% --- Executes during object creation, after setting all properties.
function twoPoleThetaBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to twoPoleThetaBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in TFdispCombo.
function TFdispCombo_Callback(hObject, eventdata, handles)
% hObject    handle to TFdispCombo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns TFdispCombo contents as cell array
%        contents{get(hObject,'Value')} returns selected item from TFdispCombo
handles.TFdispMode = get(hObject,'value');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function TFdispCombo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to TFdispCombo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in intZerosCombo.
function intZerosCombo_Callback(hObject, eventdata, handles)
% hObject    handle to intZerosCombo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns intZerosCombo contents as cell array
%        contents{get(hObject,'Value')} returns selected item from intZerosCombo
handles = updateIntFilter(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function intZerosCombo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to intZerosCombo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%------------------------------------------------
function handles = updateIntFilter(handles)
v = get(handles.intPolesCombo,'value');

switch v
    case 1
        handles.currentFilter.poles = [1 -1];
    case 2
        handles.currentFilter.poles = [1 1];
    case 3
        handles.currentFilter.poles = [1 -1 1];
    case 4
        handles.currentFilter.poles = [1 0 1];
    case 5
        handles.currentFilter.poles = [1 1 1];
    case 6
        handles.currentFilter.poles = 1;
end
set(handles.polesBox,'string',num2str(handles.currentFilter.poles));
handles.currentFilter.intPolesVal = v;

v = get(handles.intZerosCombo,'value');
order = str2double(get(handles.intFiltOrderBox,'string'));
handles.currentFilter.intOrder = order;
handles.currentFilter.intZerosVal= v;
handles.currentFilter.zeros = zeros(1,order+1);
handles.currentFilter.zeros(1) = 1;
switch v
    case 1
        handles.currentFilter.zeros(end) = 1;
    case 2
        handles.currentFilter.zeros(end) = -1;
end
set(handles.zerosBox,'string',num2str(handles.currentFilter.zeros));

% --- Executes on selection change in intPolesCombo.
function intPolesCombo_Callback(hObject, eventdata, handles)
% hObject    handle to intPolesCombo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns intPolesCombo contents as cell array
%        contents{get(hObject,'Value')} returns selected item from intPolesCombo
handles = updateIntFilter(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function intPolesCombo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to intPolesCombo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function filterZerosBox_Callback(hObject, eventdata, handles)
% hObject    handle to filterZerosBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of filterZerosBox as text
%        str2double(get(hObject,'String')) returns contents of filterZerosBox as a double


% --- Executes during object creation, after setting all properties.
function filterZerosBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filterZerosBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in updateFIRbtn.
function updateFIRbtn_Callback(hObject, eventdata, handles)
% hObject    handle to updateFIRbtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in updateImpulseBtn.
function updateImpulseBtn_Callback(hObject, eventdata, handles)
% hObject    handle to updateImpulseBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

v= get(handles.filterTypeCombo,'value');

try
    a = str2num(get(handles.filterZerosBox,'string'));
    if isempty(a)
        errordlg('Invalid entry for filter zeros.');
        return;
    else
        handles.currentFilter.zeros = a;
    end
catch
    errordlg('Invalid entry for filter zeros.');
    return;
end
try
    a = str2num(get(handles.filterPolesBox,'string'));
    if isempty(a)
        errordlg('Invalid entry for filter poles.');
        return;
    else
        if v == 1 && length(a) > 1
            errordlg('FIR filters must contain only one pole value.');
            return;
        end
        handles.currentFilter.poles = a;
    end
catch
    errordlg('Invalid entry for filter poles.');
    return;
end
set(handles.polesBox,'string',num2str(handles.currentFilter.poles));
set(handles.zerosBox,'string',num2str(handles.currentFilter.zeros));
guidata(hObject, handles);

function filterPolesBox_Callback(hObject, eventdata, handles)
% hObject    handle to filterPolesBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of filterPolesBox as text
%        str2double(get(hObject,'String')) returns contents of filterPolesBox as a double


% --- Executes during object creation, after setting all properties.
function filterPolesBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filterPolesBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on key press with focus on filterZerosBox and no controls selected.
function filterZerosBox_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to filterZerosBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --- Executes on key press with focus on filterPolesBox and no controls selected.
function filterPolesBox_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to filterPolesBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


function FIRzerosBox_Callback(hObject, eventdata, handles)
% hObject    handle to FIRzerosBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of FIRzerosBox as text
%        str2double(get(hObject,'String')) returns contents of FIRzerosBox as a double


% --- Executes during object creation, after setting all properties.
function FIRzerosBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FIRzerosBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on key press with focus on FIRzerosBox and no controls selected.
function FIRzerosBox_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to FIRzerosBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
c = get(handles.filterGUI,'currentcharacter');
if c == 13
    return;
end
try
    a = str2num(get(hObject,'string'));
    if isempty(a)
        errordlg('Invalid entry for filter zeros.');
    else
        handles.currentFilter.zeros = a;
    end
catch
    errordlg('Invalid entry for filter zeros.');
end
set(hObject,'string',num2str(handles.currentFilter.zeros));
guidata(hObject,handles);


% --- Executes on button press in zoomBtn.
function zoomBtn_Callback(hObject, eventdata, handles)
% hObject    handle to zoomBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if get(hObject,'value') zoom on;
else zoom off;
end

% --- Executes on button press in measureBtn.
function measureBtn_Callback(hObject, eventdata, handles)
% hObject    handle to measureBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of measureBtn
if get(hObject,'value') datacursormode on;
else datacursormode off;
end


% --- Executes on button press in updateTwoPoleBtn.
function updateTwoPoleBtn_Callback(hObject, eventdata, handles)
% hObject    handle to updateTwoPoleBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
R = str2double(get(handles.twoPoleRbox,'string'));
th = str2double(get(handles.twoPoleThetaBox,'string'));
mode = get(handles.twoPoleFormCombo,'value');
type = get(handles.twoPoleTypeCombo,'value');
handles.currentFilter.th = th;
switch mode
    case 1
        if th < 0 || th > 180
            errordlg('In Polar mode, theta must be 0 <= theta <= 180');
            return; 
        end
    case 2
        if th < 0 || th > handles.Rate/2
            errordlg('In Frequency mode, freq must be 0 <= freq <= fs/2');
            return; 
        end
        th = (th/handles.Rate)*360;
    case 3
        if th < 0 || th > .5
            errordlg('In Polar mode, freq must be 0 <= freq <= 0.5');
            return; 
        end
        th = 360*th;
end
th = th*pi/180;

switch type
    case 1 %lowpass
        handles.currentFilter.zeros = [1 1];
        loc = R*[cos(th)+i*sin(th); cos(th)-i*sin(th)];
        handles.currentFilter.poles = poly(loc);
    case 2 %highpass
        handles.currentFilter.zeros = [1 -1];
        loc = R*[cos(th)+i*sin(th); cos(th)-i*sin(th)];
        handles.currentFilter.poles = poly(loc);
    case 3 %bandpass
        handles.currentFilter.zeros = [1 0 -1];
        loc = R*[cos(th)+i*sin(th); cos(th)-i*sin(th)];
        handles.currentFilter.poles = poly(loc);
    case 4 %bandstop
        loc = [cos(th)+i*sin(th); cos(th)-i*sin(th)];
        handles.currentFilter.zeros = poly(loc);
        loc = R*[cos(th)+i*sin(th); cos(th)-i*sin(th)];
        handles.currentFilter.poles = poly(loc);
end
handles.currentFilter.R = R;
handles.currentFilter.mode = mode;
handles.currentFilter.type = type;
set(handles.polesBox,'string',num2str(handles.currentFilter.poles));
set(handles.zerosBox,'string',num2str(handles.currentFilter.zeros));
guidata(hObject, handles);


% --- Executes on button press in updateFreqSampleBtn.
function updateFreqSampleBtn_Callback(hObject, eventdata, handles)
% hObject    handle to updateFreqSampleBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.currentFilter.freqSampleMode = get(handles.freqSampleCombo,'value');
handles.currentFilter.freqSampleResp = str2num(get(handles.freqSampleInputBox,'string'));
if isempty(handles.currentFilter.freqSampleResp)
    errordlg('Invalid numeric input for response.');
    return;
end
if length(handles.currentFilter.freqSampleResp) < 2
    errordlg('At least 2 values must be specified.');
    return;
end

resp = 10.^(handles.currentFilter.freqSampleResp/20);

if rem(length(resp),2) == 1
    resp(end+1) = 0;
    order = length(resp);
    space = 180/(length(resp)-1.5);
    f = [0:space:180]/180;
    f(end+1) = 1;
    handles.currentFilter.zeros = firls((length(f)-2)*2,f,resp);
else
    order = length(resp);
    space = 180/(length(resp)-.5);
    f = [0:space:180]/180;
    handles.currentFilter.zeros = firls((length(f)-1)*2,f,resp);
end


handles.currentFilter.poles = 1;
set(handles.polesBox,'string',num2str(handles.currentFilter.poles,1));
set(handles.zerosBox,'string',num2str(handles.currentFilter.zeros,1));

switch handles.currentFilter.freqSampleMode
    case 1 % polar
        f = f*180;
        %set(handles.freqSampleFreqBox,'string',num2str(f*180));
    case 2 % freq
        f = f*handles.Rate/2;
        %set(handles.freqSampleFreqBox,'string',num2str());
    case 3 % normalized
        f = f/2;
        %set(handles.freqSampleFreqBox,'string',num2str(f/2));
end
str = '';
for i=1:length(f)
    str = sprintf('%s %1.2f', str, f(i));
end

handles.currentFilter.freqSampleFstr = str;
set(handles.freqSampleFreqBox,'string',str);
guidata(hObject, handles);



function firPoleBox_Callback(hObject, eventdata, handles)
% hObject    handle to firPoleBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of firPoleBox as text
%        str2double(get(hObject,'String')) returns contents of firPoleBox as a double

p = str2num(get(hObject,'string'));
if length(p) ~= 1
    errordlg('The pole coefficient of an FIR filter can only have a single value!');
    return;
end
handles.currentFilter.poles = p;
set(handles.polesBox,'string',num2str(handles.currentFilter.poles));
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function firPoleBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to firPoleBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function numCascadesBox_Callback(hObject, eventdata, handles)
% hObject    handle to numCascadesBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of numCascadesBox as text
%        str2double(get(hObject,'String')) returns contents of numCascadesBox as a double


% --- Executes during object creation, after setting all properties.
function numCascadesBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to numCascadesBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in plotExtBtn.
function plotExtBtn_Callback(hObject, eventdata, handles)
% hObject    handle to plotExtBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

plots = get(handles.axesPanel,'children');
if isempty(plots) return; end
f = figure('color',[1 1 1]);
for i=1:length(plots)
    copyobj(plots(i), f);
end



function fsBox_Callback(hObject, eventdata, handles)
% hObject    handle to fsBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of fsBox as text
%        str2double(get(hObject,'String')) returns contents of fsBox as a double
fs = str2double(get(hObject,'string'));
if fs < 10 
    errordlg('The sampling rate must be >= 10');
    set(hObject,'string',num2str(handles.Rate));
    guidata(hObject, handles);
    return;
end
handles.Rate = fs;

guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function fsBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to fsBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes on button press in normCheck.
function normCheck_Callback(hObject, eventdata, handles)
% hObject    handle to normCheck (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of normCheck


% --- Executes on button press in saveFilterBtn.
function saveFilterBtn_Callback(hObject, eventdata, handles)
% hObject    handle to saveFilterBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if isempty(handles.filter)
    waitfor(errordlg('You must press the "Create Filter" button before the filter can be saved'));
    return;
end

[fname,fpath] = uiputfile('*.fil');
if fname == 0 return; end
isiir = length(handles.filter.poles) > 1;
isintfilt = 0;
if isfield(handles.filter,'filterType')
    isintfilt = handles.filter.filterType == 8;
end
DigiFilWrite([fpath,fname],isiir, isintfilt,handles.filter.zeros,handles.filter.poles);
