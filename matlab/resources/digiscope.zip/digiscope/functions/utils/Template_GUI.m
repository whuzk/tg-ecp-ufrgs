function varargout = Template_GUI(varargin)
% TEMPLATE_GUI M-file for Template_GUI.fig
%      TEMPLATE_GUI, by itself, creates a new TEMPLATE_GUI or raises the existing
%      singleton*.
%
%      H = TEMPLATE_GUI returns the handle to a new TEMPLATE_GUI or the handle to
%      the existing singleton*.
%
%      TEMPLATE_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TEMPLATE_GUI.M with the given input arguments.
%
%      TEMPLATE_GUI('Property','Value',...) creates a new TEMPLATE_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Template_GUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Template_GUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Template_GUI

% Last Modified by GUIDE v2.5 31-Aug-2008 19:14:09

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Template_GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @Template_GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Template_GUI is made visible.
function Template_GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Template_GUI (see VARARGIN)

% Choose default command line output for Template_GUI
handles.output = [];

handles.signal = varargin{1};
handles.filtdat = varargin{2};
if isempty(handles.filtdat.template)
    handles.filtdat.startT = [];
    handles.filtdat.startT = [];
end

set(handles.filterChainOutCombo,'value',handles.filtdat.outputMode);
handles.t = (0:length(handles.signal)-1)/handles.filtdat.Rate;
axes(handles.signalAxes);
xlim([handles.t(1) handles.t(end)]);
guidata(hObject, handles);
handles = updatePlots(handles);
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Template_GUI wait for user response (see UIRESUME)
% uiwait(handles.templateGUI);
uiwait(handles.templateGUI);

% --- Outputs from this function are returned to the command line.
function varargout = Template_GUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
if isempty(handles)
    varargout{1} = [];
else
    varargout{1} = handles.output;
end
close(hObject);

%------------------------------------------
function handles = updatePlots(handles)


XL = get(handles.signalAxes,'xlim');
axes(handles.signalAxes);
cla;
plot(handles.t, handles.signal,'color',[0 0 0]);
YL = get(handles.signalAxes,'ylim');
if isempty(handles.filtdat.template)
    axis([XL min(handles.signal) max(handles.signal)]);
    return; 
end
axis([XL YL]);
hold on;
plot([handles.filtdat.startT handles.filtdat.startT],[YL(1) YL(2)],'r');
plot([handles.filtdat.endT handles.filtdat.endT],[YL(1) YL(2)],'r');
hold off;
axis([XL YL]);
set(handles.startTimeBox,'string',num2str(handles.filtdat.startT));
set(handles.endTimeBox,'string',num2str(handles.filtdat.endT));
what2plot = get(handles.templateRadio,'value');
if what2plot
    axes(handles.secondAxes);
    t = (0:length(handles.filtdat.template)-1)/handles.filtdat.Rate;
    plot(t,handles.filtdat.template,'color',[0 0 0]);
    set(handles.secondAxes,'xlim',([0 t(end)]));
else
    axes(handles.secondAxes);
    P = 10*log10(abs(fft(handles.filtdat.template, max(512, length(handles.filtdat.template)))));
    if rem(length(P),2)
        %odd
        P = P(1:round(length(P)/2));
        F = linspace(0,handles.filtdat.Rate,length(P));
        plot(F,P,'color',[0 0 0]);        
    else
        P = P(1:(round(length(P)/2+1)));
        F = linspace(0,handles.filtdat.Rate/2,length(P));
        plot(F,P);
    end
end

% --- Executes on button press in zoomBtn.
function zoomBtn_Callback(hObject, eventdata, handles)
% hObject    handle to zoomBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of zoomBtn
if get(hObject,'value')
    zoom(handles.signalAxes,'on');
else
    zoom(handles.signalAxes,'off');
end
guidata(hObject, handles);
% --- Executes on button press in selectBtn.
function selectBtn_Callback(hObject, eventdata, handles)
% hObject    handle to selectBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
axes(handles.signalAxes);
[x,y] = ginput(2);
x = sort(x);
x = round(x.*handles.filtdat.Rate)+1;
if x(1) < 1 x(1) = 1; end
if x(2) > length(handles.signal) x(2) = length(handles.signal); end
handles.filtdat.startT = (x(1)-1)/handles.filtdat.Rate;
handles.filtdat.endT = (x(2)-1)/handles.filtdat.Rate;
set(handles.startTimeBox,'string',num2str(handles.filtdat.startT));
set(handles.endTimeBox,'string',num2str(handles.filtdat.endT));

handles.filtdat.template = handles.signal(x(1):x(2));
handles = updatePlots(handles);
guidata(hObject, handles);

function startTimeBox_Callback(hObject, eventdata, handles)
% hObject    handle to startTimeBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of startTimeBox as text
%        str2double(get(hObject,'String')) returns contents of startTimeBox as a double
t1 = str2double(get(handles.startTimeBox,'string'));
t2 = str2double(get(handles.endTimeBox,'string'));
t = sort([t1 t2]);
x = round(t.*handles.filtdat.Rate)+1;
if x(1) < 1 x(1) = 1; end
if x(2) > length(handles.signal) x(2) = length(handles.signal); end
handles.filtdat.startT = (x(1)-1)/handles.filtdat.Rate;
handles.filtdat.endT = (x(2)-1)/handles.filtdat.Rate;
set(handles.startTimeBox,'string',num2str(handles.filtdat.startT));
set(handles.endTimeBox,'string',num2str(handles.filtdat.endT));

handles.filtdat.template = handles.signal(x(1):x(2));
handles = updatePlots(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function startTimeBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to startTimeBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function endTimeBox_Callback(hObject, eventdata, handles)
% hObject    handle to endTimeBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of endTimeBox as text
%        str2double(get(hObject,'String')) returns contents of endTimeBox as a double
t1 = str2double(get(handles.startTimeBox,'string'));
t2 = str2double(get(handles.endTimeBox,'string'));
t = sort([t1 t2]);
x = round(t.*handles.filtdat.Rate)+1;
if x(1) < 1 x(1) = 1; end
if x(2) > length(handles.signal) x(2) = length(handles.signal); end
handles.filtdat.startT = (x(1)-1)/handles.filtdat.Rate;
handles.filtdat.endT = (x(2)-1)/handles.filtdat.Rate;
set(handles.startTimeBox,'string',num2str(handles.filtdat.startT));
set(handles.endTimeBox,'string',num2str(handles.filtdat.endT));

handles.filtdat.template = handles.signal(x(1):x(2));
handles = updatePlots(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function endTimeBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to endTimeBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in saveBtn.
function saveBtn_Callback(hObject, eventdata, handles)
% hObject    handle to saveBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.filtdat.mode = get(handles.corrRadio,'value');
handles.filtdat.template = handles.filtdat.template;
handles.filtdat.outputMode = get(handles.filterChainOutCombo,'value');
handles.output = handles.filtdat;
guidata(hObject, handles);
uiresume(handles.templateGUI);

% --- Executes on button press in cancelBtn.
function cancelBtn_Callback(hObject, eventdata, handles)
% hObject    handle to cancelBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.output = [];
guidata(hObject, handles);
uiresume(handles.templateGUI);

% --- Executes on button press in templateRadio.
function templateRadio_Callback(hObject, eventdata, handles)
% hObject    handle to templateRadio (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of templateRadio
if get(hObject,'value') == 0
    set(hObject,'value',1);
else
    handles = updatePlots(handles);
end
guidata(hObject, handles);

% --- Executes on button press in powerRadio.
function powerRadio_Callback(hObject, eventdata, handles)
% hObject    handle to powerRadio (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of powerRadio

if get(hObject,'value') == 0
    set(hObject,'value',1);
else
    handles = updatePlots(handles);
end
guidata(hObject, handles);


% --- Executes on button press in corrRadio.
function corrRadio_Callback(hObject, eventdata, handles)
% hObject    handle to corrRadio (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of corrRadio
if get(hObject,'value') == 0 set(hObject,'value',1); end
guidata(hObject,handles);


% --- Executes on button press in diffRadio.
function diffRadio_Callback(hObject, eventdata, handles)
% hObject    handle to diffRadio (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of diffRadio
if get(hObject,'value') == 0 set(hObject,'value',1); end
guidata(hObject,handles);


% --- Executes on selection change in filterChainOutCombo.
function filterChainOutCombo_Callback(hObject, eventdata, handles)
% hObject    handle to filterChainOutCombo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns filterChainOutCombo contents as cell array
%        contents{get(hObject,'Value')} returns selected item from filterChainOutCombo


% --- Executes during object creation, after setting all properties.
function filterChainOutCombo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filterChainOutCombo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


