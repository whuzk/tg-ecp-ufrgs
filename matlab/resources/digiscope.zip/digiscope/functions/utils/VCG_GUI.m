function varargout = VCG_GUI(varargin)
% VCG_GUI M-file for VCG_GUI.fig
%      VCG_GUI, by itself, creates a new VCG_GUI or raises the existing
%      singleton*.
%
%      H = VCG_GUI returns the handle to a new VCG_GUI or the handle to
%      the existing singleton*.
%
%      VCG_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in VCG_GUI.M with the given input arguments.
%
%      VCG_GUI('Property','Value',...) creates a new VCG_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before VCG_GUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to VCG_GUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help VCG_GUI

% Last Modified by GUIDE v2.5 20-Aug-2008 23:52:57

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @VCG_GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @VCG_GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before VCG_GUI is made visible.
function VCG_GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to VCG_GUI (see VARARGIN)

% Choose default command line output for VCG_GUI
handles.output = hObject;
if nargin ~=4
    errordlg('Vectorcardiogram GUI requires 1 input containing a filter object');
    delete(hObject);
    return;
end
handles.filtdat = varargin{1};
handles.filtdat.Rate = 500;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes VCG_GUI wait for user response (see UIRESUME)
uiwait(handles.VCG_GUI);


% --- Outputs from this function are returned to the command line.
function varargout = VCG_GUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
close(hObject);

function ECG1box_Callback(hObject, eventdata, handles)
% hObject    handle to ECG1box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ECG1box as text
%        str2double(get(hObject,'String')) returns contents of ECG1box as a double


% --- Executes during object creation, after setting all properties.
function ECG1box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ECG1box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in getECG1btn.
function getECG1btn_Callback(hObject, eventdata, handles)
% hObject    handle to getECG1btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[fname,fpath] = uigetfile('*.txt');
if fname == 0 return; end
handles.filtdat.ECG1file = [fpath,fname];
try
    handles.filtdat.ECG1data = load([fpath,fname]);
catch
    errordlg('There was an error reading ECG I data. Please select a valid file and try again.');
    handles.filtdat.ECG1file = [];
    guidata(hObject, handles);
    return;
end
set(handles.ECG1box,'string',handles.filtdat.ECG1file);
guidata(hObject, handles);

function ECG2box_Callback(hObject, eventdata, handles)
% hObject    handle to ECG2box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ECG2box as text
%        str2double(get(hObject,'String')) returns contents of ECG2box as a double


% --- Executes during object creation, after setting all properties.
function ECG2box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ECG2box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in getECG2btn.
function getECG2btn_Callback(hObject, eventdata, handles)
% hObject    handle to getECG2btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[fname,fpath] = uigetfile('*.txt');
if fname == 0 return; end
handles.filtdat.ECG2file = [fpath,fname];
try
    handles.filtdat.ECG2data = load([fpath,fname]);
catch
    errordlg('There was an error reading ECG II data. Please select a valid file and try again.');
    handles.filtdat.ECG2file = [];
    guidata(hObject, handles);
    return;
end
set(handles.ECG2box,'string',handles.filtdat.ECG1file);
guidata(hObject, handles);


function sampleRateBox_Callback(hObject, eventdata, handles)
% hObject    handle to sampleRateBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sampleRateBox as text
%        str2double(get(hObject,'String')) returns contents of sampleRateBox as a double
fs = str2double(get(hObject,'string'));
if fs < 1
    errordlg('The sample rate must be >= 1');
    set(hObject,'string',str2num(handles.filtdat.Rate));
    guidata(hObject,handles);
    return;
end
handles.filtdat.Rate = fs;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function sampleRateBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sampleRateBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in saveBtn.
function saveBtn_Callback(hObject, eventdata, handles)
% hObject    handle to saveBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.output = handles.filtdat;
guidata(hObject,handles);
uiresume(handles.VCG_GUI);

% --- Executes on button press in cancelBtn.
function cancelBtn_Callback(hObject, eventdata, handles)
% hObject    handle to cancelBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.output = [];
guidata(hObject,handles);
uiresume(handles.VCG_GUI);
