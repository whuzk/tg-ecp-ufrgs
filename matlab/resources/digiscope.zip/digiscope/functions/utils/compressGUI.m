function varargout = compressGUI(varargin)
% COMPRESSGUI M-file for compressGUI.fig
%      COMPRESSGUI, by itself, creates a new COMPRESSGUI or raises the existing
%      singleton*.
%
%      H = COMPRESSGUI returns the handle to a new COMPRESSGUI or the handle to
%      the existing singleton*.
%
%      COMPRESSGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in COMPRESSGUI.M with the given input arguments.
%
%      COMPRESSGUI('Property','Value',...) creates a new COMPRESSGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before compressGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to compressGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help compressGUI

% Last Modified by GUIDE v2.5 10-Sep-2008 13:36:51

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @compressGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @compressGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before compressGUI is made visible.
function compressGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to compressGUI (see VARARGIN)

% Choose default command line output for compressGUI
handles.output = hObject;

handles.filtdat = varargin{1};
set(handles.methodCombo,'value',handles.filtdat.method);

handles = updateDisplay(handles);
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes compressGUI wait for user response (see UIRESUME)
uiwait(handles.compressGUI);


% --- Outputs from this function are returned to the command line.
function varargout = compressGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
delete(handles.compressGUI);

%-----------------------------------
function handles = updateDisplay(handles)
set(handles.loadDictBox,'visible','off');
set(handles.loadDictText,'visible','off');
set(handles.loadDictBtn,'visible','off');
set(handles.saveDictBox,'visible','off');
set(handles.saveDictText,'visible','off');
set(handles.saveDictBtn,'visible','off');
switch get(handles.methodCombo,'value')
    case 1 %TP
        set(handles.text2,'visible','off');
        set(handles.errorBox,'visible','off');
        set(handles.smoothingFilterCheck,'visible','off');
    case 2 %fan
        set(handles.text2,'visible','on','string','Thresh: ');
        set(handles.errorBox,'visible','on');
        set(handles.smoothingFilterCheck,'visible','on','string','7-Pt Filter');
    case 3 %AZTEC
        set(handles.text2,'visible','on','string','Thresh: ');
        set(handles.errorBox,'visible','on');
        set(handles.smoothingFilterCheck,'visible','on','string','7-Pt Filter');
    case 4 %huffman
        set(handles.text2,'visible','off','string','Error');
        set(handles.errorBox,'visible','off');
        set(handles.smoothingFilterCheck,'visible','on','string','1st Diff');
        set(handles.loadDictBox,'visible','on');
        set(handles.loadDictText,'visible','on');
        set(handles.loadDictBtn,'visible','on');
        if ~isempty(handles.filtdat.dict)
            set(handles.saveDictBox,'visible','on');
            set(handles.saveDictText,'visible','on');
            set(handles.saveDictBtn,'visible','on');
        end
end


% --- Executes on selection change in methodCombo.
function methodCombo_Callback(hObject, eventdata, handles)
% hObject    handle to methodCombo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns methodCombo contents as cell array
%        contents{get(hObject,'Value')} returns selected item from methodCombo
handles = updateDisplay(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function methodCombo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to methodCombo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function errorBox_Callback(hObject, eventdata, handles)
% hObject    handle to errorBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of errorBox as text
%        str2double(get(hObject,'String')) returns contents of errorBox as a double


% --- Executes during object creation, after setting all properties.
function errorBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to errorBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in saveBtn.
function saveBtn_Callback(hObject, eventdata, handles)
% hObject    handle to saveBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.filtdat.method = get(handles.methodCombo,'value');
handles.filtdat.error = str2double(get(handles.errorBox,'string'));
handles.filtdat.filter = get(handles.smoothingFilterCheck,'value');
if length(get(handles.loadDictBox,'string')) > 0 && ~isempty(handles.filtdat.dict)
    handles.filtdat.useLoadedDict = 1;
else
    handles.filtdat.useLoadedDict = 0;
end
handles.output = handles.filtdat;
guidata(hObject, handles);
uiresume(handles.compressGUI);


% --- Executes on button press in cancelBtn.
function cancelBtn_Callback(hObject, eventdata, handles)
% hObject    handle to cancelBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.output = [];
guidata(hObject, handles);
uiresume(handles.compressGUI);


% --- Executes when user attempts to close compressGUI.
function compressGUI_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to compressGUI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
handles.output = [];
guidata(hObject, handles);
uiresume(handles.compressGUI);


% --- Executes on button press in smoothingFilterCheck.
function smoothingFilterCheck_Callback(hObject, eventdata, handles)
% hObject    handle to smoothingFilterCheck (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of smoothingFilterCheck



function loadDictBox_Callback(hObject, eventdata, handles)
% hObject    handle to loadDictBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of loadDictBox as text
%        str2double(get(hObject,'String')) returns contents of loadDictBox as a double


% --- Executes during object creation, after setting all properties.
function loadDictBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to loadDictBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in loadDictBtn.
function loadDictBtn_Callback(hObject, eventdata, handles)
% hObject    handle to loadDictBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[fname,fpath] = uigetfile('*.mat');
if fname == 0 return; end
D = load([fpath,fname]);
if ~isfield(D,'dict')
    errordlg('Invalid Huffman dictionary matlab file selected.');
    return;
end
handles.filtdat.dict = D.dict;
set(handles.loadDictBox,'string',fname);
guidata(hObject, handles);


function saveDictBox_Callback(hObject, eventdata, handles)
% hObject    handle to saveDictBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of saveDictBox as text
%        str2double(get(hObject,'String')) returns contents of saveDictBox as a double


% --- Executes during object creation, after setting all properties.
function saveDictBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to saveDictBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in saveDictBtn.
function saveDictBtn_Callback(hObject, eventdata, handles)
% hObject    handle to saveDictBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[fname,fpath] = uiputfile('*.mat');
if fname == 0 return; end
dict = handles.filtdat.dict;
save([fpath,fname], 'dict', '-mat');
set(handles.saveDictBox,'string',fname);
