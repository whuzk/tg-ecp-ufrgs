function doUpdate = checkForUpdates(dsDir, repos)

f = statusDlg([],'Checking if updates are needed...','5%');
% first, check if a status file exists
updateDir = sprintf('%s%sfunctions%sutils%supdate%s',dsDir, filesep, filesep, filesep, filesep);
statusFile = [updateDir,'status.mat'];
doUpdate = 1;
if exist(statusFile, 'file')
    doUpdate = compareVersions(repos, statusFile, updateDir);
end
if ~doUpdate
    try close(f); end
    return;
end

getSVNupdate(repos, updateDir, dsDir, statusFile,f);
try close(f); end

%-----------------------------------------
function doUpdate = compareVersions(repos, statusFile, updateDir)
% first load the account information
status = load(statusFile);
svnStatus = getSVNstatus(repos, updateDir, statusFile);
doUpdate = 1;
try
    doUpdate = str2num(status.Revision) ~= str2num(svnStatus.Revision);
end

%-----------------------------------------
function svnStatus = getSVNstatus(repos, updateDir, dsDir, statusFile)
svncmd = 'svn';
rmcmd = 'rm';
if ispc
    svncmd = sprintf('%ssvn.exe',updateDir);
    rmcmd =sprintf('%srm.exe',updateDir);
end
statusTmp = sprintf('%s%sstatus.tmp',updateDir, filesep);
cmd = sprintf('!"%s" info %s > "%s"', svncmd, repos, statusTmp);
eval(cmd);

svnStatus = struct;
% read in the status file
fid = fopen(statusTmp,'r');
if fid == -1
    % error...
end
while 1
    line = fgetl(fid);
    if isempty(line) break; end
    [fld, val] = strtok(line,':');
    val(1:2) = [];
    a = strfind(fld,' ');
    fld(a) = '_';
    svnStatus = setfield(svnStatus, fld, val);
end
fclose(fid);
delete(statusTmp);

%------------------------------
function getSVNupdate(repos, updateDir, dsDir, statusFile,f)
svncmd = 'svn';
rsynccmd = 'cp';
rmcmd = 'rm';
dirList={'','ECGfiles','doc','filterFiles','labs','templateFiles','functions',...
    sprintf('functions%sIO',filesep),sprintf('functions%sfilters',filesep),...
    sprintf('functions%smyFilters',filesep),...
    sprintf('functions%sutils',filesep)};
checkUpdateDir = sprintf('functions%sutils%supdate%s',filesep,filesep, filesep);
checkUpdateFile = sprintf('functions%sutils%supdate%scheckForUpdates.m',filesep,filesep, filesep);
if ispc
    svncmd = sprintf('%ssvn.exe',updateDir);
    rsynccmd = 'copy';
    %rsynccmd = sprintf('%srsync.exe', updateDir);
    rmcmd =sprintf('%srm.exe',updateDir);
end
statusTmp = sprintf('%s%sstatus.tmp',updateDir, filesep);
tmpDir = sprintf('%stmp',updateDir);
if exist(tmpDir,'dir') rmdir(tmpDir,'s'); end
try
    figure(f);
    statusDlg([],'Removing previous temp directories...','10%');
end
%eval(cmd);
try
    figure(f);
    statusDlg([],'Downloading updates','25%');
end
%for i=1:length(dirList)
    cmd = sprintf('!"%s" export --force "%s" "%s"', svncmd, repos, tmpDir);
    eval(cmd);
%end

% mkdir(sprintf('%s%s',tmpDir,checkUpdateDir));
% cmd = sprintf('!"%s" export --force -N "%s%s" "%s%s"', svncmd, repos, checkUpdateFile, tmpDir, checkUpdateFile);
% eval(cmd);
syncdir = sprintf('%s%stmp%s',updateDir,filesep,filesep);
% if ispc
%     syncdrv = syncdir(1);
%     dsdrv = dsDir(1);
%     syncdir(1:2) = [];
%     syncdir = sprintf('/cygdrive/%s/%s', syncdrv, syncdir);
%     dsDir(1:2) = [];
%     dsDir = sprintf('/cygdrive/%s/%s', dsdrv, dsDir);
%     syncdir(strfind(syncdir,filesep)) = '/';
%     dsDir(strfind(dsDir,filesep)) = '/';
% end

%cmd = sprintf('!%s -R "%stmp/" "%s"', rsynccmd,syncdir, dsDir);
try
    figure(f);
    statusDlg([],'Synchronizing directories...','75%');
end
copyfile(syncdir, dsDir,'f');

try
    figure(f);
    statusDlg([],'Updating local status...','90%');
end

svnStatus = getSVNstatus(repos, updateDir);
save(statusFile,'-struct', 'svnStatus');
%cmd = sprintf('!"%s" -rf "%s"', rmcmd, tmpDir);
try
    figure(f);
    statusDlg([],'Removing previous temp directories...','95%');
end
if exist(tmpDir,'dir') rmdir(tmpDir,'s'); end
