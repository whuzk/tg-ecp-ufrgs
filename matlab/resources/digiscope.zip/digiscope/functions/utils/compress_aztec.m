function compressed = compress_aztec(signal, ErrorTol)
%this function takes in the input signal (signal) of size (size) and
%produces an output compressed that consists of the output after performing
%the AZTEC compression algorithm.  
InRef=1;  %where we are in the input data.
OutRef=1; %where we are in the output data
Cur = signal(InRef);  %get the first data point.
Maxi=Cur;
Mini=Cur;
LineLen=0;
PLATEAU=0;
SLOPE=1;
LineMode=PLATEAU;
cAZT=1;
LastOut=-999999;
tmp=1;
siglen = length(signal);
%loop through all the inputs.
while (InRef <= siglen)
    Cur=signal(InRef);
    InRef=InRef+1;
    Max=Maxi;
    Min=Mini;
    LineLen=LineLen+1;
    if (LineLen <=50)
        if(Max<Cur)
           Maxi=Cur; 
        end
        if (Cur<Min)
            Mini=Cur;
        end
    end
    if (LineLen >50 || (Maxi-Mini >=ErrorTol) )
        %fprintf('LineLen is %d, Maxi is %d Mini is %d\n',LineLen,Maxi,Mini);
        T1=LineLen-1;
        Avg=(Max+Min)/2;
        if(LineMode==PLATEAU) %if we're ina  plataeau mode, we want to save where we are, and be ready for the next sample
           if(T1>2) %we have more than 3 points, so save the plateau on reset linelen etc...
               compressed(OutRef)=T1;  %store how long we went on for...
               OutRef=OutRef+1;
               compressed(OutRef)=Avg;
               OutRef=OutRef+1;
               %fprintf('PLAT: output is %d at x=%d linelen=%d\n',Avg,InRef,LineLen);
               %fprintf('writing len of %d\n',T1);
               LastOut=Avg;
           else
               %if it's fewer than 3 points we can store a line instead of
               %a plateau. 
               LineMode=SLOPE;  %we're in slope mode
               Si=LastOut;
               if (Avg-Si <0)
                   Sign=-1;  %we are on a downward slope since the previous point.
               else
                   Sign=1;
               end
               Tsi=T1;
               Si=Cur;
               %fprintf('set Si to Cur at x=%d',Si,InRef);
           end
        else %we're in slope mode right now...
            if (LastOut==-999999)
                %fprintf('setting inital output to %d\n',signal(1));
                %compressed(OutRef)=1;
                %OutRef=OutRef+1;
                %compressed(OutRef)=signal(1);
                %OutRef=OutRef+1;
                %LastOut=InRef(1);
            end
            if (T1>2) %this means we have a slope followed by a plateau...
               compressed(OutRef)=(Tsi-tmp)*-1;
               OutRef=OutRef+1;
               compressed(OutRef)=Avg;
               %fprintf('SLOP: output is %d with weird mode\n',Avg);
               OutRef=OutRef+1; 
               compressed(OutRef)=T1;
               OutRef=OutRef+1;
               compressed(OutRef)=Avg;
               %fprintf('PLAT: Output is %d at x=%d\n',Avg,InRef);
               OutRef=OutRef+1;
               LastOut=Avg;
               LineMode=PLATEAU;
               tmp=0;
               %fprintf('%d: line was %d long, plateau is length %d\n',InRef,Tsi*-1,T1);
            else
               if ( (Avg-Si)*Sign<0 ) %the sign of the signal hasn't changed..
                   Tsi=Tsi+T1; 
                   Si=Avg;
               else %if the sign has changed we need to save the line.
                   compressed(OutRef)=(Tsi-tmp)*-1;
                   OutRef=OutRef+1;
                   compressed(OutRef)=Si;
                   OutRef=OutRef+1;
                   %fprintf('SLOP: output is %d at x=%d len is %d\n',Si,InRef,(Tsi-tmp)*-1);
                   LastOut=Si;  %set the last out variable
                   Tsi=T1;
                   Si=Avg;
                   Sign=Sign*-1;
                   tmp=0;
               end
            end
           
            
        end
        Maxi=Cur;  %we need to reset these values.
        Mini=Cur;
        %fprintf('at %d we set min and max to %d\n',InRef,Cur);
        Max=Cur;
        Min=Cur;
        LineLen=1;
    end%continue on this loop.
    
end
