function [ output_data ] = decompress_tp( input_data )
%DECOMPRESS_TP Summary of this function goes here
%   Detailed explanation goes here

% Create an array twice the size of the input data
output_data = zeros(length(input_data)*2, 1);

% Fill in the data, including interpolated points
in_i = 1;
for i = 1:length(output_data)-1
    if ( mod(i, 2) == 0 )
        output_data(i) = (input_data(in_i) + input_data(in_i-1)) / 2;
    else
        output_data(i) = input_data(in_i);
        in_i = in_i + 1;
    end
end

% The final point can't be reconstructed, so just use the original signal's
% final point.  Also transpose the output so its in the proper dimensions.
output_data(length(output_data)) = input_data(length(input_data));
output_data = output_data';