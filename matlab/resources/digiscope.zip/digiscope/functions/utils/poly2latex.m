function s = poly2latex(a)

s = '';
if isempty(a) return; end

a(find(abs(a) <1e-4)) = 0;
s = sprintf('%s', num2str(a(1)));
for i=2:length(a)
    if a(i) == 0 continue; end
    if sign(a(i)) < 0
        si = '-';
    else
        si = '+';
    end
    if abs(a(i)) == 1
        s = sprintf('%s %s z^{-%d}', s, si, i-1);
    else
        s = sprintf('%s %s %sz^{-%d}', s, si, num2str(abs(a(i)),3), i-1);
    end
end