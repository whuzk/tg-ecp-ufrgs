function s = roots2latex(a)


s = '';
if isempty(a) return; end
if length(a) == 1
    s = num2str(a);
    return;
end
a(find(abs(a) <1e-4)) = 0;
a = fliplr(a);
k = a(1);
r = roots(a);
[ru] = unique(r);
i=1;
if k ~= 1 s = num2str(abs(k)); end
while i <= length(ru)
    if i < length(ru)
        if ru(i) == conj(ru(i+1))
            n = length(find(r == ru(i)));
            if sign((-ru(i))*(-ru(i+1))) == 1
                sgn1 = '';
            else
                sgn1 = '-';
            end
            if sign(-ru(i)-ru(i+1))== 1
                sgn2 = '+';
            else
                sgn2 = '-';
            end
            s = sprintf('%s(%s%s%s%sz^{-1}+z^{-2})',...
                s,sgn1,...
                num2str(abs((-ru(i))*(-ru(i+1))),2),sgn2,...
                num2str(abs(-ru(i)-ru(i+1)),2));
            if n ~= 1 s = sprintf('%s^{%d}',s,n); end
            i = i+2;
        else
            if sign(ru(i)) == -1
                sgn = '+';
            else
                sgn = '-';
            end
            n = length(find(r == ru(i)));
            if ru(i) ~= 0
                s = sprintf('%s(%s%sz^{-1})',s,num2str(abs(ru(i)),2),sgn);
            else
                s = sprintf('%s(z^{-1})',s);
            end
            if n ~= 1 s = sprintf('%s^{%d}',s,n); end
            i=i+1;
        end
    else
        n = length(find(r == ru(i)));
        if sign(ru(i)) == -1
            sgn = '+';
        else
            sgn = '-';
        end
        if ru(i) ~= 0
            s = sprintf('%s(%s%sz^{-1})',s,num2str(abs(ru(i)),2),sgn);
        else
            s = sprintf('%s(z^{-1})',s);
        end
        if n ~= 1 s = sprintf('%s^{%d}',s,n); end
        i=i+1;
    end
end