function compressed = compress_fan(signal, ErrorTol)
%this function takes in the input signal (signal) of size (size) and
%produces an output compressed that consists of the output after performing
%the fan compression algorithm.
XU1=0;
XL1=0;
XU2=0;
XL2=0;
%these 4 variables define the slopes we will be using for our calculations.
%I removed the V2 signal from the original C code.  That doesn't appear to
%be a valid signal at all.  It should just be X2, as it is never used in
%the orignal code, and is never used in the real code.
len=1;
X0=signal(1);
X1=signal(2);
XU1=X1+ErrorTol;
XL1=X1-ErrorTol;
InRef=3;  %where in the signal we are looking at.
compressed(1)=X0;
OutRef=2;
slen = length(signal);
%fprintf('calling fan.m X0 is %d X1 is %d\n',X0,X1);
while( InRef<=slen)
    X2=signal(InRef);  %Get the next sample input
    InRef=InRef+1;  %increment the input reference value
    XU2=(XU1-X0)/len+XU1;  %set the upper bound of X2
    XL2=(XL1-X0)/len+XL1;  %set the lower bound of X2.
    %fprintf('InRef=%d X2=%g XU2=%g XL2=%g\n',InRef,X2,XU2,XL2);
    if (X2<= XU2 && X2>=XL2)
        %first find which bound is more restrictive... XU2 or XL2
        if (XU2>=X2+ErrorTol)  %only change XU2 if it's more restrictive.
            XU2=X2+ErrorTol;
        end
        if (XL2<=X2-ErrorTol)
            XL2=X2-ErrorTol;
        end
        len=len+1;  %increment how long the current line is.
        X1=X2;  %X1 holds the sample preceding X2...  (from the original comments)
    else
        %in this case, X2 is out of the bound, so we need to save the line.
        %fprintf('In else statement, inref= %d\n',InRef);
        compressed(OutRef)=len;
        OutRef=OutRef+1;
        compressed(OutRef)=X1; %we save the final amplitude now
        OutRef=OutRef+1; %increment the outreference pointer.

        %now we reset all the variables.
        X0=X1;
        X1=X2;
        len=1;
        XU1=X1+ErrorTol;
        XL1=X1-ErrorTol;
    end
end
%fprintf('adding the last one len=%d val=%d X1=%d',len,X2,X1);
compressed(OutRef)=len;
compressed(OutRef+1)=X2;
compressed=compressed';
