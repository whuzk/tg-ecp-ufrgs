function [ratio,dict]=compress_huffman(signal, useFilter, dict)
%load ~/743/code/ece763/ecgFiles/ecg117.txt
%VoltHigh=1000;
%VoltLow=-1000;
%plot(ecg117);
%Resolution=16;
%signal = int16(ecg117*(VoltHigh-VoltLow)/(Resolution));
%signal=diff(signal);
%D = int16(signal.data*;
if ischar(signal.Resolution)
    res = str2double(signal.Resolution);
else
    res = (signal.Resolution);
end
if ischar(signal.VoltHigh)
    vHigh = str2double(signal.VoltHigh);
else
    vHigh = (signal.VoltHigh);
end
if ischar(signal.VoltLow)
    vLow = str2double(signal.VoltLow);
else
    vLow = (signal.VoltLow);
end

sigRange = (0:2^res-1)-2^(res-1);
if useFilter
    D = [0, diff(signal.data)];
    D = int16(D/(vHigh-vLow)*(2^12));
else
    D = int16(signal.data/(vHigh-vLow)*(2^12));
end
D(find(D < sigRange(1))) = sigRange(1);
D(find(D > sigRange(end))) = sigRange(end);
syms=sort(unique(D));
sorted=sort(D);
%missSyms = setdiff(sigRange, syms);
%missProb = zeros(size(missSyms));
%fprintf('syms 1 is %d\n',syms(1));
%fprintf('sorted 1 is %d\n',sorted(1));
sym_len=size(syms);
len = length(D);
if sym_len(1) >sym_len(2)
    sym_len=sym_len(1);
else
    sym_len=sym_len(2);
end
sig_len=size(sorted);
if (sig_len(1)>sig_len(2))
    sig_len=sig_len(1);
else
    sig_len=sig_len(2);
end
sort_ref=1;
%fprintf('%d unique symbols\n',sym_len);
sym_ref=1;
full_count=1;
for i=1:length(syms)
    prob(i) = length(find(D == syms(i)));
end
% while(sym_ref<=sym_len)
%     count=0;
%     while(sorted(sort_ref)==syms(sym_ref) && sort_ref<sig_len)
%         count=count+1;
%         sort_ref=sort_ref+1;
%         full_count=full_count+1;
%     end
%     %fprintf('symbol %d has a count of %d\n',syms(sym_ref),count);
%     prob(sym_ref)=count;
%     sym_ref=sym_ref+1;
% end
%fprintf('full_count is %d\n',full_count);
prob = [prob];%, missProb];
syms = [syms];%, missSyms];
ratio=prob;
table=0;
prob=prob/sig_len;
tmp=sum(prob);
fudge=1-tmp;
%fprintf('fudge is %g\n',fudge);
prob(1)=prob(1)+fudge;
if isempty(dict)
    [dict,avglen]=huffmandict(syms,prob);
end
enc=huffmanenco(D,dict);
newsize=size(enc);
if (newsize(2)>newsize(1))
    newsize=newsize(2);
else
    newsize=newsize(1);
end
newsize=newsize/8;
ratio=newsize/len;

%fprintf('new size is %d or %g percent\n',newsize,newsize/5120);
