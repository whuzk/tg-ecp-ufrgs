function signal = decompress_fan(inSignal)
OutRef=1;
InRef=1;
len = length(inSignal);
%fprintf('running for %d\n',size);
while InRef<len
    %fprintf('InRef is %d of %d\n',InRef,size);
    Cur=inSignal(InRef);
    Cur2=inSignal(InRef+2);
    dist=inSignal(InRef+1);
    InRef=InRef+2;
    slope=(Cur2-Cur)/dist;
    signal(OutRef)=Cur;
    OutRef=OutRef+1;
    while dist>1
        signal(OutRef)=Cur+slope;
        Cur=Cur+slope;
        OutRef=OutRef+1;
        dist=dist-1;
    end
end
%fprintf('Cur2 is %d\n',Cur2);
signal(OutRef)=Cur2;
