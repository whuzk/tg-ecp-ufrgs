function filtdat = addOutputInfo(filtdat, str)

infoStr = get(filtdat.infoBox,'string');
if ~iscell(infoStr)
    if isempty(infoStr)
        infoStr = [];
    else
        tmp = infoStr;
        infoStr = [];
        infoStr{1} = tmp;
        clear tmp;
    end

end
infoStr{filtdat.filtPos} = str;
set(filtdat.infoBox,'string',infoStr);
