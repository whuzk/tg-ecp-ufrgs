function TH = transferOut(a,b,TH,parent, mode)
switch mode
    case 1
        num = poly2latex(a);
        den = poly2latex(b);
    case 2
        num = roots2latex(a);
        den = roots2latex(b);
end

if ~isempty(TH) && ishandle(TH)
    delete(TH);
end
pos = get(parent,'position');
TH = text('interpreter', 'latex','string',sprintf('$$H(z)=\\frac{%s}{%s}$$' , num, den),...
    'units','characters','fontsize',14,...
    'parent',parent,'horizontalalignment','left');

ex = get(TH,'extent');
set(TH,'position',[pos(3)/2-ex(3)/2, pos(4)/2+ex(2)/2, 0]);
curSize = 13;
while ex(3) > pos(3) && curSize >= 4
    delete(TH);
    TH = text('interpreter', 'latex','string',sprintf('$$\\frac{%s}{%s}$$' , num, den),...
        'units','characters','fontsize',curSize,...
        'parent',parent,'horizontalalignment','left');
    ex = get(TH,'extent');
    curSize = curSize-1;
end

set(TH,'position',[pos(3)/2-ex(3)/2, pos(4)/2+ex(2)/2, 0]);
