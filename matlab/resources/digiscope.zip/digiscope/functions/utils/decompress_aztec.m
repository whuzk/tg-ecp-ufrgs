function signal = decompress_aztec(inSignal,decompressSize)
InRef=1;
OutRef=1;
Last=inSignal(2);
siglen = length(inSignal);
while (InRef < siglen)
    Len=inSignal(InRef);
    InRef=InRef+1;
    Val=inSignal(InRef);
    InRef=InRef+1;
    if (Len>0)
       for i=1:Len,
          signal(OutRef)=Val;
          OutRef=OutRef+1;
       end
    else
        Len=Len*-1;
        slope=(Val-Last)/Len;
        %fprintf('%d between %d and %d\n',Len,Last,Val);
        Cur=Last;
        
        for i=1:Len,
            %fprintf('output %d is %d\n',OutRef,Cur);
            signal(OutRef)=Cur;
            Cur=Cur+slope;
            OutRef=OutRef+1;
        end
    end
    Last=Val;
end

% Hold the last value
while (OutRef <= decompressSize)
    if Len > 0
        signal(OutRef) = Last;
        OutRef = OutRef + 1;
    else
        Last = Last+slope;
        signal(OutRef) = Last;
        OutRef = OutRef+1;
    end
    
end

