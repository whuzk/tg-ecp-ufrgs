function varargout = DStemplate(varargin)
% change the function name so that it is IDENTICAL to the file name

switch(varargin{1})
    case 'name'
        varargout{1} = 'DStemplate';
        return;
    case 'filtdat'
        filtdat = genericFiltDat;
        filtdat.name = 'New Action Template';
        filtdat.passthrough = 0; % change this to 1
        % so that the output of this filter is propogated to the next step in the chain
        
        % create other fields in filtdat that should be saved for
        % configuring, calculating, and plotting, for example:
        
        % filtdat.newValue = 0; % this creates a new value called newValue,
        % and can be accessed later
        varargout{1} = filtdat;
        return;
    case 'config'
        % the second input is the filtdat structure created during
        % initializtion, and passed from digiscope
        filtdat = varargin{2};
        % the 3rd input is the signal input to this action
        signal = varargin{3};
        
        % call configuration functions here
        % for a user-interface for inputting values, see inputdlg
        % filtdat.newValue = updatedValue;
        
        % once you are finished configuring filtdat and updating the
        % fields, set the output to your filtdat structure to pass it back
        % to digiscope
        varargout{1} = filtdat;
        return;
    case 'calc'
        % your algorithm is called here
        % get the input signal and the filtdat structure from digiscope
        signal = varargin{3};
        filtdat = varargin{2};
        
        %sig = signal.data; % the signal is stored in signal.data
        %fs = signal.Rate; % the sample rate is stored in signal.Rate
        
        % save your output to filtdat.data
        % this function doubles the input data
        % filtdat.Rate =fs; % propagate the sample rate
        % filtdat.data = sig*2;
        
        %finally, if you are going to plot the data, create a time vector
        % filtdat.t = (0:length(filtdat.data)-1)/filtdat.Rate;
        
        % return your new data to digiscope        
        varargout{1} = filtdat;
        return;
    case 'plot'
        % this is where digiscope asks you to plot output
        % your data is passed from digiscope, and you can access it with
        % filtdat again
        filtdat = varargin{2};
        if isempty(filtdat.data) return; end
        
        % filtdat.axes contains the pointer/handle to the plot that you
        % should use, so select it first
        axes(filtdat.axes(1));
        
        hold on;
        % plot your new data
        %plot(filtdat.t, filtdat.data,'color',[0 0 0]);
        hold off;
        return;
end


