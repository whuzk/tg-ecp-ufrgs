function varargout = ECGsquare(varargin)

switch(varargin{1})
    case 'name'
        varargout{1} = 'ECGpantompkins';
        return;
    case 'filtdat'
        % This is where the filter settings are initialized; nothing needs
        % to be changed here
        filtdat = genericFiltDat;
        filtdat.name = 'Pan-Tompkins Thresh';
        filtdat.numPlots = 1;
        filtdat.passthrough=1;
        
        filtdat.lookAhead = 2;
        filtdat.signalUpdate = .125;
        filtdat.noiseUpdate = .125;
        filtdat.signalSBupdate = .25;
        filtdat.rrHighPerc = 1.16;
        filtdat.rrLowPerc = .92;
        filtdat.rrMissLim = 1.66;
        filtdat.peakDur = 75;
        filtdat.QRSupdate = .475;
        
        varargout{1} = filtdat;
        return;

    case 'config'
        % The filter settings are configured here. This uses the inputdlg
        % function, which displays a simple user interface.
        %warndlg('The PT thresholding does not work yet!');
        filtdat = varargin{2};
        
        prompt = {'Look-ahead (s)','Signal Update (0-1)','Noise Update (0-1)',...
            'Searchback Update (0-1)','RR High Range','RR Low Range','RR Miss Limit','Peak Search Range (ms)','QRS Update'};
        def = {num2str(filtdat.lookAhead),...
            num2str(filtdat.signalUpdate),...
            num2str(filtdat.noiseUpdate),...
            num2str(filtdat.signalSBupdate),...
            num2str(filtdat.rrHighPerc),...
            num2str(filtdat.rrLowPerc),...
            num2str(filtdat.rrMissLim),...
            num2str(filtdat.peakDur),...
            num2str(filtdat.QRSupdate)};
        
        answer = inputdlg(prompt,'Adaptive Threshold Parms',1,def);
        
        if ~isempty(answer)
            filtdat.lookAhead = str2double(answer{1});
            filtdat.signalUpdate = str2double(answer{2});
            filtdat.noiseUpdate = str2double(answer{3});
            filtdat.signalSBupdate = str2double(answer{4});
            filtdat.rrHighPerc = str2double(answer{5});
            filtdat.rrLowPerc = str2double(answer{6});
            filtdat.rrMissLim = str2double(answer{7});
            filtdat.peakDur = str2double(answer{8});
            filtdat.QRSupdate = str2double(answer{9});
        end
        varargout{1} = filtdat;
        return;

    case 'calc'
        % this is where the algorithm is actually implemented
        % the signal structure is passed as argument 3, and the filtdat
        % structure is passed as argument 2
        signal = varargin{3};
        filtdat = varargin{2};
        if isempty(signal)
            varargout{1} = filtdat;
            return;
        end
        fs = signal.Rate;
        filtdat.Rate = fs;
        sig = signal.data;
        lahead = round(1:filtdat.lookAhead*fs);
        noiseUpdate = filtdat.noiseUpdate;
        signalUpdate = filtdat.signalUpdate;
        signalSBupdate = filtdat.signalSBupdate;
        lenRRavg = 8;
        rrHighPerc = filtdat.rrHighPerc;
        rrLowPerc = filtdat.rrLowPerc;
        rrMissLim = filtdat.rrMissLim;
        peakDur = ceil(filtdat.peakDur/1000*fs);
        RRmiss = 0;

        %npk = min(sig(lahead));
        %spk = max(sig(lahead));
        thresh1 = 2/2^12;
        thresh2 = thresh1/2;
        blankPer = round(.2*filtdat.Rate);
        
        deriv1buf = zeros(3,1);
        deriv1out = [];
        
        qpkcnt = 0;
        maxder = 0;
        lastmax = 0;
        cnt = 0;
        sbpeak = 0;
        initBlank = 0;
        initMax = 0;
        preBlankCnt =0;
        ddPtr = 0;
        sbCount = round(1.5*fs);
        tempPeak =0;
        
        
        WINDOW_WIDTH = peakDur;
        PRE_BLANK = round(2*peakDur);
        
        pos = 1;
        %pk = sig(pos);
        pk = 0;
        v2 = 0;
        curPeak = 0;
        range = (-peakDur+1):0;
        RR = zeros(size(sig));
        RR(1:8) = fs;
        rsetBuf(1:8) = 0;
        rsetBufPos = 1;
        QRS = zeros(size(sig));
        QRSreal= zeros(size(sig));
        QRSpeakBuf = zeros(size(sig));
        noisePeakBuf(1:8) = 0;
        noisePos = 1;
        timeSinceMax = 0;
        lastQRS = 0;
        filtdat.thresh1 = zeros(size(sig));
        filtdat.thresh1(1:pos) = thresh1;
        filtdat.thresh2 = zeros(size(sig));
        filtdat.thresh2(1:pos) = thresh2;
        newpk = 0;
        searchback = 0;
        waiting = 0;
        lastQRS = 1;
        waitForNextPeak = 0;
        dMax = 0;
        dly = 0;
        pkTmp = 1;
        pkTmp2 = 1;
        pkPos = 1;
        pkCnt = 1;
        qmedian=0;
        nmedian = 0;
        while pos <= length(sig)
            
            v = sig(pos);
            
            if (timeSinceMax > 0) 
                timeSinceMax  =timeSinceMax+1; end
            % get the peak
            pk = 0;
            if pos > 140
                asdf=1;
            end
            if v > v2 && v > dMax
                dMax = v;
                pkTmp2 = pos;
                if dMax > 2/2^(str2double(signal.Resolution)) 
                    timeSinceMax = 1; 
                end
            elseif v < (dMax/2)
                pk = dMax;                
                dMax = 0;
                timeSinceMax = 0;
                dly = 0;
            elseif timeSinceMax > round(.095*fs)
                pk = dMax;
                dMax = 0;
                timeSinceMax = 0;
                dly = 3;
            end
            
            newPeak = 0;
            
            if (pk ~= 0 && preBlankCnt==0)
                tempPeak = pk;
                pkTmp = pkTmp2;
                preBlankCnt = PRE_BLANK;
            elseif pk==0 && preBlankCnt ~= 0
                preBlankCnt = preBlankCnt-1;
                if preBlankCnt == 0 
                    newPeak = tempPeak; 
                    pkPos = pkTmp;
                end
            elseif pk ~= 0
                if pk > tempPeak
                    tempPeak = pk;
                    pkTmp = pkTmp2;
                    preBlankCnt = PRE_BLANK;
                else
                    preBlankCnt = preBlankCnt-1;
                    if preBlankCnt == 0
                        newPeak = tempPeak;
                        pkTmp = pkTmp2;
                    end
                end
            end
            
%             deriv1buf(3) = deriv1buf(2);
%             deriv1buf(2) = deriv1buf(1);
%             deriv1buf(1) = v;
%             deriv1out = [deriv1out, deriv1buf(1)-deriv1buf(3)];
            
            if qpkcnt < 9
                cnt = cnt+1;
                if newPeak > 0 
                    cnt = WINDOW_WIDTH; end
                initBlank = initBlank+1;
                if initBlank == fs || newPeak > 0
                    if newPeak > thresh1
                        initBlank = 0;
                        QRSpeakBuf(pkCnt) = newPeak;
                        QRS(pkCnt) = pos;
                        QRSreal(pkCnt) = pkPos;
                        pkCnt = pkCnt+1;
                        initMax = 0;
                        qpkcnt = qpkcnt+1;
                        %if qpkcnt==8
                        qmedian = median(QRSpeakBuf(1:qpkcnt));
                        nmedian = 0;
                        rrmedian = fs;
                        sbcount = round(fs*(1.500+.150));
                        dmed = qmedian-nmedian;
                        thresh1 = calcThresh(qmedian, nmedian, filtdat.QRSupdate);
                        thresh2 = thresh1/2;
                    else
                        noisePeakBuf(noisePos) = newPeak;
                        noisePos = noisePos+1;
                        if noisePos > 8 noisePos=1; end                        
                        nmedian = median(noisePeakBuf);
                        thresh1 = calcThresh(qmedian, nmedian, filtdat.QRSupdate);
                        if qmedian == 0
                            thresh1 = mean(noisePeakBuf)*(1+filtdat.QRSupdate);
                        end
                        thresh2 = thresh1/2;
                    end
                    
                    %end
                end
                if newPeak > initMax
                    initMax = newPeak;
                    pkPos =pkTmp;
                end
            else
                cnt = cnt+1;
                if newPeak > 0
                    if newPeak > thresh1
                        qrsDelay = signal.totalDelay;
                        QRSpeakBuf(pkCnt) = newPeak;
                        QRS(pkCnt) = pos;%-qrsDelay;
                        QRSreal(pkCnt) = pkTmp;
                        qmedian = median(QRSpeakBuf(pkCnt-7:pkCnt));
                        thresh1 = calcThresh(qmedian, nmedian, filtdat.QRSupdate);
                        RR(pkCnt) = cnt;
                        pkCnt = pkCnt+1;
                        rrmedian = median(RR(pkCnt-7:pkCnt));
                        sbcount = rrmedian + rrmedian/2 + peakDur;
                        cnt = peakDur;
                        sbpeak = 0;
                        lastmax = maxder;
                        maxder = 0;
                        
                        sbpeak = 0;
                        lastmax = maxder;
                        maxder = 0;
                        initBlank = 0;
                        initMax = 0;
                        rsetBufPos = 1;
                    else
                        noisePeakBuf(noisePos) = newPeak;
                        noisePos = noisePos+1;
                        if noisePos > 8 noisePos=1; end                        
                        nmedian = median(noisePeakBuf);
                        thresh1 = calcThresh(qmedian, nmedian, filtdat.QRSupdate);
                        thresh2 = thresh1/2;

                        if (newPeak > sbpeak) && (cnt - peakDur >= round(fs*.36))
                            sbpeak = newPeak;
                            sbloc = cnt - peakDur;
                        end
                    end
                end
                if cnt > sbCount && sbpeak > thresh2
                    qrsDelay = cnt - sbloc;
                    cnt = cnt-sbloc;
                    qrsDelay = qrsDelay + signal.totalDelay;
                    
                    QRSpeakBuf(pkCnt) = sbpeak;
                    QRS(pkCnt) = pos-qrsDelay;
                    QRSreal(pkCnt) = pkTmp;
                    
                    qmedian = median(QRSpeakBuf(pkCnt-8:pkCnt-1));
                    thresh1 = calcThresh(qmedian, nmedian, filtdat.QRSupdate);
                    thresh2 = thresh1/2;
                    RR(pkCnt) = sbloc;
                    pkCnt = pkCnt+1;
                    rrmedian = median(RR(pkCnt-8:pkCnt-1));
                    sbcount = rrmedian + rrmedian/2 +peakDur;                   
                    
                    
                    sbpeak = 0;
                    lastmax = maxder;
                    maxder = 0;
                    initBlank = 0;
                    initMax = 0;
                    rsetBufPos = 1;
                end
            end
            if qpkcnt == 8
                initBlank = initBlank+1;
                if initBlank == fs
                    initBlank = 0;
                    rsetBuf(rsetBufPos) = initMax;
                    rsetBufPos = rsetBufPos+1;
                    if rsetBufPos > 8 rsetBufPos=1; end
                    initMax = 0;
                    if rsetBufPos == 8
                        for q=1:8
                            QRSpeakBuf(q) = rsetBuf(q);
                            noisePeakBuf(q) = 0;
                        end
                        qmedian = median(rsetBuf);
                        nmedian = 0;
                        rrmedian = fs;
                        sbcount = round(fs*(1.5+.15));
                        thresh1 = calcThresh(qmedian, nmedian, filtdat.QRSupdate);
                        thresh2 = thresh1/2;
                        initBlank = 0;
                        initMax = 0;
                        rsetCount = 0;
                        rsetBufPos = 1;
                        sbpeak = 0;
                    end
                end
                if newPeak > initMax
                    initMax = newPeak;
                end
            end
%             [pktmp,idx] = max(sig(pos+range));
%             if pktmp ~= pk && abs(idx - length(range)/2) <3
%             %if pktmp > sig(pos+range(1)) && pktmp > sig(pos+range(end)) && pktmp ~= pk
%                 pk = pktmp;
%                 if ~searchback
%                     if pk >= thresh1
%                         spk = (signalUpdate)*pk + (1-signalUpdate)*spk;
%                     else
%                         npk = noiseUpdate*pk +(1-noiseUpdate)*npk;
%                     end
%                 else
%                     if pk >= thresh2
%                         spk = (signalSBupdate)*pk + (1-signalSBupdate)*spk;
%                     else
%                         npk = noiseUpdate*pk +(1-noiseUpdate)*npk;
%                     end
%                 end
%                 thresh1 = npk + (spk-npk)/4;
%                 thresh2 = thresh1/2;
%             end
%             if ~searchback threshtmp = thresh1;
%             else threshtmp = thresh2;
%             end
%             if v <= spk/2 && v2 > spk/2 && pk > threshtmp && waiting == 0
% %                 if ~searchback
% %                     spk = (signalUpdate)*pk + (1-signalUpdate)*spk;
% %                 else
% %                     spk = (signalSBpdate)*pk + (1-signalSBUpdate)*spk;
% %                 end
%                 QRS = [QRS, pos];
%                 lastQRS = pos;
%                 waitForNextPeak = 0;
%                 if length(QRS) > 1
%                     RR = [RR, QRS(end)-QRS(end-1)];
%                     rRange = min(length(RR), 8)-1;
%                     RRavg1 = mean(RR(end-rRange:end));
%                     RRavg2 = RRavg1;
%                     if rRange >= 7
%                         % start updating searchback
%                         tmpPos = intersect(find(RR <= RRhigh), find(RR >= RRlow));
%                         tmpRange = min(length(tmpPos),8)-1;
%                         RRavg2 = mean(RR(end-tmpRange:end));
%                         RRhigh = rrHighPerc*RRavg2;
%                         RRlow = rrLowPerc*RRavg2;
%                         RRmiss = rrMissLim*RRavg2;
%                     else
%                         RRhigh = rrHighPerc*RRavg2;
%                         RRlow = rrLowPerc*RRavg2;
%                         RRmiss = rrMissLim*RRavg2;
%                     end
% %                     RRavg1(RRavg1Pos) = RR(end) - RR(end-1);
% %                     RRavg1Pos = RRavg1Pos+1;
% %                     if RRavg1Pos >lenRRavg RRavg1Pos = 1; end
%                 end
%                 
%                 waiting = blankPer;
%                 thresh1 = npk + (spk-npk)/4;
%                 thresh2 = thresh1/2;
%                 searchback = 0;
%             end
%             if waiting > 0 
%                 waiting = waiting-1; end
%             
%             % check if searchback is necessary
%             if RRmiss ~= 0
%                 if (pos-lastQRS) >= RRmiss
%                     if searchback == 0 && waitForNextPeak == 0
%                         pos2 = pos;
%                         pos = lastQRS;
%                         v2 = sig(pos-1);
%                         searchback = 1;
%                         waiting = blankPer;
%                         continue;
%                     else
%                         waitForNextPeak = 1;
%                     end
%                 end
%             end
%             if searchback && pos == pos2
%                 searchback = 0;
%             end
%             
%             v2 = sig(pos);
            filtdat.thresh1(pos) = thresh1;
            filtdat.thresh2(pos) = thresh2;
            v2 = v;
            pos = pos+1;

        end
        filtdat.data = signal.data;
        QRS(pkCnt:end) = [];
        QRSreal(pkCnt:end) = [];
        RR(pkCnt:end) = [];
        filtdat.QRS = QRS;
        filtdat.QRSreal = QRSreal;
        filtdat.RR = RR;

        filtdat.t = (0:length(filtdat.data)-1)/filtdat.Rate;
        
        filtdat.output = sprintf('Heartrate=%1.2f BPM', 60*filtdat.Rate/mean(filtdat.RR));

        varargout{1} = filtdat;
        return;

    case 'plot'
        % the results are plotted here
        filtdat = varargin{2};
        % select the axes assigned by digiscope
        axes(filtdat.axes(1));
        hold on; % turn hold on so that multiple plots are not overwritten

        %---------------------------
        % YOUR CODE GOES HERE
        % plot the original signal, the threshold line, and the markers
        % where the beats are detected
        if isempty(filtdat.data) return; end
        plot(filtdat.t, filtdat.data,'color',[0 0 0]); % plot the data
        plot(filtdat.t(filtdat.QRS), filtdat.data(filtdat.QRS),'r*');
        plot(filtdat.t, filtdat.thresh1,'color','g');
        plot(filtdat.t(filtdat.QRSreal), filtdat.data(filtdat.QRSreal),'g*');
        if isfield(filtdat,'atrtime')
            plot(filtdat.t(filtdat.atrtime), filtdat.data(filtdat.atrtime),'b*');
        end
        %plot(filtdat.t, filtdat.thresh2,'color',[1 0 1]);

        % CODE FINISHED
        %---------------------------
        hold off;

        % examples: to plot markers, you include a symbol after the data to
        % plot, e.g.: plot(time, data, '*')
        % this displays stars at each sample instead of connected lines
        return;
end

%-------------------
function thrsh = calcThresh(qmedian, nmedian, TH)
thrsh = nmedian + TH*(qmedian - nmedian);

