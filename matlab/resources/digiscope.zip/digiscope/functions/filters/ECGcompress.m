function varargout = ECGcompress(varargin)

switch(varargin{1})
    case 'name'
        varargout{1} = 'ECGcompress';
        return;
    case 'filtdat'
        filtdat = genericFiltDat;
        filtdat.name = 'ECGcompress';
        filtdat.passthrough = 1;
        filtdat.method = 1;
        filtdat.error = [];
        filtdat.filter = [];
        filtdat.dict = [];
        filtdat.useLoadedDict = 0;
        varargout{1} = filtdat;
        return;
    case 'config'
        filtdat = varargin{2};
        C = compressGUI(filtdat);
        if ~isempty(C)
            filtdat = C;
        end
        varargout{1} = filtdat;
        return;
    case 'calc'
        signal = varargin{3};
        filtdat = varargin{2};
        filtdat.oldSig = signal.data;
        filtdat.oldt = signal.t;
        if isempty(filtdat.method)
            varargout{1} = filtdat;
            return;
        end
        switch filtdat.method
            case 1 % turning-point
                CS = compress_tp(signal.data);
                filtdat.data = decompress_tp(CS);
                filtdat.CS = CS;
                filtdat.t = (0:length(filtdat.data)-1)/signal.Rate;
                PRD = sqrt(sum((signal.data-filtdat.data).^2)/sum(signal.data.^2))*100;
                filtdat.output = sprintf('Compress: Ratio=%d:%d, PRD=%1.3f%%',length(signal.data), length(CS), PRD);
                
            case 2 % fan
                b = [-2 3 6 7 6 3 -2];
                a = 21;
                CS = compress_fan(signal.data,filtdat.error);
                filtdat.data = decompress_fan(CS);
                if filtdat.filter
                    filtdat.data = filtfilt(b,a,filtdat.data);
                end
                filtdat.CS = CS;
                filtdat.t = (0:length(filtdat.data)-1)/signal.Rate;
                PRD = sqrt(sum((signal.data-filtdat.data).^2)/sum(signal.data.^2))*100;
                filtdat.output = sprintf('Compress: Ratio=%d:%d, PRD=%1.3f%%',length(signal.data), length(CS), PRD);
            case 3 % AZTEC
                b = [-2 3 6 7 6 3 -2];
                a = 21;
                CS = compress_aztec(signal.data,filtdat.error);
                filtdat.data = decompress_aztec(CS, length(signal.data));
                if filtdat.filter
                    filtdat.data = filtfilt(b,a,filtdat.data);
                end
                filtdat.CS = CS;
                filtdat.t = (0:length(filtdat.data)-1)/signal.Rate;
                PRD = sqrt(sum((signal.data-filtdat.data).^2)/sum(signal.data.^2))*100;
                filtdat.output = sprintf('Compress: Ratio=%d:%d, PRD=%1.3f%%',length(signal.data), length(CS), PRD);
            case 4 % huffman
                if filtdat.useLoadedDict
                    [filtdat.ratio,filtdat.dict] = compress_huffman(signal, filtdat.filter, filtdat.dict);
                else
                    [filtdat.ratio,filtdat.dict] = compress_huffman(signal, filtdat.filter, []);
                end
                filtdat.data = signal.data;
                filtdat.t = (0:length(filtdat.data)-1)/filtdat.Rate;
                PRD = 0;
                filtdat.output = sprintf('Compress: Ratio=%1.2f%%, PRD=%1.3f%%',filtdat.ratio*100, PRD);
        end
        varargout{1} = filtdat;
    case 'plot'
        filtdat = varargin{2};
        if isempty(filtdat.data) return; end
        axes(filtdat.axes(1));
        
        hold on;
        plot(filtdat.oldt, filtdat.oldSig,'r');
        plot(filtdat.t, filtdat.data,'color',[0 0 0]);
        hold off;
        return;
end


