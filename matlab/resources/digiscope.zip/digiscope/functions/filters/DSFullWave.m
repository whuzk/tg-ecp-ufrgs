function varargout = DSFullWave(varargin)

switch(varargin{1})
    case 'name'
        varargout{1} = 'DSFullWave';
        return;
    case 'filtdat'
        % This is where the filter settings are initialized; nothing needs
        % to be changed here
        filtdat = genericFiltDat;
        filtdat.name = 'Full-Wave Rect';
        filtdat.numPlots = 1;
        filtdat.passthrough=1;
        varargout{1} = filtdat;
        return;
        
    case 'config'
        % The filter settings are configured here. This uses the inputdlg
        % function, which displays a simple user interface.
        varargout{1} = varargin{2};
        return;
        
    case 'calc'
        % this is where the algorithm is actually implemented
        % the signal structure is passed as argument 3, and the filtdat
        % structure is passed as argument 2
        signal = varargin{3};
        filtdat = varargin{2};
        filtdat.data = abs(signal.data);
        %filtdat.data(find(filtdat.data < 0)) = 0;
        %filtdat.data = filtdat.data.^2;
        filtdat.Rate = signal.Rate;    
        
        filtdat.t = (0:length(filtdat.data)-1)/filtdat.Rate;
        
        varargout{1} = filtdat;
        return;
        
    case 'plot'
        % the results are plotted here
        filtdat = varargin{2};
        % select the axes assigned by digiscope
        axes(filtdat.axes(1));
        hold on; % turn hold on so that multiple plots are not overwritten
        
        %---------------------------
        % YOUR CODE GOES HERE
        % plot the original signal, the threshold line, and the markers
        % where the beats are detected
        plot(filtdat.t, filtdat.data,'color',[0 0 0]); % plot the data
    
        % CODE FINISHED
        %---------------------------
        hold off;
        
        % examples: to plot markers, you include a symbol after the data to
        % plot, e.g.: plot(time, data, '*')
        % this displays stars at each sample instead of connected lines
        return;
end