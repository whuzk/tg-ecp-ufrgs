function varargout = ECGpower(varargin)

switch varargin{1}

    case 'name'
        varargout{1} = 'Power';
        return;
    case 'filtdat'
        filtdat = genericFiltDat;
        filtdat.name = 'Power';

        filtdat.normalize = 1;
        filtdat.doLog = 1;
        filtdat.scroll = 0;
        filtdat.updateOnScroll = 0;
        filtdat.updateWindow = 1;
        filtdat.removeMean = 0;

        filtdat.maxF = 100;
        filtdat.nfft = 400;
        filtdat.minNFFT = 512;
        filtdat.win = 1;
        varargout{1} = filtdat;
        return;
    case 'config'
        filtdat = varargin{2};
        signal = varargin{3};
        filtdat.nfft = diff(signal.plotRange);
        filtdat.maxF = signal.Rate/2;
        prompt = {'Max Freq','Normalize (0/1)','Use LOG10','Window (1=Rect,2=Hanning,3=Tri)','Remove Mean'};
        defans = {num2str(filtdat.maxF),...
            num2str(filtdat.normalize),num2str(filtdat.doLog),num2str(filtdat.win), num2str(filtdat.removeMean)};

        answer = inputdlg(prompt,'Power Spectrum',1,defans);
        if isempty(answer)
            varargout{1} = filtdat;
            return;
        end
        filtdat.maxF = str2num(answer{1});
        filtdat.normalize = str2num(answer{2});
        filtdat.doLog = str2num(answer{3});
        filtdat.updateWindow = 1;%str2num(answer{5});
        filtdat.win = str2num(answer{4});
        filtdat.removeMean = str2num(answer{5});
        varargout{1} = filtdat;
        return;
    case 'calc'
        signal = varargin{3};
        filtdat = varargin{2};
        range = round(signal.plotRange(1):(signal.plotRange(end)-1));
        sig = signal.data(range);
        if filtdat.removeMean
            sig = sig-mean(sig);
        end
        switch filtdat.win
            case 1
                win = ones(size(sig));
            case 2
                win = hann(length(sig))';
            case 3
                win = triang(length(sig))';
        end
        NFFT = max(filtdat.minNFFT, length(sig)*2);
        D = 2*abs(fft(sig.*win, NFFT)/length(sig));
        filtdat.f = signal.Rate*linspace(0,1,NFFT);
        if filtdat.normalize == 1
            D = D./max(D);
        end
        D(find(D < 1e-6)) = 1e-6;
        if filtdat.doLog
            D = 20*log10(D);
        end
        filtdat.data = D;
        mPos = find(filtdat.data == max(filtdat.data));
        mPos = mPos(1);
        filtdat.output = sprintf('Power: Peak at %1.3f Hz',filtdat.f(mPos));
        varargout{1} = filtdat;
    case 'plot'
        filtdat = varargin{2};
        axes(filtdat.axes(1));
        plot(filtdat.f, filtdat.data,'color',[0 0 0]);
        if filtdat.maxF > filtdat.f(end)
            hold on;
            YL = get(filtdat.axes(1),'ylim');
            for k=1:ceil(filtdat.maxF/filtdat.f(end))-1
                plot(filtdat.f+filtdat.f(end)*k,filtdat.data,'color',[0 0 0]);
                plot(filtdat.f(end)*[k k], YL,'r');
            end
        end
        xlim([0 filtdat.maxF]);
        if filtdat.doLog
            ylabel('Power (db)');
        else
            ylabel('|Y(f)|');
        end
        xlabel('Frequency (Hz)');
        return;
end
