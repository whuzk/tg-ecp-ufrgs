function varargout = ECGresample(varargin)

switch(varargin{1})
    case 'name'
        varargout{1} = 'ECGresample';
        return;
    case 'filtdat'
        filtdat = genericFiltDat;
        filtdat.name = 'Resample';
        filtdat.passthrough = 1;
        filtdat.Rate = [];
        filtdat.oldfs = [];
        filtdat.plotMarker = 1;
        varargout{1} = filtdat;
        return;
    case 'config'
        filtdat = varargin{2};
        signal = varargin{3};
        answer = inputdlg({'Old Sample Rate','New Sample Rate','Plot Markers (0/1)'},'Enter a new sample rate',1,{num2str(signal.Rate),'',num2str(filtdat.plotMarker)});
        if ~isempty(answer)
            filtdat.oldfs = str2double(answer{1});
            filtdat.Rate = str2double(answer{2});
            filtdat.plotMarker = str2double(answer{3});
        end
        varargout{1} = filtdat;
        return;
    case 'calc'
        signal = varargin{3};
        filtdat = varargin{2};
        if isempty(filtdat.Rate)
            filtdat.data = [];
            return;
        end
        range = round(1:(filtdat.oldfs/filtdat.Rate):length(signal.data));
        
        filtdat.data = signal.data(range);
        filtdat.t = (0:length(filtdat.data)-1)/filtdat.Rate;
        filtdat.oldsig = signal.data;
        filtdat.oldt = (0:length(signal.data)-1)/signal.Rate;
        varargout{1} = filtdat;
    case 'plot'
        filtdat = varargin{2};
        if isempty(filtdat.data) return; end
        axes(filtdat.axes(1));
        plot(filtdat.t, filtdat.data,'r');
        hold on;
        plot(filtdat.oldt, filtdat.oldsig,':','color',[0 0 0]);
        if filtdat.plotMarker == 1 plot(filtdat.t, filtdat.data,'o'); end
        return;
end


