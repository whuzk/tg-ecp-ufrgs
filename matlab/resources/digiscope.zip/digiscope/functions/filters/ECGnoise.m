function varargout = ECGnoise(varargin)

switch(varargin{1})
    case 'name'
        varargout{1} = 'ECGnoise';
        return;
    case 'filtdat'
        filtdat = genericFiltDat;
        filtdat.name = 'Add Noise';
        filtdat.passthrough = 1;
        filtdat.amp = .1;
        filtdat.mode = 1;
        varargout{1} = filtdat;
        return;
    case 'config'
        filtdat = varargin{2};
        answer = inputdlg({'Noise Amplitude (mV)','Noise Type (1=60Hz,2=50Hz,3=Rand)'},...
            'Add Noise',1,{num2str(filtdat.amp*1000),num2str(filtdat.mode)});
        if ~isempty(answer)
            filtdat.amp = str2double(answer{1})/1000;
            filtdat.mode = str2double(answer{2});
        end
        varargout{1} = filtdat;
        return;
    case 'calc'
        signal = varargin{3};
        filtdat = varargin{2};
        filtdat.Rate = signal.Rate;
        if isempty(filtdat.amp)
            varargout{1} = filtdat;
            return;
        end
        filtdat.t = ((0:length(signal.data)-1)/filtdat.Rate);
        switch filtdat.mode
            case 1
                filtdat.data = signal.data(:) + filtdat.amp*sin(2*pi*filtdat.t(:)*60);
            case 2
                filtdat.data = signal.data(:) + filtdat.amp*sin(2*pi*filtdat.t(:)*50);
            case 3
                filtdat.data = signal.data + filtdat.amp*randn(size(signal.data));
        end
        varargout{1} = filtdat;
    case 'plot'
        filtdat = varargin{2};
        if isempty(filtdat.data) return; end
        axes(filtdat.axes(1));
        plot(filtdat.t, filtdat.data,'color',[0 0 0]);
        return;
end


