function varargout = ECGFilter(varargin)

switch varargin{1}

    case 'name'
        varargout{1} = 'ECGFilter';
        return;
    case 'filtdat'
        filtdat = genericFiltDat;
        filtdat.name = 'Filter Designer';
        filtdat.passthrough = 1;
        filtdat.poles = [];
        filtdat.zeros = [];
        filtdat.scroll = 1;
        filtdat.updateOnScroll = 0;
        filtdat.updateWindow = 0;
        filtdat.sigreqd = 0;
        filtdat.filterType = 1;
        varargout{1} = filtdat;
        return;
    case 'config'
        filtdat = varargin{2};
        signal = varargin{3};
        if ~isempty(signal)
            filtdat.Rate = signal.Rate;
        else
            filtdat.Rate = 200;
        end
        % pause, so that it works...?
        pause(.5);
        F = FilterGUI(filtdat);      
        if isempty(F)
            varargout{1} = filtdat;
            return;
        end
        if ~isempty(F.poles)
            tmp = fields(F);
            for i=1:length(tmp)
                filtdat = setfield(filtdat,tmp{i},getfield(F,tmp{i}));
            end
        end
        varargout{1} = filtdat;
        return;
    case 'calc'
        signal = varargin{3};
        filtdat = varargin{2};
        
        if isempty(signal)
            varargout{1} = filtdat;
            return;
        end
        filtdat.Rate = signal.Rate;
        
        if isempty(filtdat.zeros) || isempty(filtdat.poles)
            varargout{1} = filtdat;
            return;
        end
        filtdat.delay = ceil(length(filtdat.zeros)/2);
        if isempty(signal)
            filtdat.data = [];
            filtdat.t = [];
            varargout{1} = filtdat;
            return;
        end
        filtdat.data = filter(filtdat.zeros, filtdat.poles, signal.data);
        filtdat.t = (0:length(filtdat.data)-1)/filtdat.Rate;
        varargout{1} = filtdat;
    case 'plot'
        filtdat = varargin{2};
        if isempty(filtdat.data) return; end
        axes(filtdat.axes(1));
        plot(filtdat.t, filtdat.data,'color',[0 0 0]);
        return;
end
