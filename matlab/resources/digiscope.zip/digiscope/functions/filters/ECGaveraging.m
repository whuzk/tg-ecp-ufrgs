function varargout = Vectorcardiogram(varargin)

switch(varargin{1})
    case 'name'
        varargout{1} = 'ECGaveraging';
        return;
    case 'filtdat'
        filtdat = genericFiltDat;
        filtdat.name = 'Averaging';
        filtdat.numAvg = 16;
        filtdat.noiseAmp = .1;
        filtdat.passthrough = 0;
        filtdat.sigreqd = 0;
        filtdat.scroll = 1;
        filtdat.numPlots = 2;
        varargout{1} = filtdat;
        return;
    case 'config'
        filtdat = varargin{2};
        answer = inputdlg({'# Averages','Noise Amplitude (mV)'},'Averaging (mV)',1,...
            {num2str(filtdat.numAvg),num2str(filtdat.noiseAmp*1000)});
        if isempty(answer) 
            varargout{1} = filtdat; 
            return; 
        end
        filtdat.numAvg = str2double(answer{1});
        filtdat.noiseAmp = str2double(answer{2})/1000;
        varargout{1} = filtdat;
        return;
    case 'calc'
        signal = varargin{3};
        filtdat = varargin{2};
        if isempty(filtdat.numAvg) || isempty(filtdat.noiseAmp)
            varargout{1} = filtdat;
            return;
        end
        len = length(signal.data);
        filtdat.noise = filtdat.noiseAmp*randn(len, filtdat.numAvg);
        filtdat.noisyECG = repmat(signal.data(:),[1 filtdat.numAvg]) + filtdat.noise;
        filtdat.data = mean(filtdat.noisyECG,2);
        filtdat.RMSavgNoise = sqrt(mean((filtdat.data - signal.data(:)).^2));
        filtdat.RMSnoise = sqrt(mean(filtdat.noise.^2,1));
        filtdat.RMSsig = sqrt(mean((signal.data).^2));
        filtdat.RMSavg = sqrt(mean((filtdat.data).^2));
        filtdat.RMSnoisyECG = sqrt(mean((filtdat.noisyECG).^2,1));
        filtdat.SNRavg = filtdat.RMSavg/filtdat.RMSavgNoise;
        filtdat.SNRnoisy = filtdat.RMSnoisyECG./filtdat.RMSnoise;
        filtdat.t = signal.t;
        filtdat.Rate = signal.Rate;
        str = sprintf('Avg: Avg RMS=%1.2f, Orig RMS=%1.2f, Mean Noisy ECG RMS=%1.2f',...
            mean(filtdat.RMSnoisyECG),filtdat.RMSsig, mean(filtdat.RMSnoise));
        str = sprintf('%s\nMean SNR of Noisy ECG=%1.2f, SNR Avg ECG=%1.2f, Expected Improvement=%1.2f, Actual Improvement=%1.2f',...
            str,mean(filtdat.SNRnoisy), filtdat.SNRavg, sqrt(filtdat.numAvg), filtdat.SNRavg/mean(filtdat.SNRnoisy));
        filtdat.output = str;
        varargout{1} = filtdat;
        return;
    case 'plot'
        filtdat = varargin{2};
        if isempty(filtdat.data) return; end
        % check that we have 6 axes available
        if length(filtdat.axes) ~= 2
            error('Incorrect number of subplots available!');
            return;
        end
        
        axes(filtdat.axes(1));
        plot(filtdat.t, filtdat.noisyECG); ylabel('Noisy');
        axes(filtdat.axes(2));
        plot(filtdat.t, filtdat.data); ylabel('Avg');
        return;
end