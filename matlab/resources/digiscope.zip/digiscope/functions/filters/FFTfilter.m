function varargout = FFTfilter(varargin)

switch(varargin{1})
    case 'name'
        varargout{1} = 'FFTfilter';
        return;
    case 'filtdat'
        filtdat = genericFiltDat;
        filtdat.name = 'FFT Filter';

        filtdat.maxF = 100;
        filtdat.winLen = 20;
        filtdat.overlap = 10;
        filtdat.nfft = 512;
        filtdat.binWidth = 1;
        filtdat.bins = 1;
        filtdat.passthrough = 1;
        varargout{1} = filtdat;
        return;
    case 'config'
        filtdat = varargin{2};
        
        prompt = {'Window Length (samples)','Overlap (samples)','NFFT','Max Freq','Bin Width (Hz)','Bins'};
        defans = {num2str(filtdat.winLen), num2str(filtdat.overlap),...
            num2str(filtdat.nfft), num2str(filtdat.maxF),...
            num2str(filtdat.binWidth), num2str(filtdat.bins)};

        answer = inputdlg(prompt,'ECG Specgram Config',1,defans);
        if isempty(answer)
            varargout{1} = filtdat;
            return;
        end
        filtdat.winLen = str2double(answer{1});
        filtdat.overlap = str2double(answer{2});
        filtdat.nfft = str2double(answer{3});
        filtdat.maxF = str2double(answer{4});
        filtdat.binWidth = str2num(answer{5});
        filtdat.bins = str2num(answer{6});
        varargout{1} = filtdat;
        return;
    case 'calc'        
        filtdat = varargin{2};
        signal = varargin{3};
        maxLength = 50000 + filtdat.winLen-mod(10000, filtdat.winLen);
        bins = [];
        nCols = fix((length(signal.data)-filtdat.winLen)/(filtdat.winLen-filtdat.overlap));
        filtdat.data = zeros(1, nCols);
        q = 1;
        for p=1:maxLength:length(signal.data)
            clear D;
            range = p + (0:(maxLength-1));
            range(find(range > length(signal.data))) = [];
            [tmp, filtdat.f, t, D] = spectrogram(signal.data(range),...
                filtdat.winLen,...
                filtdat.overlap,...
                filtdat.nfft,...
                signal.Rate);
            % get the associated bins
            clear tmp;
            if p  == 1
                a = find(filtdat.f <= filtdat.binWidth);
                w = a(end);
                %D2 = zeros(length(1:w:size(D,1)),size(D,2));
                range = 0:(w-1);
                for i=1:length(filtdat.bins)
                    bins = [bins, (filtdat.bins(i)-1)*w+1+range];
                end
            end
            range2 = q + (0:(length(t)-1));
            q = q+length(t);
            filtdat.data(range2) = [mean(D(bins,:),1)];

        end       
        
        filtdat.Rate = 1/(t(2)-t(1));
%        numAdds = length(0:1/filtdat.Rate:filtdat.t(1)-1/filtdat.Rate);
        %filtdat.data = [zeros(1, numAdds), filtdat.data];
        filtdat.t = (0:length(filtdat.data)-1)/filtdat.Rate;%[0:1/filtdat.Rate:filtdat.t(1)-1/filtdat.Rate, filtdat.t];
        varargout{1} = filtdat;
    case 'plot'
        filtdat = varargin{2};
        axes(filtdat.axes(1));
        plot(filtdat.t, filtdat.data);
        %ylim([0 filtdat.maxF]);
        %ylabel('Freq (hz)');
        set(gca,'ydir','normal');
        return;
end