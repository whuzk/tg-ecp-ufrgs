function varargout = ECGbeatDetector(varargin)
% BME 463 Lab 1 - Beat Detection
% This lab introduces the MATLAB DigiScope interface, which you will use to
% read in a signal from digiscope, detect the QRS waves, plot your results,
% and output the beats-per-minute in the digiscope window.
% DigiScope3 has a reasonably straightforward interface that allows new
% signal filters to be developed quickly. This lab shows how to use this
% interface to add a new REUSABLE algorithm to DigiScope, and output
% results. This file will give a brief overview of this interface; for more
% information, consult the digiscope documentation.


switch(varargin{1})
    case 'name'
        varargout{1} = 'ECGbeatDetector';
        return;
    case 'filtdat'
        % This is where the filter settings are initialized; nothing needs
        % to be changed here
        filtdat = genericFiltDat;
        filtdat.name = 'Beat Detector';
        filtdat.numPlots = 1;
        filtdat.thresh = 0;
        filtdat.skip = 1;
        filtdat.qrs = [];
        filtdat.edge = 0;
        varargout{1} = filtdat;
        return;
        
    case 'config'
        % The filter settings are configured here. This uses the inputdlg
        % function, which displays a simple user interface. 
        filtdat = varargin{2};

        % prompt is a cell array containing the questions that should be
        % asked. In this case, only threshold is set. To add additonal
        % variables, you can do: 
        % prompt = {'Threshold','New Variable 1','New Variable 2'};
        prompt = {'Threshold','Rising Edge(0)/Falling Edge(1)'};
        
        % defans contains the default answers. If you add variables above
        % to the prompt, you MUST add default answers for them here. Note
        % that to convert a number to a string, you can use the num2str
        % function, e.g.:
        % defans = {num2str(filtdat.thresh), num2str(filtdat.NewVar1),
        %               num2str.NewVar2)};
        defans = {num2str(filtdat.thresh),num2str(filtdat.edge)};

        % the returned variables are stored in answer as a cell array of
        % strings. Type 'help inputdlg' for information on using inputdlg
        % here. If the user exits the window or cancels, answer is empty,
        % so the unchanged filtdat variable should be returned and exit
        % from the function.
        answer = inputdlg(prompt,'Threshold Detection',1,defans);
        if isempty(answer)
            varargout{1} = filtdat;
            return;
        end
        % if we did not return, convert the strings in answer to numbers,
        % and save them in the filtdat structure.
        filtdat.thresh = str2double(answer{1});
        filtdat.edge = str2num(answer{2});

        % return the configured filtdat to digiscope
        varargout{1} = filtdat;
        return;
        
    case 'calc'
        % this is where the algorithm is actually implemented
        % the signal structure is passed as argument 3, and the filtdat
        % structure is passed as argument 2
        signal = varargin{3};
        filtdat = varargin{2};
        
        % in this case, we are not actually changing the signal in this
        % filter, so the data and sample rate for the signal are assigned
        % to filtdat.data and filtdat.Rate, so that it can be passed to the
        % next step in the filter chain if necessary
        filtdat.data = signal.data;
        filtdat.Rate = signal.Rate;    
        
        filtdat.qrs = []; % store sample positions in this variable
        
        
        
        %----------------------------------------------
        % YOUR CODE GOES HERE
        % I have included a basic algorithm. You should improve upon this
        % so that only a SINGLE sample is stored for every beat
        if filtdat.edge ~= 0
            a = find(filtdat.data <= filtdat.thresh);
        else
            a = find(filtdat.data >= filtdat.thresh);
        end
        filtdat.qrs = a([1, find(diff(a) > 15)+1]);
        filtdat.BPM = filtdat.Rate/mean(diff(filtdat.qrs))*60;
        
        % CODE FINISHED
        %----------------------------------------------
        
        % Remember: if you need additional settings that can be changed by
        % the user, you can put them in 'config'!
        
        % example: create a time vector for this data for use in plotting.
        % This creates a vector starting at 0, incrementing by 1 to the 
        % length of the data, and divides by the sample rate to get each
        % time point for each sample
        filtdat.t = (0:length(filtdat.data)-1)/filtdat.Rate;
        
        
        % at the command line, type 'doc sprintf' to learn more about using
        % formatted strings
        filtdat.output = sprintf('Beat Detect: Avg BPM = %1.3f',filtdat.BPM(1));
        varargout{1} = filtdat;
        return;
        
    case 'plot'
        % the results are plotted here
        filtdat = varargin{2};
        % select the axes assigned by digiscope
        axes(filtdat.axes(1));
        hold on; % turn hold on so that multiple plots are not overwritten
        
        %---------------------------
        % YOUR CODE GOES HERE
        % plot the original signal, the threshold line, and the markers
        % where the beats are detected
        plot(filtdat.t, filtdat.data,'color',[0 0 0]); % plot the data
        plot(filtdat.t(filtdat.qrs), filtdat.data(filtdat.qrs),'r*'); % plot markers
        % CODE FINISHED
        %---------------------------
        hold off;
        
        % examples: to plot markers, you include a symbol after the data to
        % plot, e.g.: plot(time, data, '*')
        % this displays stars at each sample instead of connected lines
        return;
end


% Lab 1 Procedure
% 1. Introduction - Every digiscope interface file has an input and output variable,
% called varargin and varargout ('variable argument input/output'). These
% varibles are MATLAB cells; each cell can contain a different matlab
% object, such as a matrix, structure, or anything else. When you call a
% matlab function, you can pass zero, one or more variables to the function, and
% return one or more variables, e.g.: 
% [a,b]= MyFunction(signal, filter);
% In this case, the signal and filter variables are input to the
% MyFunction function. Within the function, these variables are stored
% in varargin. To get the signal and filter variables, you would do something like:
% signal = varargin{1};
% filter = varargin{2};
% Note the use of the curly brackets (shift+[ or shift+]), which is the
% matlab syntax for accessing a cell. There is also a variable in every
% function called nargin, that gives the number of input arguments passed;
% in this example, nargin would be two.
% To return variables, you assign them to varargout. If you calculated a
% new signal and saved it in a variable called newSignal, you can return
% this by typing:
% varargout{1} = newSignal;
% Additional outputs are returned the same way:
% varargout{2} = newFilter;
% The number of outputs that are expected are given by nargout. The number
% of variables returned should equal nargout.

% 2. DigiScope interface - DigiScope operates on ECG signals using
% 'filters'. A filter is any algorithm that operates on a signal, and is
% not just a time-domain filter, although time-domain filters ARE a subset
% of DigiScope filters.
% The first argument to any DigiScope filter is a
% command, which tells the function what DigiScope is expecting it to do.
% The commands are: name, filtdat, config, calc, and plot. 
% The first thing a DigiScope filter does is determine which command was passed, which is
% done with the switch(varargin{1}) statement. 
% The name command just % returns the name of the file and is used to ensure that the filter is a
% valid DigiScope filter. 
% The second command, filtdat, sets up the settings
% for this filter. When the 'filtdat' command is called from
% digiscope, the file initializes the general settings required for ALL
% digiscope filters, updates these variables from the default values if
% necessary, and initializes any new variables unique to this filter. All
% of this is stored in a structure called filtdat. A structure contains
% named variables, or fields, which are accessed using a period. For example, to
% access the 'name' field of the filtdat structure, you would type:
% filtdat.name
% You can assign values like:
% filtdat.name = 'MyFunction';
% At the end of the filtdat function, the new filtdat structure is returned
% to digiscope with by assigning it to varargout{1} and returning, like:
% varargout{1} = filtdat; return;
% The third command is 'config'. This is where filter settings are changed.
% In this case, varargin{2} contains the filtdat structure for this filter,
% which is passed from DigiScope, and varargin{3} contains the input signal
% to this filter. The 'config' section is where any changes to the filter
% are made, either by hardcoding values (bad) or using a user interface
% (good). A simple user interface is the matlab inputdlg command, which
% allows users to enter values to be used. The updated settings are saved
% to the filtdat structure, which is then passed back to digiscope in
% varargout{1}.
% The 4th command is 'calc' which is where the actual algorithm is
% implemented. After configuring the filter, calc is called from DigiScope.
% The second parameter passed (varargin{2}) is the input signal, and the
% third is this filter's filtdat structure. Using the settings stored in
% filtdat, the input signal is changed in some way, and the results are
% stored in filtdat. Generally, the primary results are stored in
% filtdat.data, and secondary variables that should be saved are also
% stored in filtdat as well. DigiScope uses a filter chain concept, where
% the variable stored in filtdat.data is passed to the next step in the chain,
% so this should be an ECG type signal.
% The calc function is also where results that should be printed
% can be saved to the filtdat.output variable as a string. See below for
% examples. After the calculation completes, the updated
% filtdat variable is returned to digiscope in varargout{1}.
% The final command is 'plot'. This is where results are plotted in
% digiscope, or externally. Again, filtdat is passed as the 2nd argument.
% Based on the numPlots field set under the filtdat command, DigiScope
% creates one or more plots for this filter. The location of these plots
% are stored in the filtdat.axes variable. Most filters only require 1
% axes, but some can use more. To activate the first axes, you would type:
% axes(filtdat.axes(1));
% Any matlab plot commands are then directed to that specific plot. Your
% results from 'calc' can be plotted in the correct axes this way. The plot
% command does not return any values. 

% 3. ECG Beat Detector - In this lab, the initial parts of the filter are
% already setup for you. The config function returns a variable, the
% manually set threshold, which is stored in filtdat.thresh. First, try to
% implement the beat detector using the threshold value. There are several
% (many?) acceptable methods of doing this. If you decide that there are
% additional settings the user may want to change, you can add them to the
% config section; information on doing this is contained there. Your final
% results should be saved in filtdat. I recommend creating a variable
% called 'qrs' which contains the sample numbers where the beats have been
% detected, e.g., qrs might contain the vector [200 405 638 867 ... 4098].
% After calculating the beat locations, output the beats per minute to the
% digiscope information window using by assigning a string to the
% filtdat.output variable. Finally, under plot, plot the original signal,
% which is stored in filtdat.data, the threshold line, and the points where
% the beat was detected.