function varargout = ECGtemplate(varargin)

switch(varargin{1})
    case 'name'
        varargout{1} = 'Template Matching';
        return;
    case 'filtdat'
        filtdat = genericFiltDat;
        filtdat.name = 'Template Matching';

        filtdat.template = [];
        filtdat.method = 0;
        filtdat.passthrough = 1;
        filtdat.outputMode = 1;
        varargout{1} = filtdat;
        return;
    case 'config'
        filtdat = varargin{2};
        signal = varargin{3};

        D = Template_GUI(signal.data, filtdat);
        if ~isempty(D.template)
            filtdat = D;
        end
        varargout{1} = filtdat;
        return;
    case 'calc'
        filtdat = varargin{2};
        signal = varargin{3};
        if isempty(filtdat.template)
            varargout{1} = filtdat;
            return;
        end
        filtdat.Rate = signal.Rate;
        
        filtdat.Rxy = [];
        filtdat.Dxy = [];
        filtdat.data = [];
        %-----------------------------
        % YOUR CODE GOES HERE
        % use the lab4_template.m file to implement the algorithm in
        % Digiscope
        % NOTES: 
        % * the input signal data is accessed with signal.data, the
        % template returned from the GUI is accessed with filtdat.template.
        % * remove the mean from the template before calculating the
        % correlation
        % * store the correlation in filtdat.Rxy, and the difference in filtdat.Dxy
        % * make sure that the times of the correlation/difference are
        % correct (e.g., a peak in the correlation should NOT appear
        % before the corresponding peak in the ECG!)
        sig = signal.data;
        temp = filtdat.template - mean(filtdat.template);
        m = length(temp);
        n = length(temp)-1;
        for i=1:length(sig) - m
            s=sig(i:i+n)-mean(sig(i:i+n));
            filtdat.Dxy(i+n)=sum(abs(s-temp));
            filtdat.Rxy(i+n)=sum(s.*temp)/sqrt(sum(s.^2)*sum(temp.^2));
        end

        %-----------------------------
        % END OF YOUR CODE - DO NOT EDIT BELOW THIS LINE!
        %-----------------------------        
        switch filtdat.outputMode
            case 1
                switch filtdat.mode
                    case 1
                        filtdat.data = filtdat.Rxy;
                    case 0
                        filtdat.data = filtdat.Dxy;
                end
                
                filtdat.scroll = 1;
            case 2
                filtdat.data = filtdat.template;
                filtdat.t = (0:length(filtdat.template)-1)/filtdat.Rate;
                filtdat.scroll = 0;
        end
        varargout{1} = filtdat;
        
    case 'plot'
        
        filtdat = varargin{2};
        if isempty(filtdat.data) return; end
        axes(filtdat.axes(1));
        t = (0:length(filtdat.data)-1)/filtdat.Rate;
        plot(t, filtdat.data,'color',[0 0 0]);
        ylabel('Corr.');
        if filtdat.outputMode == 2
            xlim([t(1) t(end)]);
            ylabel('Temp.');
        end
        
        return;
end


