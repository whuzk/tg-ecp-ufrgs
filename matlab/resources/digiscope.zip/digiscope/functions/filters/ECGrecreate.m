function varargout = ECGresample(varargin)

switch(varargin{1})
    case 'name'
        varargout{1} = 'ECGrecreate';
        return;
    case 'filtdat'
        filtdat = genericFiltDat;
        filtdat.name = 'Up-sample';
        filtdat.passthrough = 1;
        filtdat.Rate = [];
        filtdat.mode = 1;
        filtdat.oldfs = [];
        filtdat.showOld = 0;
        varargout{1} = filtdat;
        return;
    case 'config'
        filtdat = varargin{2};
        signal = varargin{3};
        answer = inputdlg({'Mode (1=ZOH,2=lin,3=sin','Old Sample Rate','New Sample Rate','Show Old Signal'},...
            'Enter a new sample rate',1,{num2str(filtdat.mode),num2str(signal.Rate),...
            num2str(filtdat.Rate),num2str(filtdat.showOld)});
        if ~isempty(answer)
            filtdat.mode = str2num(answer{1});
            filtdat.oldfs = str2double(answer{2});
            filtdat.Rate = str2double(answer{3});
            filtdat.showOld = str2num(answer{4});
        end
        varargout{1} = filtdat;
        return;
    case 'calc'
        signal = varargin{3};
        filtdat = varargin{2};
        if isempty(filtdat.Rate)
            filtdat.data = [];
            return;
        end
        filtdat.t = (0:1/filtdat.Rate:(length(signal.data)/signal.Rate))';
        switch filtdat.mode
            case 1 % ZOH
                D = resample(timeseries(signal.data, signal.t), filtdat.t,'zoh');
                filtdat.data = squeeze(D.data);
                filtdat.t = squeeze(D.time);
            case 2
                D = resample(timeseries(signal.data, signal.t), filtdat.t,'linear');
                filtdat.data = squeeze(D.data);
                filtdat.t = squeeze(D.time);
            case 3
                filtdat.data = interpft(signal.data,length(signal.t));
        end
        filtdat.t = filtdat.t + signal.t(1);
        filtdat.oldsig = signal.data;
        filtdat.oldt = signal.t;
        varargout{1} = filtdat;
    case 'plot'
        filtdat = varargin{2};
        if isempty(filtdat.data) return; end
        axes(filtdat.axes(1));
        plot(filtdat.t, filtdat.data,'color',[0 0 0]);
        if filtdat.showOld == 0 return; end
        hold on;
        plot(filtdat.oldt, filtdat.oldsig,':','color',[1 0 0]);
        return;
end


