function varargout = ECGadaptiveFilter(varargin)

switch(varargin{1})
    case 'name'
        varargout{1} = 'ECGadaptiveFilter';
        return;
    case 'filtdat'
        filtdat = genericFiltDat;
        filtdat.name = 'Adaptive Filter';
        filtdat.passthrough = 1;
        filtdat.d = .1;
        varargout{1} = filtdat;
        return;
    case 'config'
        filtdat = varargin{2}
        answer = inputdlg({'Adaptation (mV)'},'Adaptive Filter',1,{num2str(filtdat.d*1000)});
        if ~isempty(answer)
            filtdat.d = str2double(answer{1})/1000;
        end
        varargout{1} = filtdat;
        return;
    case 'calc'
        signal = varargin{3};
        filtdat = varargin{2};
        filtdat.Rate = signal.Rate;
        if isempty(filtdat.d)
            varargout{1} = filtdat;
            return;
        end
        D = adaptiveFilter(signal.data, filtdat.Rate,filtdat.d);
        filtdat.data = D;
        filtdat.t = (0:length(D)-1)/filtdat.Rate;
        varargout{1} = filtdat;
    case 'plot'
        filtdat = varargin{2};
        if isempty(filtdat.data) return; end
        axes(filtdat.axes(1));
        plot(filtdat.t, filtdat.data,'color',[0 0 0]);
        return;
end


