function varargout = ECGspec(varargin)

switch(varargin{1})
    case 'name'
        varargout{1} = 'Spectrogram';
        return;
    case 'filtdat'
        filtdat = genericFiltDat;
        filtdat.name = 'Spectrogram';

        filtdat.maxF = 100;
        filtdat.winLen = 20;
        filtdat.overlap = 10;
        filtdat.nfft = 512;
        varargout{1} = filtdat;
        return;
    case 'config'
        filtdat = varargin{2};
        
        prompt = {'Window Length (samples)','Overlap (samples)','NFFT','Max Freq','Plot'};
        defans = {num2str(filtdat.winLen), num2str(filtdat.overlap),...
            num2str(filtdat.nfft), num2str(filtdat.maxF), num2str(filtdat.plot)};

        answer = inputdlg(prompt,'ECG Specgram Config',1,defans);
        if isempty(answer)
            varargout{1} = filtdat;
            return;
        end
        filtdat.winLen = str2double(answer{1});
        filtdat.overlap = str2double(answer{2});
        filtdat.nfft = str2double(answer{3});
        filtdat.maxF = str2double(answer{4});
        filtdat.plot = str2double(answer{5});
        varargout{1} = filtdat;
        return;
    case 'calc'
        filtdat = varargin{2};
        signal = varargin{3};
        [tmp, filtdat.f, filtdat.t, filtdat.data] = spectrogram(signal.data,...
            filtdat.winLen,...
            filtdat.overlap,...
            filtdat.nfft,...
            filtdat.Rate);
        filtdat.data = 10*log10(filtdat.data);
        varargout{1} = filtdat;
    case 'plot'
        filtdat = varargin{2};
        axes(filtdat.axes(1));
        imagesc(filtdat.t, filtdat.f, filtdat.data);
        ylim([0 filtdat.maxF]);
        ylabel('Freq (hz)');
        set(gca,'ydir','normal');
        return;
end