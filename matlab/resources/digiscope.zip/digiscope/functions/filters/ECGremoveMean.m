function varargout = ECGremoveMean(varargin)

switch(varargin{1})
    case 'name'
        varargout{1} = 'ECGremoveMean';
        return;
    case 'filtdat'
        filtdat = genericFiltDat;
        filtdat.name = 'Remove Mean';
        filtdat.passthrough = 1;
        varargout{1} = filtdat;
        return;
    case 'config'
        varargout{1} = varargin{2};
        return;
    case 'calc'
        signal = varargin{3};
        filtdat = varargin{2};
        filtdat.data = signal.data-mean(signal.data);
        filtdat.t = (0:length(filtdat.data)-1)/filtdat.Rate;
        varargout{1} = filtdat;
    case 'plot'
        filtdat = varargin{2};
        if isempty(filtdat.data) return; end
        axes(filtdat.axes(1));
        
        plot(filtdat.t, filtdat.data,'color',[0 0 0]);
        return;
end


