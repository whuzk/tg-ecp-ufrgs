% BlockyCleanup -- Remove global datastructures for BlockyDemoclear global Fil2 Fil4 Fil6 Fil8clear global EdgeFil2 EdgeFil4 EdgeFil6 EdgeFil8clear labels callbacks header         
 
%
%  Part of Wavelab Version 850
%  Built Tue Jan  3 13:20:41 EST 2006
%  This is Copyrighted Material
%  For Copying permissions see COPYING.m
%  Comments? e-mail wavelab@stat.stanford.edu 
