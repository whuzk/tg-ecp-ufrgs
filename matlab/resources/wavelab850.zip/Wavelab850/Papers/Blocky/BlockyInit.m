% BlockyInit -- setup global data structures for BlockyDemoglobal Fil2 Fil4 Fil6 Fil8global EdgeFil2 EdgeFil4 EdgeFil6 EdgeFil8%   MakeAllFilters                
 
%
%  Part of Wavelab Version 850
%  Built Tue Jan  3 13:20:41 EST 2006
%  This is Copyrighted Material
%  For Copying permissions see COPYING.m
%  Comments? e-mail wavelab@stat.stanford.edu 
