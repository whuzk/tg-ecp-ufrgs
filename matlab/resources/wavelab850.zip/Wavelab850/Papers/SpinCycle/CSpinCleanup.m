clear global CSFIGNUM  
clear global L QMF_Filter 
clear global t 
clear global QuadChirp MishMash n 
clear global xQuad yQuad 
clear global xMish yMish 
clear global N rho 
clear global xhblocks xhheavi 
clear global tsine nsine 
clear global fRatSine fIrrSine 
clear global RatSine IrrSine yRatSine yIrrSine 
clear global tsine nsine 
clear global tiwtblocks 
clear global Noisy_Stat_Table 
clear global Blocks Bumps HeaviSine Doppler 
clear global xblocks xbumps xheavi xDoppler 
clear global yblocks ybumps yheavi yDoppler 
    
    
 
 
%
%  Part of Wavelab Version 850
%  Built Tue Jan  3 13:20:42 EST 2006
%  This is Copyrighted Material
%  For Copying permissions see COPYING.m
%  Comments? e-mail wavelab@stat.stanford.edu 
