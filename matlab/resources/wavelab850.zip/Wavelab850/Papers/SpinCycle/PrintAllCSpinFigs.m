% PrintAllCSpinFigs: Generate Encapsulated Postscript

cspinf01; print -deps cspin01.ps; close;
cspinf02; print -deps cspin02.ps; close;
cspinf03; print -deps cspin03.ps; close;
cspinf04; print -deps cspin04.ps; close;
cspinf05; print -deps cspin05.ps; close;
cspinf06; print -deps cspin06.ps; close;
cspinf07; print -deps cspin07.ps; close;
cspinf08; print -deps cspin08.ps; close;
cspinf09; print -deps cspin09.ps; close;
cspinf11; print -deps cspin11.ps; close;
cspinf12; print -deps cspin12.ps; close;
cspinf13; print -deps cspin13.ps; close;
cspinf14; print -deps cspin14.ps; close;
cspinf15; print -deps cspin15.ps; close;
cspinf16; print -deps cspin16.ps; close;
cspinf17; print -deps cspin17.ps; close;
cspinf18; print -deps cspin18.ps; close;
cspinf19; print -deps cspin19.ps; close;
cspinf20; print -deps cspin20.ps; close;
cspinf21; print -deps cspin21.ps; close;
cspinf10; print -deps cspin10.ps; close;
    
    
    
 
 
%
%  Part of Wavelab Version 850
%  Built Tue Jan  3 13:20:42 EST 2006
%  This is Copyrighted Material
%  For Copying permissions see COPYING.m
%  Comments? e-mail wavelab@stat.stanford.edu 
